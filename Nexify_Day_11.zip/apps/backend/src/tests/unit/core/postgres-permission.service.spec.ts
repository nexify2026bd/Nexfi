import { describe, it, expect, vi } from 'vitest';

/**
 * Day 11 STEP 10 — RBAC tests for the real IPermissionService implementation.
 * Mocks the pg pool (no live database in this environment — see class doc comment) and
 * asserts the exact query text/parameter binding, plus the resulting permission-set
 * behavior for several scenarios: multiple-roles resolution, and an unknown user
 * resolving to zero permissions (never "everything", never an error that fails open).
 */
vi.mock('../../../core/database/pg-pool', () => ({
  readPool: { query: vi.fn() },
}));

describe('PostgresPermissionService', () => {
  it('queries identity.user_roles/role_permissions/permissions with the userId parameterized (never string-interpolated)', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      rows: [{ code: 'product.read' }, { code: 'product.create' }],
    });
    const { PostgresPermissionService } = await import('../../../core/rbac/postgres-permission.service');
    const service = new PostgresPermissionService();

    const result = await service.getPermissionsForUser('user-abc');

    expect(readPool.query).toHaveBeenCalledTimes(1);
    const [sql, params] = (readPool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('identity.user_roles');
    expect(sql).toContain('identity.role_permissions');
    expect(sql).toContain('identity.permissions');
    expect(sql).toContain('$1');
    expect(sql).not.toContain('user-abc'); // never string-interpolated into the query text
    expect(params).toEqual(['user-abc']);
    expect(result).toEqual(['product.read', 'product.create']);
  });

  it('a user with multiple roles resolves to the union of all their roles\' permissions (single flattened query, not per-role calls)', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      rows: [{ code: 'product.read' }, { code: 'product.approve' }, { code: 'seller.suspend' }],
    });
    const { PostgresPermissionService } = await import('../../../core/rbac/postgres-permission.service');
    const service = new PostgresPermissionService();

    const result = await service.getPermissionsForUser('multi-role-user');
    expect(readPool.query).toHaveBeenCalledTimes(1); // one query resolves all roles via the JOIN, not N queries
    expect(result).toEqual(['product.read', 'product.approve', 'seller.suspend']);
  });

  it('a user with no rows in user_roles resolves to an empty permission set, not an error and not "everything"', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresPermissionService } = await import('../../../core/rbac/postgres-permission.service');
    const service = new PostgresPermissionService();

    const result = await service.getPermissionsForUser('unknown-user');
    expect(result).toEqual([]);
  });
});
