import { describe, it, expect, beforeEach, vi } from 'vitest';
import jwt from 'jsonwebtoken';
import type { IRefreshTokenRepository, StoredRefreshToken } from '../../../core/auth/refresh-token.repository.port';

/**
 * Day 11-13 — authentication tests for the real IAuthTokenService implementation.
 * Covers JWT verification (valid/expired/malformed/bad-signature/wrong-algorithm/
 * payload-shape) and, as of Day 13, real refresh-token persistence/rotation/replay
 * detection — exercised against an in-memory fake IRefreshTokenRepository rather than a
 * live database (none available in this environment), so the actual PostgreSQL query
 * shape is verified separately in postgres-refresh-token.repository.spec.ts.
 */
const ACCESS_SECRET = 'test-access-secret-not-a-real-production-value';
const REFRESH_SECRET = 'test-refresh-secret-not-a-real-production-value';

/** Simple in-memory stand-in for IRefreshTokenRepository — same contract, no SQL. */
class InMemoryRefreshTokenRepository implements IRefreshTokenRepository {
  private rows = new Map<string, StoredRefreshToken>();

  async store(tokenHash: string, userId: string, expiresAt: Date): Promise<void> {
    this.rows.set(tokenHash, { userId, expiresAt, revokedAt: null });
  }

  async findByHash(tokenHash: string): Promise<StoredRefreshToken | null> {
    return this.rows.get(tokenHash) ?? null;
  }

  async revoke(tokenHash: string): Promise<void> {
    const row = this.rows.get(tokenHash);
    if (row && !row.revokedAt) row.revokedAt = new Date();
  }

  async revokeAllForUser(userId: string): Promise<void> {
    for (const row of this.rows.values()) {
      if (row.userId === userId && !row.revokedAt) row.revokedAt = new Date();
    }
  }
}

async function freshService(repo: IRefreshTokenRepository = new InMemoryRefreshTokenRepository()) {
  vi.resetModules();
  process.env.NODE_ENV = 'test';
  process.env.JWT_ACCESS_SECRET = ACCESS_SECRET;
  process.env.JWT_REFRESH_SECRET = REFRESH_SECRET;
  const { RealAuthTokenService } = await import('../../../core/auth/real-auth-token.service');
  return new RealAuthTokenService(repo);
}

describe('RealAuthTokenService — JWT verification', () => {
  beforeEach(() => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
    process.env.JWT_ACCESS_SECRET = ACCESS_SECRET;
    process.env.JWT_REFRESH_SECRET = REFRESH_SECRET;
  });

  it('accepts a validly-signed, unexpired token and extracts the identity', async () => {
    const service = await freshService();
    const token = jwt.sign({ userId: 'user-123', roles: ['seller'] }, ACCESS_SECRET, {
      algorithm: 'HS256',
      expiresIn: '15m',
    });
    const payload = await service.verifyAccessToken(token);
    expect(payload).toEqual({ userId: 'user-123', roles: ['seller'] });
  });

  it('rejects an expired token', async () => {
    const service = await freshService();
    const token = jwt.sign({ userId: 'user-123', roles: ['seller'] }, ACCESS_SECRET, {
      algorithm: 'HS256',
      expiresIn: '-10s',
    });
    await expect(service.verifyAccessToken(token)).rejects.toThrow(/expired/i);
  });

  it('rejects a token signed with the wrong secret (invalid signature)', async () => {
    const service = await freshService();
    const token = jwt.sign({ userId: 'user-123', roles: ['seller'] }, 'wrong-secret-entirely', {
      algorithm: 'HS256',
      expiresIn: '15m',
    });
    await expect(service.verifyAccessToken(token)).rejects.toThrow(/invalid/i);
  });

  it('rejects a malformed (non-JWT) token string', async () => {
    const service = await freshService();
    await expect(service.verifyAccessToken('not-a-jwt-at-all')).rejects.toThrow(/invalid/i);
  });

  it('rejects an empty token string', async () => {
    const service = await freshService();
    await expect(service.verifyAccessToken('')).rejects.toThrow();
  });

  it('rejects a token whose payload is missing userId even if the signature is valid', async () => {
    const service = await freshService();
    const token = jwt.sign({ roles: ['seller'] }, ACCESS_SECRET, { algorithm: 'HS256', expiresIn: '15m' });
    await expect(service.verifyAccessToken(token)).rejects.toThrow(/invalid token payload/i);
  });

  it('rejects an alg:none token (algorithm confusion attempt)', async () => {
    const service = await freshService();
    const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
    const payload = Buffer.from(JSON.stringify({ userId: 'attacker', roles: ['admin'] })).toString('base64url');
    const forgedToken = `${header}.${payload}.`;
    await expect(service.verifyAccessToken(forgedToken)).rejects.toThrow(/invalid/i);
  });

  it('rejects a token signed with a different (but otherwise valid) algorithm — HS384 instead of the pinned HS256', async () => {
    const service = await freshService();
    const token = jwt.sign({ userId: 'user-123', roles: ['seller'] }, ACCESS_SECRET, {
      algorithm: 'HS384',
      expiresIn: '15m',
    });
    await expect(service.verifyAccessToken(token)).rejects.toThrow(/invalid/i);
  });

  it('never includes the actual secret value in any thrown error message', async () => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
    delete process.env.JWT_ACCESS_SECRET;
    delete process.env.JWT_REFRESH_SECRET;
    const { RealAuthTokenService } = await import('../../../core/auth/real-auth-token.service');
    try {
      new RealAuthTokenService(new InMemoryRefreshTokenRepository());
      expect.unreachable('should have thrown');
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      expect(message).not.toContain(ACCESS_SECRET);
      expect(message).not.toContain(REFRESH_SECRET);
    }
  });

  it('constructor throws if JWT secrets are not configured', async () => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
    delete process.env.JWT_ACCESS_SECRET;
    delete process.env.JWT_REFRESH_SECRET;
    const { RealAuthTokenService } = await import('../../../core/auth/real-auth-token.service');
    expect(() => new RealAuthTokenService(new InMemoryRefreshTokenRepository())).toThrow(/JWT_ACCESS_SECRET/);
  });
});

describe('RealAuthTokenService — refresh token persistence, rotation, replay detection', () => {
  beforeEach(() => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
    process.env.JWT_ACCESS_SECRET = ACCESS_SECRET;
    process.env.JWT_REFRESH_SECRET = REFRESH_SECRET;
  });

  it('issueTokenPair persists the new refresh token hash (never the raw token) via the repository', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const storeSpy = vi.spyOn(repo, 'store');
    const service = await freshService(repo);
    const { refreshToken } = await service.issueTokenPair({ userId: 'user-456', roles: ['customer'] });

    expect(storeSpy).toHaveBeenCalledTimes(1);
    const [storedHash, storedUserId] = storeSpy.mock.calls[0];
    expect(storedHash).not.toBe(refreshToken); // hashed, not raw
    expect(storedUserId).toBe('user-456');
  });

  it('rotateRefreshToken succeeds for a valid, unrevoked, unexpired stored token — and revokes the old one', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const service = await freshService(repo);
    const { refreshToken } = await service.issueTokenPair({ userId: 'user-456', roles: ['customer'] });

    const rotated = await service.rotateRefreshToken(refreshToken);
    expect(rotated.accessToken).toBeDefined();
    expect(rotated.refreshToken).toBeDefined();
    expect(rotated.refreshToken).not.toBe(refreshToken);

    await expect(service.rotateRefreshToken(refreshToken)).rejects.toThrow(/already been used/i);
  });

  it('rejects rotation of an unknown token (cryptographically valid but never persisted)', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const service = await freshService(repo);
    const neverStoredToken = jwt.sign({ userId: 'ghost-user', roles: [] }, REFRESH_SECRET, {
      algorithm: 'HS256',
      expiresIn: '30d',
    });
    await expect(service.rotateRefreshToken(neverStoredToken)).rejects.toThrow(/invalid refresh token/i);
  });

  it('rejects rotation of an expired stored token (DB expires_at in the past) even if the JWT itself has not expired yet', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const service = await freshService(repo);
    const token = jwt.sign({ userId: 'user-789', roles: [] }, REFRESH_SECRET, {
      algorithm: 'HS256',
      expiresIn: '1h',
    });
    const { hashRefreshToken } = await import('../../../core/auth/postgres-refresh-token.repository');
    await repo.store(hashRefreshToken(token), 'user-789', new Date(Date.now() - 1000));

    await expect(service.rotateRefreshToken(token)).rejects.toThrow(/expired/i);
  });

  it('replaying an already-rotated (revoked) refresh token revokes the entire session for that user', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const revokeAllSpy = vi.spyOn(repo, 'revokeAllForUser');
    const service = await freshService(repo);

    const { refreshToken: firstToken } = await service.issueTokenPair({ userId: 'user-999', roles: ['seller'] });
    await service.rotateRefreshToken(firstToken);

    await expect(service.rotateRefreshToken(firstToken)).rejects.toThrow(/already been used/i);
    expect(revokeAllSpy).toHaveBeenCalledWith('user-999');
  });

  it('revokeRefreshToken marks the token revoked via the repository rather than throwing', async () => {
    const repo = new InMemoryRefreshTokenRepository();
    const revokeSpy = vi.spyOn(repo, 'revoke');
    const service = await freshService(repo);
    const { refreshToken } = await service.issueTokenPair({ userId: 'user-111', roles: [] });

    await service.revokeRefreshToken(refreshToken);
    expect(revokeSpy).toHaveBeenCalledTimes(1);

    await expect(service.rotateRefreshToken(refreshToken)).rejects.toThrow(/already been used/i);
  });

  it('fails closed (propagates the error) rather than granting rotation when the repository throws (e.g. a database error)', async () => {
    const failingRepo: IRefreshTokenRepository = {
      store: async () => undefined,
      findByHash: async () => {
        throw new Error('connection terminated unexpectedly');
      },
      revoke: async () => undefined,
      revokeAllForUser: async () => undefined,
    };
    const service = await freshService(failingRepo);
    const token = jwt.sign({ userId: 'user-222', roles: [] }, REFRESH_SECRET, {
      algorithm: 'HS256',
      expiresIn: '30d',
    });
    await expect(service.rotateRefreshToken(token)).rejects.toThrow(/connection terminated/);
  });
});
