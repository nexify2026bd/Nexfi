import { IAuthTokenService, TokenPayload } from './auth.ports';

/**
 * Day 11 STEP 2/4: no real JWT/Firebase infrastructure exists anywhere in this
 * repository (re-confirmed this round — no signing key, no Firebase Admin SDK, no
 * verification library, no auth config). Per the explicit "do not fabricate
 * authentication" / "do not use a fake JWT verifier" instructions, this class does
 * NOT perform cryptographic verification of any kind.
 *
 * What changed from the Day 10 inline stub: the fixed-identity behavior now sits
 * behind the real IAuthTokenService contract and is resolved through DI (see
 * authenticate.middleware.ts), rather than being hardcoded directly inside the
 * middleware function body. This is an architecture/wiring improvement, NOT a step
 * toward "more real" authentication — verifyAccessToken still does not check the
 * token's signature, issuer, or expiry, because there is nothing real to check it
 * against. issueTokenPair/rotateRefreshToken/revokeRefreshToken are deliberately left
 * unimplemented (throw) rather than faked, since NEXFIY's authenticate middleware only
 * ever calls verifyAccessToken — implementing the others with fake logic would invite
 * accidental use elsewhere and create false confidence.
 *
 * Defense in depth: this constructor carries its own production guard, independent of
 * the one in authenticate.middleware.ts, so this class can never be instantiated with
 * NODE_ENV=production even if imported directly from somewhere other than that
 * middleware in the future.
 */
export class StubAuthTokenService implements IAuthTokenService {
  constructor() {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        'FATAL: StubAuthTokenService performs no real token verification and must never be ' +
          'instantiated with NODE_ENV=production. Implement IAuthTokenService against a real ' +
          'provider (Firebase Admin SDK + signed JWT verification, per Day 3 §2) first.',
      );
    }
  }

  async verifyAccessToken(_token: string): Promise<TokenPayload> {
    // NOT real verification — see class doc comment. The token string itself is
    // deliberately ignored: this is exactly what "arbitrary Bearer token → one
    // hardcoded identity" means, and it must never run in production (enforced above
    // and by the guard in authenticate.middleware.ts).
    return { userId: 'stub-resolved-by-day3-jwt-service', roles: ['seller'] };
  }

  async issueTokenPair(): Promise<{ accessToken: string; refreshToken: string }> {
    throw new Error('StubAuthTokenService.issueTokenPair is not implemented — no real token issuance exists.');
  }

  async rotateRefreshToken(): Promise<{ accessToken: string; refreshToken: string }> {
    throw new Error('StubAuthTokenService.rotateRefreshToken is not implemented — no real token issuance exists.');
  }

  async revokeRefreshToken(): Promise<void> {
    throw new Error('StubAuthTokenService.revokeRefreshToken is not implemented — no real token issuance exists.');
  }
}
