import jwt from 'jsonwebtoken';
import { env } from '../config/env.schema';
import { AuthError } from '../errors/error-catalog';
import { IAuthTokenService, TokenPayload } from './auth.ports';
import { IRefreshTokenRepository } from './refresh-token.repository.port';
import { hashRefreshToken } from './postgres-refresh-token.repository';

/**
 * Day 11-13 — real implementation of IAuthTokenService.
 *
 * SCOPE: verifies/issues NEXFIY's OWN JWTs (Day 3 §2.2-2.4), the token this middleware
 * actually checks on every request. Firebase Admin SDK verification remains a separate,
 * not-yet-built concern (Day 3 §2.4 steps 1-2) — see the Day 13 report.
 *
 * Real cryptographic guarantees: HMAC-SHA256, algorithm pinned, expiry enforced,
 * payload shape validated after verification (see verifyAndExtract).
 *
 * UPDATED (Day 13): refresh-token rotation/revocation is now backed by a real
 * IRefreshTokenRepository (identity.refresh_tokens, Day 2 §1) — the token hash (never
 * the raw token) is what's persisted. rotateRefreshToken now detects replay of an
 * already-rotated token and revokes the entire session for that user (Day 3 §2.3), not
 * just the resubmitted token. This is real logic against real SQL, verified by
 * inspection and mocked-pool unit tests — not a live database run (no DB access here).
 */
export class RealAuthTokenService implements IAuthTokenService {
  constructor(private readonly refreshTokens: IRefreshTokenRepository) {
    if (!env.JWT_ACCESS_SECRET || !env.JWT_REFRESH_SECRET) {
      throw new Error(
        'FATAL: RealAuthTokenService requires JWT_ACCESS_SECRET and JWT_REFRESH_SECRET to be set. ' +
          'These are validated by env.schema.ts in production, but this constructor guards against ' +
          'direct instantiation with missing config in any environment.',
      );
    }
  }

  async issueTokenPair(payload: TokenPayload): Promise<{ accessToken: string; refreshToken: string }> {
    const accessToken = jwt.sign({ userId: payload.userId, roles: payload.roles }, env.JWT_ACCESS_SECRET, {
      algorithm: 'HS256',
      expiresIn: env.JWT_ACCESS_EXPIRY,
    });
    const refreshToken = jwt.sign({ userId: payload.userId, roles: payload.roles }, env.JWT_REFRESH_SECRET, {
      algorithm: 'HS256',
      expiresIn: env.JWT_REFRESH_EXPIRY,
    });

    const decoded = jwt.decode(refreshToken) as jwt.JwtPayload;
    const expiresAt = new Date((decoded.exp ?? 0) * 1000);
    await this.refreshTokens.store(hashRefreshToken(refreshToken), payload.userId, expiresAt);

    return { accessToken, refreshToken };
  }

  async verifyAccessToken(token: string): Promise<TokenPayload> {
    return this.verifyAndExtract(token, env.JWT_ACCESS_SECRET);
  }

  async rotateRefreshToken(oldToken: string): Promise<{ accessToken: string; refreshToken: string }> {
    // Real cryptographic verification first — a refresh token that isn't validly
    // signed by us is rejected before any database round-trip.
    const payload = this.verifyAndExtract(oldToken, env.JWT_REFRESH_SECRET);

    const tokenHash = hashRefreshToken(oldToken);
    const stored = await this.refreshTokens.findByHash(tokenHash);

    if (!stored) {
      // Cryptographically valid but never persisted (or its row was deleted) — treat
      // as invalid rather than trusting the JWT claim alone; the database record is
      // the actual source of truth for whether this session is still live.
      throw new AuthError('Invalid refresh token');
    }
    if (stored.revokedAt) {
      // REPLAY of an already-rotated/revoked token — per Day 3 §2.3 this is a signal
      // of possible token theft (an attacker replaying a token the legitimate client
      // already rotated past). Correct response: burn the entire session, not just
      // this one token, then reject the request.
      await this.refreshTokens.revokeAllForUser(stored.userId);
      throw new AuthError('Refresh token has already been used — session revoked');
    }
    if (stored.expiresAt.getTime() < Date.now()) {
      throw new AuthError('Refresh token has expired');
    }

    await this.refreshTokens.revoke(tokenHash);
    return this.issueTokenPair(payload);
  }

  async revokeRefreshToken(token: string): Promise<void> {
    await this.refreshTokens.revoke(hashRefreshToken(token));
  }

  private verifyAndExtract(token: string, secret: string): TokenPayload {
    let decoded: string | jwt.JwtPayload;
    try {
      decoded = jwt.verify(token, secret, { algorithms: ['HS256'] });
    } catch (err) {
      if (err instanceof jwt.TokenExpiredError) {
        throw new AuthError('Token has expired');
      }
      if (err instanceof jwt.JsonWebTokenError) {
        // Covers malformed tokens, invalid signature, wrong algorithm, and similar —
        // jsonwebtoken intentionally doesn't distinguish these further to avoid giving
        // an attacker a signature-validity oracle.
        throw new AuthError('Invalid token');
      }
      throw new AuthError('Token verification failed');
    }

    if (typeof decoded === 'string') {
      throw new AuthError('Invalid token payload');
    }
    const { userId, roles } = decoded as Record<string, unknown>;
    if (typeof userId !== 'string' || userId.length === 0) {
      throw new AuthError('Invalid token payload');
    }
    if (!Array.isArray(roles) || !roles.every((r) => typeof r === 'string')) {
      throw new AuthError('Invalid token payload');
    }

    return { userId, roles };
  }
}
