import { NextFunction, Request, Response } from 'express';
import { AuthError } from '../errors/error-catalog';
import { setContextUserId } from '../logger/request-context';
import { container } from '../di/container';
import { env } from '../config/env.schema';
import { IAuthTokenService } from './auth.ports';
import { StubAuthTokenService } from './stub-auth-token.service';
import { RealAuthTokenService } from './real-auth-token.service';
import { PostgresRefreshTokenRepository } from './postgres-refresh-token.repository';

/**
 * Day 3 §2.4 authenticate middleware — verifies the bearer token via a DI-resolved
 * IAuthTokenService (Day 3 §2.2, typed in ./auth.ports.ts) and attaches req.identity.
 *
 * Production resolves to RealAuthTokenService (real JWT verification, Day 11; real
 * refresh-token persistence/rotation/replay-detection against identity.refresh_tokens,
 * Day 13). StubAuthTokenService is registered ONLY outside production.
 *
 * env.schema.ts fails fast in production if JWT_ACCESS_SECRET/JWT_REFRESH_SECRET are
 * missing or weak (before this file's module-level code below even runs, since it
 * imports `env`), and RealAuthTokenService's own constructor re-checks the secrets as
 * defense in depth. There is no code path left that lets NODE_ENV=production silently
 * fall back to the stub identity.
 */
container.registerSingleton<IAuthTokenService>('IAuthTokenService', () =>
  env.NODE_ENV === 'production'
    ? new RealAuthTokenService(new PostgresRefreshTokenRepository())
    : new StubAuthTokenService(),
);

export function authenticate(req: Request, _res: Response, next: NextFunction): void {
  const header = req.header('authorization');
  if (!header?.startsWith('Bearer ')) {
    throw new AuthError('Missing or malformed Authorization header');
  }
  const token = header.slice('Bearer '.length).trim();
  if (token.length === 0) {
    throw new AuthError('Missing or malformed Authorization header');
  }

  const authTokenService = container.resolve<IAuthTokenService>('IAuthTokenService');
  authTokenService
    .verifyAccessToken(token)
    .then((payload) => {
      req.identity = payload;
      setContextUserId(payload.userId);
      next();
    })
    .catch((err) => next(err instanceof AuthError ? err : new AuthError('Invalid token')));
}
