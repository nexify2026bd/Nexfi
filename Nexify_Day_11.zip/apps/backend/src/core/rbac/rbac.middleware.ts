import { NextFunction, Request, Response } from 'express';
import { ForbiddenError } from '../errors/error-catalog';
import { container } from '../di/container';
import { env } from '../config/env.schema';
import { IPermissionService } from './permission.service.port';
import { StubPermissionService } from './stub-permission.service';
import { PostgresPermissionService } from './postgres-permission.service';
import { RedisCachedPermissionService } from './redis-cached-permission.service';

/**
 * Day 3 §3.4 — route guard. Resolves the actor's flattened permission set and rejects
 * with 403 if the required permission is absent.
 *
 * Production resolves to RedisCachedPermissionService wrapping PostgresPermissionService
 * (Day 13 — the Day 3 §3.2 cache layer, previously absent). A Redis outage degrades to
 * hitting Postgres directly on every request (see RedisCachedPermissionService doc
 * comment) — it never grants access and never fails the request. StubPermissionService
 * is registered ONLY outside production.
 */
container.registerSingleton<IPermissionService>('IPermissionService', () =>
  env.NODE_ENV === 'production'
    ? new RedisCachedPermissionService(new PostgresPermissionService())
    : new StubPermissionService(),
);

export function requirePermission(permission: string) {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    // Day 11 audit fix: this handler is `async`, and Express 4 (unlike 5) does NOT
    // automatically catch a rejected promise from an async middleware — a bare `throw`
    // here would become an unhandled rejection instead of reaching the global error
    // handler, hanging the request instead of returning 403. This was a real,
    // pre-existing bug (present since the original Day 4 stub) that no prior test ever
    // exercised, because every earlier test either hit the success path or failed at
    // `authenticate` first. Writing a dedicated deny-branch test for this middleware
    // (STEP 10 item 6) is what surfaced it. Fixed the same way product.controller.ts
    // already handles it: explicit try/catch, next(err).
    try {
      const identity = req.identity;
      if (!identity) throw new ForbiddenError('No authenticated identity on request');

      const permissionService = container.resolve<IPermissionService>('IPermissionService');
      const granted = await permissionService.getPermissionsForUser(identity.userId);
      if (!granted.includes(permission)) {
        throw new ForbiddenError(`Missing required permission: ${permission}`);
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}
