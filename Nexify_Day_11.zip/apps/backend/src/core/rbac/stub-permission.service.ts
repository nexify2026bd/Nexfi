import { IPermissionService } from './permission.service.port';

/**
 * Day 11 STEP 5: no real identity.roles/role_permissions query infrastructure exists in
 * this repository (Day 2's schema for it is a markdown document, not a live database
 * this code connects to). This stub preserves the exact Day 4–10 behavior — every
 * authenticated user is granted all five Product permissions — but now sits behind the
 * IPermissionService contract and is resolved through DI, instead of being a hardcoded
 * array literal inline in the middleware.
 *
 * This is NOT real RBAC. It does not distinguish between users, roles, or the actual
 * grants recorded in identity.user_roles/role_permissions. A real implementation would
 * be a PostgresPermissionRepository (read pool, per Day 2 §17) wrapped in a
 * Redis-cached IPermissionService (Day 3 §3.2), swapped in behind this same interface.
 *
 * Defense in depth: this constructor carries its own production guard, independent of
 * the one in rbac.middleware.ts.
 */
export class StubPermissionService implements IPermissionService {
  constructor() {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        'FATAL: StubPermissionService grants all permissions to every user unconditionally ' +
          'and must never be instantiated with NODE_ENV=production. Implement IPermissionService ' +
          'against real identity.user_roles/role_permissions data (Day 2 §1) first.',
      );
    }
  }

  async getPermissionsForUser(_userId: string): Promise<string[]> {
    // NOT a real lookup — every user gets the same fixed set. See class doc comment.
    return ['product.create', 'product.read', 'product.update', 'product.publish', 'product.archive'];
  }
}
