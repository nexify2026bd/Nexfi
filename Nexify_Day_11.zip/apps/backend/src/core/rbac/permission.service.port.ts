/**
 * Day 11 STEP 5: typed contract for real RBAC permission resolution — the missing
 * infrastructure piece Day 10 found (rbac.middleware.ts previously granted every
 * identity all permissions unconditionally, with no lookup at all).
 *
 * Shape matches the Day 2 database architecture document's actual schema
 * (identity.user_roles → identity.roles → identity.role_permissions →
 * identity.permissions, flattened into a permission-code set per user) — but that
 * schema exists only as a markdown document in this repository, not as a live,
 * queryable database. No IPermissionService implementation backed by a real
 * repository/cache exists here; only this interface and a clearly-labeled stub.
 */
export interface IPermissionService {
  /** Returns the flattened set of permission codes granted to a user, per Day 3 §3.2
   *  (real implementation would be Redis-cached, resolved from Day 2's
   *  identity.user_roles/role_permissions tables on cache miss). */
  getPermissionsForUser(userId: string): Promise<string[]>;
}
