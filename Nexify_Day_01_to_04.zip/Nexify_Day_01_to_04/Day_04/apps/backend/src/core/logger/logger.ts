/**
 * Structured logger (Day 3 §11.1). Thin wrapper so modules never import
 * a concrete logging library directly — keeps the vendor swappable.
 */
type LogFields = Record<string, unknown>;

function emit(level: string, fields: LogFields, message: string): void {
  // eslint-disable-next-line no-console -- replaced by Pino transport in real deployment
  console.log(JSON.stringify({ level, message, timestamp: new Date().toISOString(), ...fields }));
}

export const logger = {
  info: (fields: LogFields, message: string) => emit('info', fields, message),
  warn: (fields: LogFields, message: string) => emit('warn', fields, message),
  error: (fields: LogFields, message: string) => emit('error', fields, message),
  debug: (fields: LogFields, message: string) => emit('debug', fields, message),
};
