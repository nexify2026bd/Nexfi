import { AsyncLocalStorage } from 'node:async_hooks';
import { randomUUID } from 'node:crypto';
import { NextFunction, Request, Response } from 'express';

interface RequestContextData {
  requestId: string;
  userId?: string;
}

const storage = new AsyncLocalStorage<RequestContextData>();

/** Day 3 §5.4 step 1 — correlation ID generation/propagation, no manual passing required. */
export function requestContext(req: Request, res: Response, next: NextFunction): void {
  const requestId = (req.header('x-request-id') as string) || randomUUID();
  res.setHeader('x-request-id', requestId);
  storage.run({ requestId }, next);
}

export function getRequestId(): string {
  return storage.getStore()?.requestId ?? 'unbound';
}

export function setContextUserId(userId: string): void {
  const store = storage.getStore();
  if (store) store.userId = userId;
}

export function getContextUserId(): string | undefined {
  return storage.getStore()?.userId;
}
