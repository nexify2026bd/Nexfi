import { Response } from 'express';
import { getRequestId } from '../logger/request-context';

/** Day 3 §5.1 — the single, uniform success/error response shape used by every module. */
export function sendSuccess<T>(res: Response, data: T, httpStatus = 200): void {
  res.status(httpStatus).json({
    success: true,
    data,
    meta: { requestId: getRequestId() },
  });
}
