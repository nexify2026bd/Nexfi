import { ValidationError } from '../errors/error-catalog';

/**
 * Cursor (keyset) pagination utilities — Day 3 §5.1 explicitly forbids OFFSET pagination.
 * The cursor is an opaque, base64-encoded pointer built from the last row's sort key(s),
 * never a page number/offset — performance stays O(limit), independent of how deep the
 * caller pages, which is mandatory once `catalog.products` reaches partition-scale volume.
 */
export interface CursorPage<T> {
  items: T[];
  nextCursor: string | null;
  hasMore: boolean;
}

export interface DecodedCursor {
  createdAt: string; // ISO timestamp
  id: string; // UUIDv7 tiebreaker for rows sharing the same createdAt
}

export function encodeCursor(cursor: DecodedCursor): string {
  return Buffer.from(JSON.stringify(cursor)).toString('base64url');
}

/**
 * Day 9 audit fix: previously threw a plain `Error('INVALID_CURSOR')`. Since nothing
 * along the ListProductsQuery → controller path caught and translated it, a malformed
 * or tampered `?cursor=` value (trivial for any client to send) fell through to the
 * global error handler's generic-error branch and was returned as a 500 INTERNAL_ERROR —
 * wrong status for routine bad client input, and it polluted server error logs/alerting
 * with "unexpected error" noise for something that is really a 422 validation failure.
 * This is the one place in the module that hadn't been brought into the domain-error →
 * AppError translation discipline established from Day 5 onward. `core/http/` is a Day 3
 * cross-cutting core file (not domain/), so importing core/errors here is not a boundary
 * violation — the same rule that keeps Domain framework-free doesn't apply to core-to-core.
 */
export function decodeCursor(raw: string): DecodedCursor {
  try {
    const parsed = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    if (typeof parsed.createdAt !== 'string' || typeof parsed.id !== 'string') {
      throw new Error('malformed cursor');
    }
    return parsed;
  } catch {
    throw new ValidationError('Invalid or malformed pagination cursor');
  }
}
