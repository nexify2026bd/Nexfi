/**
 * Base class for all application-level errors (Day 3 §5.5).
 * Every thrown error inside modules MUST extend this class so the
 * global error handler can map it deterministically to an HTTP response.
 */
export abstract class AppError extends Error {
  abstract readonly code: string;
  abstract readonly httpStatus: number;
  readonly details?: unknown[];

  protected constructor(message: string, details?: unknown[]) {
    super(message);
    this.name = new.target.name;
    this.details = details;
    // V8-only extension, not part of the standard ErrorConstructor type — audit fix:
    // cast through `unknown` rather than declaring an ambient global (keeps this file
    // self-contained; @types/node normally supplies this augmentation in a real install).
    const captureStackTrace = (Error as unknown as { captureStackTrace?: (target: object, ctor?: unknown) => void })
      .captureStackTrace;
    captureStackTrace?.(this, new.target);
  }
}
