import { NextFunction, Request, Response } from 'express';
import { AppError } from './app-error.base';
import { InternalError } from './error-catalog';
import { logger } from '../logger/logger';
import { getRequestId } from '../logger/request-context';

/**
 * Last middleware in the chain (Day 3 §5.4/5.5). Maps AppError subclasses to their
 * declared HTTP status; anything else (unexpected/programmer error) is logged in full
 * internally and returned to the client as a generic 500 — never leaking internals.
 */
export function globalErrorHandler(err: unknown, req: Request, res: Response, _next: NextFunction): void {
  const requestId = getRequestId();

  if (err instanceof AppError) {
    if (err.httpStatus >= 500) {
      logger.error({ err, requestId }, 'Unhandled AppError (5xx)');
    } else {
      logger.warn({ code: err.code, message: err.message, requestId }, 'Request rejected');
    }
    res.status(err.httpStatus).json({
      success: false,
      error: { code: err.code, message: err.message, details: err.details ?? [] },
      meta: { requestId },
    });
    return;
  }

  logger.error({ err, requestId }, 'Unexpected error');
  const fallback = new InternalError();
  res.status(fallback.httpStatus).json({
    success: false,
    error: { code: fallback.code, message: fallback.message, details: [] },
    meta: { requestId },
  });
}
