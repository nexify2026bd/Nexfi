/**
 * Day 3 §14 — minimal composition-root container. Real deployments may swap this for
 * tsyringe/inversify; the contract (register/resolve by string token) is what modules
 * code against, so the concrete implementation stays swappable.
 */
type Factory<T> = () => T;

export class Container {
  private registry = new Map<string, Factory<unknown>>();
  private singletons = new Map<string, unknown>();

  registerSingleton<T>(token: string, factory: Factory<T>): void {
    this.registry.set(token, factory);
  }

  resolve<T>(token: string): T {
    if (this.singletons.has(token)) return this.singletons.get(token) as T;
    const factory = this.registry.get(token);
    if (!factory) throw new Error(`No binding registered for token: ${token}`);
    const instance = factory();
    this.singletons.set(token, instance);
    return instance as T;
  }
}

export const container = new Container();
