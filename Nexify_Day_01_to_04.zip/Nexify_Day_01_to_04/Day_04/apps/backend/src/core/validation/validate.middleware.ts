import { NextFunction, Request, Response } from 'express';
import { ZodTypeAny } from 'zod';
import { ValidationError } from '../errors/error-catalog';

type Source = 'body' | 'query' | 'params';

/** Day 3 §5.3 — generic validation middleware; failures never reach the controller. */
export function validate(schema: ZodTypeAny, source: Source = 'body') {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      throw new ValidationError(
        'Request validation failed',
        result.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
      );
    }
    (req as unknown as Record<Source, unknown>)[source] = result.data;
    next();
  };
}
