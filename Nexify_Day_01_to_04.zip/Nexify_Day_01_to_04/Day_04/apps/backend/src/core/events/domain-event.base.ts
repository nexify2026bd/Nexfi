import { randomUUID } from 'node:crypto';

/** Day 3 §8.2/§8.3 — base class every module's domain events extend. */
export abstract class DomainEvent<TPayload> {
  abstract readonly eventName: string;
  readonly occurredAt: Date;
  readonly correlationId: string;
  readonly payload: TPayload;

  protected constructor(payload: TPayload, correlationId: string) {
    this.payload = payload;
    this.correlationId = correlationId;
    this.occurredAt = new Date();
  }
}

export function newCorrelationId(): string {
  return randomUUID();
}
