import { DomainEvent } from './domain-event.base';

export interface IEventBus {
  publish<T>(event: DomainEvent<T>): Promise<void>;
  subscribe<T>(eventName: string, handler: (event: DomainEvent<T>) => Promise<void>): void;
}

/**
 * Day 3 §8.3 — in-process pub/sub for same-pod listeners (e.g. the wildcard
 * AuditTimelineListener, Day 3 §8.6), bridged to Redis/BullMQ for cross-pod delivery
 * by the relay worker described in §8.4. The in-process implementation is sufficient
 * for Day 4's scope (Product module has no other module subscribing yet).
 */
export class InProcessEventBus implements IEventBus {
  private handlers = new Map<string, Array<(event: DomainEvent<unknown>) => Promise<void>>>();

  async publish<T>(event: DomainEvent<T>): Promise<void> {
    const listeners = this.handlers.get(event.eventName) ?? [];
    await Promise.all(listeners.map((h) => h(event)));
  }

  subscribe<T>(eventName: string, handler: (event: DomainEvent<T>) => Promise<void>): void {
    const existing = this.handlers.get(eventName) ?? [];
    existing.push(handler as (event: DomainEvent<unknown>) => Promise<void>);
    this.handlers.set(eventName, existing);
  }
}
