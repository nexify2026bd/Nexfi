import { redisCacheClient } from './redis-client';

export interface ICacheService {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttlSeconds: number): Promise<void>;
  invalidate(key: string): Promise<void>;
  /** SCAN-based, never KEYS — required at Day 2/Day 3's data volume. */
  invalidatePattern(pattern: string): Promise<void>;
}

/** Day 3 §6.2 — Cache-Aside implementation used by every module's cache adapter. */
export class RedisCacheService implements ICacheService {
  async get<T>(key: string): Promise<T | null> {
    const raw = await redisCacheClient.get(key);
    return raw ? (JSON.parse(raw) as T) : null;
  }

  async set<T>(key: string, value: T, ttlSeconds: number): Promise<void> {
    await redisCacheClient.set(key, JSON.stringify(value), 'EX', ttlSeconds);
  }

  async invalidate(key: string): Promise<void> {
    await redisCacheClient.del(key);
  }

  async invalidatePattern(pattern: string): Promise<void> {
    let cursor = '0';
    do {
      const [nextCursor, keys] = await redisCacheClient.scan(cursor, 'MATCH', pattern, 'COUNT', 100);
      cursor = nextCursor;
      if (keys.length > 0) await redisCacheClient.del(...keys);
    } while (cursor !== '0');
  }
}
