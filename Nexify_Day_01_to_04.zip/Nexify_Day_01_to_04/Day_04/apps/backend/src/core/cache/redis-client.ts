import Redis from 'ioredis';
import { env } from '../config/env.schema';

/** Day 3 §6 — cache/session Redis client, isolated from the queue Redis instance. */
export const redisCacheClient = new Redis(env.REDIS_URL, { keyPrefix: '', lazyConnect: true });
