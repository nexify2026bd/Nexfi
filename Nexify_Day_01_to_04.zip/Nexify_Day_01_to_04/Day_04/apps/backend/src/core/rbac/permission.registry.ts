/**
 * Day 3 §3.1 — static catalog of permission codes, validated at boot against
 * identity.permissions (Day 2 §1). Day 4 registers ONLY the Product permissions
 * actually required — no speculative permissions for future modules.
 */
export const PRODUCT_PERMISSIONS = {
  CREATE: 'product.create',
  READ: 'product.read',
  UPDATE: 'product.update',
  PUBLISH: 'product.publish',
  ARCHIVE: 'product.archive',
} as const;

export type ProductPermission = (typeof PRODUCT_PERMISSIONS)[keyof typeof PRODUCT_PERMISSIONS];
