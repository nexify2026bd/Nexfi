/** Augments Express Request with the identity attached by the Day 3 authenticate middleware. */
export interface AuthenticatedIdentity {
  userId: string;
  roles: string[];
}

declare global {
  namespace Express {
    interface Request {
      identity?: AuthenticatedIdentity;
    }
  }
}
export {};
