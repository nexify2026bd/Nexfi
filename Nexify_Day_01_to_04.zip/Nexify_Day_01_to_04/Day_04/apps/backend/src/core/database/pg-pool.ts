import { Pool } from 'pg';
import { env } from '../config/env.schema';

/**
 * Day 3 §4.2 — separate write (primary) and read (replica) pools. Repositories choose
 * explicitly which pool to use per call; there is no implicit fallback to primary for reads.
 */
export const writePool = new Pool({ connectionString: env.DATABASE_URL, max: 20 });
export const readPool = new Pool({ connectionString: env.DATABASE_READ_REPLICA_URL ?? env.DATABASE_URL, max: 20 });
