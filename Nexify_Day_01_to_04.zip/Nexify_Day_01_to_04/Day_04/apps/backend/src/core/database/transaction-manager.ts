import { PoolClient } from 'pg';
import { writePool } from './pg-pool';

export type DbTransaction = PoolClient;

export interface ITransactionManager {
  runInTransaction<T>(work: (trx: DbTransaction) => Promise<T>): Promise<T>;
}

/**
 * Day 3 §4.4 — Unit of Work. Every multi-step write (product row + event_outbox row)
 * runs inside a single Postgres transaction so a crash between steps can never leave
 * a product persisted without its corresponding domain event queued for dispatch.
 */
export class PgTransactionManager implements ITransactionManager {
  async runInTransaction<T>(work: (trx: DbTransaction) => Promise<T>): Promise<T> {
    const client = await writePool.connect();
    try {
      await client.query('BEGIN');
      const result = await work(client);
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }
}
