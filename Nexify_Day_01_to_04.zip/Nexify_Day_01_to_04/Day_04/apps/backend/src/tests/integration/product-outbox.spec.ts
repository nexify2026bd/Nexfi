import { describe, it, expect, vi } from 'vitest';
import { CreateProductCommand } from '../../modules/product/application/commands/create-product.command';
import { ProductDomainService } from '../../modules/product/domain/services/product-domain.service';
import type { IProductRepository } from '../../modules/product/application/ports/product.repository.port';
import type { IProductCache } from '../../modules/product/application/ports/product-cache.port';
import type { ITransactionManager } from '../../core/database/transaction-manager';
import type { IOutboxRepository } from '../../core/events/outbox/transactional-outbox.repository';

/**
 * Day 4 §19 integration scope: verifies the product write and the outbox event write
 * happen inside the SAME transaction, and that a failure in either step rolls back both
 * (no orphaned product row without its event, no orphaned event without its product).
 */
describe('Product write + Outbox transaction (integration)', () => {
  it('writes the product and the outbox event inside a single transaction', async () => {
    const callOrder: string[] = [];
    const repository: IProductRepository = {
      findById: vi.fn(), findBySlug: vi.fn(), findMany: vi.fn(),
      existsBySlug: vi.fn().mockResolvedValue(false),
      save: vi.fn(async () => { callOrder.push('product-save'); }),
    };
    const outbox: IOutboxRepository = {
      append: vi.fn(async () => { callOrder.push('outbox-append'); }),
    };
    const transactionManager: ITransactionManager = {
      runInTransaction: vi.fn(async (work) => {
        callOrder.push('BEGIN');
        const result = await work({} as never);
        callOrder.push('COMMIT');
        return result;
      }),
    };
    const cache: IProductCache = {
      getById: vi.fn(), getBySlug: vi.fn(), setById: vi.fn(), setBySlug: vi.fn(),
      invalidate: vi.fn(), invalidateListCaches: vi.fn(),
    };

    const command = new CreateProductCommand(repository, cache, new ProductDomainService(), transactionManager, outbox);
    await command.execute({ sellerId: 'seller-1', dto: { categoryId: 'c1', title: 'Item', basePrice: 5 } });

    expect(callOrder).toEqual(['BEGIN', 'product-save', 'outbox-append', 'COMMIT']);
  });

  it('rolls back the product write if the outbox append fails', async () => {
    const repository: IProductRepository = {
      findById: vi.fn(), findBySlug: vi.fn(), findMany: vi.fn(),
      existsBySlug: vi.fn().mockResolvedValue(false),
      save: vi.fn().mockResolvedValue(undefined),
    };
    const outbox: IOutboxRepository = { append: vi.fn().mockRejectedValue(new Error('outbox write failed')) };
    let rolledBack = false;
    const transactionManager: ITransactionManager = {
      runInTransaction: vi.fn(async (work) => {
        try {
          return await work({} as never);
        } catch (e) {
          rolledBack = true;
          throw e;
        }
      }),
    };
    const cache: IProductCache = {
      getById: vi.fn(), getBySlug: vi.fn(), setById: vi.fn(), setBySlug: vi.fn(),
      invalidate: vi.fn(), invalidateListCaches: vi.fn(),
    };

    const command = new CreateProductCommand(repository, cache, new ProductDomainService(), transactionManager, outbox);
    await expect(
      command.execute({ sellerId: 'seller-1', dto: { categoryId: 'c1', title: 'Item', basePrice: 5 } }),
    ).rejects.toThrow('outbox write failed');
    expect(rolledBack).toBe(true);
    expect(cache.invalidateListCaches).not.toHaveBeenCalled(); // no cache side-effect on a rolled-back write
  });
});
