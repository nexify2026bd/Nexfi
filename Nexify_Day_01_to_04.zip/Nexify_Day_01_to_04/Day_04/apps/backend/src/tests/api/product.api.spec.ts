import { describe, it, expect, vi, beforeEach } from 'vitest';
import express, { Express } from 'express';
import request from 'supertest';
import { ProductController } from '../../modules/product/presentation/controllers/product.controller';
import { buildProductRoutes } from '../../modules/product/presentation/routes/product.routes';
import { globalErrorHandler } from '../../core/errors/global-error-handler';
import { requestContext } from '../../core/logger/request-context';
import { NotFoundError } from '../../core/errors/error-catalog';

/**
 * Day 4 §19 API-level tests. Auth/RBAC middlewares are the real Day 3 stubs (core/auth,
 * core/rbac) — this test exercises the actual middleware chain, not a bypassed shortcut.
 */
function buildApp(controller: ProductController): Express {
  const app = express();
  app.use(express.json());
  app.use(requestContext);
  app.use('/api/v1', buildProductRoutes(controller));
  app.use(globalErrorHandler);
  return app;
}

function stubController(overrides: Partial<ProductController> = {}): ProductController {
  const base = {
    create: (req: any, res: any) => res.status(201).json({ success: true, data: { id: 'p1' }, meta: {} }),
    getById: (req: any, res: any) => res.status(200).json({ success: true, data: { id: req.params.id }, meta: {} }),
    list: (req: any, res: any) => res.status(200).json({ success: true, data: { items: [], nextCursor: null }, meta: {} }),
    update: (req: any, res: any) => res.status(200).json({ success: true, data: { id: req.params.id }, meta: {} }),
    publish: (req: any, res: any) => res.status(200).json({ success: true, data: { status: 'pending_approval' }, meta: {} }),
    archive: (req: any, res: any) => res.status(200).json({ success: true, data: { status: 'archived' }, meta: {} }),
    ...overrides,
  };
  return base as unknown as ProductController;
}

describe('Product API', () => {
  it('GET /products/:id returns the envelope with the product data', async () => {
    const app = buildApp(stubController());
    const res = await request(app).get('/api/v1/products/018f2c9e-1a2b-7c3d-8e4f-1234567890ab');
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });

  it('GET /products/:id rejects a malformed UUID with 422 VALIDATION_ERROR', async () => {
    const app = buildApp(stubController());
    const res = await request(app).get('/api/v1/products/not-a-uuid');
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('GET /products supports cursor pagination query params', async () => {
    const app = buildApp(stubController());
    const res = await request(app).get('/api/v1/products?limit=10');
    expect(res.status).toBe(200);
  });

  it('POST /products without an Authorization header returns 401', async () => {
    const app = buildApp(stubController());
    const res = await request(app).post('/api/v1/products').send({ categoryId: 'x', title: 'y', basePrice: 1 });
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('UNAUTHORIZED');
  });

  it('POST /products with a bearer token and valid body succeeds through the full middleware chain', async () => {
    const app = buildApp(stubController());
    const res = await request(app)
      .post('/api/v1/products')
      .set('Authorization', 'Bearer stub-token')
      .send({ categoryId: '018f2c9e-1a2b-7c3d-8e4f-1234567890ab', title: 'A Nice Item', basePrice: 19.99 });
    expect(res.status).toBe(201);
  });

  it('POST /products with an invalid body returns 422 before reaching the controller', async () => {
    const app = buildApp(stubController({
      create: () => { throw new Error('controller should not be reached on validation failure'); },
    }));
    const res = await request(app)
      .post('/api/v1/products')
      .set('Authorization', 'Bearer stub-token')
      .send({ title: 'x' }); // missing categoryId/basePrice
    expect(res.status).toBe(422);
  });

  it('propagates NotFoundError from the controller into a 404 envelope with no stack trace leak', async () => {
    const app = buildApp(
      stubController({ getById: (_req: any, _res: any, next: any) => next(new NotFoundError('PRODUCT_NOT_FOUND', 'not found')) }),
    );
    const res = await request(app).get('/api/v1/products/018f2c9e-1a2b-7c3d-8e4f-1234567890ab');
    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe('PRODUCT_NOT_FOUND');
    expect(res.body.error).not.toHaveProperty('stack');
  });
});
