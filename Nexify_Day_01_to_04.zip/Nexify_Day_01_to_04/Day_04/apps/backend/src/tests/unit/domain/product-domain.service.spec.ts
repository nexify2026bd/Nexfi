import { describe, it, expect } from 'vitest';
import { ProductDomainService } from '../../../modules/product/domain/services/product-domain.service';
import { InvalidProductDataError } from '../../../modules/product/domain/errors/product.errors';

describe('ProductDomainService.generateSlugCandidate', () => {
  const service = new ProductDomainService();

  it('normalizes a well-formed title into a URL-safe slug', () => {
    expect(service.generateSlugCandidate('Nice  Running   Shoes!')).toBe('nice-running-shoes');
  });

  it('strips diacritics', () => {
    expect(service.generateSlugCandidate('Café Déjà Vu')).toBe('cafe-deja-vu');
  });

  it('collapses repeated separators and trims leading/trailing hyphens', () => {
    expect(service.generateSlugCandidate('  -- Hello -- World --  ')).toBe('hello-world');
  });

  // Day 9 audit regression: previously returned '' silently for this input.
  it('throws InvalidProductDataError for an all-symbol title that would produce an empty slug', () => {
    expect(() => service.generateSlugCandidate('!!! ??? ###')).toThrow(InvalidProductDataError);
  });

  it('throws InvalidProductDataError for a title that is only whitespace', () => {
    expect(() => service.generateSlugCandidate('     ')).toThrow(InvalidProductDataError);
  });
});
