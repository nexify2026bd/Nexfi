import { describe, it, expect } from 'vitest';
import { Product } from '../../../modules/product/domain/entities/product.entity';
import { ProductId } from '../../../modules/product/domain/value-objects/product-id.vo';
import { Money } from '../../../modules/product/domain/value-objects/money.vo';
import { InvalidProductStateTransitionError, InvalidProductDataError } from '../../../modules/product/domain/errors/product.errors';

const validId = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';

function makeProduct() {
  return Product.create({
    id: ProductId.from(validId),
    sellerId: 'seller-1',
    categoryId: 'category-1',
    brandId: null,
    title: 'Test Product',
    slug: 'test-product',
    description: 'A test product',
    basePrice: Money.from(100.5),
  });
}

describe('Product entity', () => {
  it('creates a product in draft status with version 1', () => {
    const product = makeProduct();
    expect(product.status.value).toBe('draft');
    expect(product.version).toBe(1);
  });

  it('rejects invalid product data at the value-object boundary with a domain-native error (no core/ dependency)', () => {
    expect(() => Money.from(-5)).toThrow(InvalidProductDataError);
    expect(() => Money.from(10.999)).toThrow(InvalidProductDataError); // more than 2 decimal places
    expect(() => ProductId.from('not-a-uuid')).toThrow(InvalidProductDataError);
  });

  it('allows draft → pending_approval (publish) transition', () => {
    const product = makeProduct();
    product.submitForApproval();
    expect(product.status.value).toBe('pending_approval');
    expect(product.version).toBe(2);
  });

  it('allows draft → archived transition directly', () => {
    const product = makeProduct();
    product.archive();
    expect(product.status.value).toBe('archived');
  });

  it('rejects archived → pending_approval (invalid transition) with the domain-native error', () => {
    const product = makeProduct();
    product.archive();
    expect(() => product.submitForApproval()).toThrow(InvalidProductStateTransitionError);
  });

  it('rejects updating an archived product with the domain-native error', () => {
    const product = makeProduct();
    product.archive();
    expect(() => product.updateDetails({ title: 'New title' })).toThrow(InvalidProductStateTransitionError);
  });

  it('isOwnedBy correctly identifies the owning seller', () => {
    const product = makeProduct();
    expect(product.isOwnedBy('seller-1')).toBe(true);
    expect(product.isOwnedBy('seller-2')).toBe(false);
  });
});
