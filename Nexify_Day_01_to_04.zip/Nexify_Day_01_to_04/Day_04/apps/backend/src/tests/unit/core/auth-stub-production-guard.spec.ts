import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

/**
 * UPDATED (Day 13): production dependency resolution now also requires Firebase config
 * (env.schema.ts) since FirebaseIdentityProvider is registered in the auth module.
 * Verifies production resolves to REAL implementations (never the stub identity /
 * unconditional-grant behavior), and still fails fast when config is missing.
 */
const VALID_JWT = {
  JWT_ACCESS_SECRET: 'test-access-secret-not-a-real-production-value',
  JWT_REFRESH_SECRET: 'test-refresh-secret-not-a-real-production-value',
};
const VALID_FIREBASE = {
  FIREBASE_PROJECT_ID: 'example-not-a-real-project',
  FIREBASE_CLIENT_EMAIL: 'example@example-not-a-real-project.iam.gserviceaccount.com',
  FIREBASE_PRIVATE_KEY: 'example-not-a-real-private-key',
};
const VALID_DB = {
  DATABASE_URL: 'postgres://example-not-a-real-credential/db',
  REDIS_URL: 'redis://example-not-a-real-credential:6379',
};

describe('production dependency resolution', () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
    process.env = { ...originalEnv };
  });

  afterEach(() => {
    process.env = { ...originalEnv };
  });

  it('authenticate.middleware.ts resolves IAuthTokenService to RealAuthTokenService (not the stub) when NODE_ENV=production and all required config is set', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_JWT, VALID_FIREBASE);

    const { container } = await import('../../../core/di/container');
    const { RealAuthTokenService } = await import('../../../core/auth/real-auth-token.service');
    await import('../../../core/auth/authenticate.middleware');

    const resolved = container.resolve('IAuthTokenService');
    expect(resolved).toBeInstanceOf(RealAuthTokenService);
  });

  it('authenticate.middleware.ts resolves IAuthTokenService to StubAuthTokenService outside production', async () => {
    process.env.NODE_ENV = 'test';
    const { container } = await import('../../../core/di/container');
    const { StubAuthTokenService } = await import('../../../core/auth/stub-auth-token.service');
    await import('../../../core/auth/authenticate.middleware');

    const resolved = container.resolve('IAuthTokenService');
    expect(resolved).toBeInstanceOf(StubAuthTokenService);
  });

  it('importing authenticate.middleware.ts (and therefore env.schema.ts) throws in production when JWT secrets are missing', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_FIREBASE);
    delete process.env.JWT_ACCESS_SECRET;
    delete process.env.JWT_REFRESH_SECRET;

    await expect(import('../../../core/auth/authenticate.middleware')).rejects.toThrow(
      /missing required production environment variable/,
    );
  });

  it('rbac.middleware.ts resolves IPermissionService to RedisCachedPermissionService wrapping PostgresPermissionService (not the stub) when NODE_ENV=production', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_JWT, VALID_FIREBASE);

    const { container } = await import('../../../core/di/container');
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    await import('../../../core/rbac/rbac.middleware');

    const resolved = container.resolve('IPermissionService');
    expect(resolved).toBeInstanceOf(RedisCachedPermissionService);
  });

  it('rbac.middleware.ts resolves IPermissionService to StubPermissionService outside production', async () => {
    process.env.NODE_ENV = 'test';
    const { container } = await import('../../../core/di/container');
    const { StubPermissionService } = await import('../../../core/rbac/stub-permission.service');
    await import('../../../core/rbac/rbac.middleware');

    const resolved = container.resolve('IPermissionService');
    expect(resolved).toBeInstanceOf(StubPermissionService);
  });

  it('auth.module.ts resolves IIdentityProvider to FirebaseIdentityProvider in production and throws without Firebase config', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_JWT, VALID_FIREBASE);
    await import('../../../core/auth/authenticate.middleware'); // registers IAuthTokenService first

    const { container } = await import('../../../core/di/container');
    const { FirebaseIdentityProvider } = await import('../../../core/auth/firebase-identity.provider');
    const { registerAuthModule } = await import('../../../modules/auth/auth.module');
    registerAuthModule(container);

    const resolved = container.resolve('IIdentityProvider');
    expect(resolved).toBeInstanceOf(FirebaseIdentityProvider);
  });
});
