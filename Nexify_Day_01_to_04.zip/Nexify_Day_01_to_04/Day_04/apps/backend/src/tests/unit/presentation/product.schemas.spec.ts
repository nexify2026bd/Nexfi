import { describe, it, expect } from 'vitest';
import {
  CreateProductSchema,
  UpdateProductSchema,
  ProductIdParamsSchema,
} from '../../../modules/product/presentation/validators/product.schemas';

const validUuid = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';

/**
 * Day 6 STEP 11 (security/input hardening) gap-fill: these tests exercise the
 * request-body attack surface directly, independent of the command-level tests —
 * confirms rejection happens at the validation boundary, before any application code runs.
 */
describe('Product Zod schemas — input hardening', () => {
  it('CreateProductSchema rejects an unknown field (e.g. a client attempting to smuggle sellerId)', () => {
    const result = CreateProductSchema.safeParse({
      categoryId: validUuid,
      title: 'Legit Title',
      basePrice: 10,
      sellerId: 'attacker-controlled-seller-id', // must never be accepted from the body
    });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects an unknown "status" field (a client cannot self-approve)', () => {
    const result = CreateProductSchema.safeParse({
      categoryId: validUuid,
      title: 'Legit Title',
      basePrice: 10,
      status: 'approved',
    });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects a negative price', () => {
    const result = CreateProductSchema.safeParse({ categoryId: validUuid, title: 'Item', basePrice: -1 });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects a price with more than 2 decimal places', () => {
    const result = CreateProductSchema.safeParse({ categoryId: validUuid, title: 'Item', basePrice: 9.999 });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects an empty/whitespace-only title', () => {
    const result = CreateProductSchema.safeParse({ categoryId: validUuid, title: '   ', basePrice: 10 });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects an oversized title (over 200 chars)', () => {
    const result = CreateProductSchema.safeParse({ categoryId: validUuid, title: 'x'.repeat(201), basePrice: 10 });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema rejects an oversized description (over 5000 chars)', () => {
    const result = CreateProductSchema.safeParse({
      categoryId: validUuid, title: 'Item', basePrice: 10, description: 'x'.repeat(5001),
    });
    expect(result.success).toBe(false);
  });

  it('UpdateProductSchema rejects an attempt to smuggle an id/productId override', () => {
    const result = UpdateProductSchema.safeParse({ id: validUuid, title: 'New Title' });
    expect(result.success).toBe(false);
  });

  it('UpdateProductSchema rejects an attempt to smuggle a sellerId override', () => {
    const result = UpdateProductSchema.safeParse({ sellerId: 'someone-elses-id', title: 'New Title' });
    expect(result.success).toBe(false);
  });

  it('ProductIdParamsSchema rejects a non-UUID id (e.g. SQL-injection-shaped input)', () => {
    const result = ProductIdParamsSchema.safeParse({ id: "1' OR '1'='1" });
    expect(result.success).toBe(false);
  });

  it('CreateProductSchema accepts a well-formed request with only the documented fields', () => {
    const result = CreateProductSchema.safeParse({
      categoryId: validUuid, title: 'A Valid Product', basePrice: 49.99, description: 'Fine',
    });
    expect(result.success).toBe(true);
  });

  // Day 7 STEP 6/12 — a single realistic mass-assignment attack payload combining every
  // server-controlled field a client might try, in one request (distinct from the
  // individual-field tests above, not a duplicate of them).
  it('CreateProductSchema rejects a combined mass-assignment payload (id/sellerId/status/version/timestamps at once)', () => {
    const result = CreateProductSchema.safeParse({
      categoryId: validUuid,
      title: 'Mass Assignment Attempt',
      basePrice: 10,
      id: validUuid,
      sellerId: 'attacker-seller',
      ownerId: 'attacker-owner',
      status: 'approved',
      version: 999,
      createdAt: '2020-01-01T00:00:00.000Z',
      updatedAt: '2020-01-01T00:00:00.000Z',
      deletedAt: null,
    });
    expect(result.success).toBe(false);
  });
});
