import { describe, it, expect, vi } from 'vitest';
import { GetProductQuery } from '../../../modules/product/application/queries/get-product.query';
import { ListProductsQuery } from '../../../modules/product/application/queries/list-products.query';
import { Product } from '../../../modules/product/domain/entities/product.entity';
import { ProductId } from '../../../modules/product/domain/value-objects/product-id.vo';
import { Money } from '../../../modules/product/domain/value-objects/money.vo';
import { ProductStatus } from '../../../modules/product/domain/value-objects/product-status.vo';
import { NotFoundError } from '../../../core/errors/error-catalog';
import type { IProductRepository } from '../../../modules/product/application/ports/product.repository.port';
import type { IProductCache } from '../../../modules/product/application/ports/product-cache.port';

const validId = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';

function makeProduct() {
  return Product.create({
    id: ProductId.from(validId), sellerId: 'seller-1', categoryId: 'cat-1', brandId: null,
    title: 'A Product', slug: 'a-product', description: null, basePrice: Money.from(10),
  });
}

/** Rehydrates a product already in 'approved' status — mirrors what the repository's
 *  `rowToProduct` would produce from a DB row (Product has no public command that
 *  transitions into 'approved'; that's the future Admin module's job, Day 4 §4). */
function makeApprovedProduct() {
  const draft = makeProduct();
  const props = draft.toProps();
  return Product.rehydrate({ ...props, status: ProductStatus.from('approved') });
}

function noCache(): IProductCache {
  return {
    getById: vi.fn().mockResolvedValue(null), getBySlug: vi.fn(), setById: vi.fn(),
    setBySlug: vi.fn(), invalidate: vi.fn(), invalidateListCaches: vi.fn(),
  };
}

/**
 * Day 7 STEP 12 security-fix regression tests: the public/unauthenticated read path
 * (GET /products, GET /products/:id — no `authenticate` middleware, Day 4 §11 by design)
 * must never expose a draft/pending_approval/rejected/archived product. Locks in the fix
 * for the information-disclosure gap found during this audit.
 */
describe('GetProductQuery — public visibility gate', () => {
  it('returns the product when status is approved', async () => {
    const approvedProduct = makeApprovedProduct();
    const repository: IProductRepository = {
      findById: vi.fn().mockResolvedValue(approvedProduct),
      findBySlug: vi.fn(), findMany: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
    };
    const cache = noCache();
    const query = new GetProductQuery(repository, cache);
    const result = await query.execute(validId);
    expect(result.id).toBe(validId);
    expect(result.status).toBe('approved');
    expect(cache.setById).toHaveBeenCalledTimes(1); // approved products are cached
  });

  it('returns 404 (never the product) for a draft product — no ownership context on this public route', async () => {
    const draftProduct = makeProduct(); // freshly created → status 'draft'
    const repository: IProductRepository = {
      findById: vi.fn().mockResolvedValue(draftProduct),
      findBySlug: vi.fn(), findMany: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
    };
    const cache = noCache();
    const query = new GetProductQuery(repository, cache);
    await expect(query.execute(validId)).rejects.toThrow(NotFoundError);
    expect(cache.setById).not.toHaveBeenCalled(); // never cache a non-public product
  });

  it('returns 404 for a pending_approval product (still not publicly visible)', async () => {
    const product = makeProduct();
    product.submitForApproval();
    const repository: IProductRepository = {
      findById: vi.fn().mockResolvedValue(product),
      findBySlug: vi.fn(), findMany: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
    };
    const query = new GetProductQuery(repository, noCache());
    await expect(query.execute(validId)).rejects.toThrow(NotFoundError);
  });

  it('returns 404 for an archived product', async () => {
    const product = makeProduct();
    product.archive();
    const repository: IProductRepository = {
      findById: vi.fn().mockResolvedValue(product),
      findBySlug: vi.fn(), findMany: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
    };
    const query = new GetProductQuery(repository, noCache());
    await expect(query.execute(validId)).rejects.toThrow(NotFoundError);
  });
});

describe('ListProductsQuery — public visibility gate', () => {
  it('always pins the repository filter to status=approved, even if the caller requests draft', async () => {
    const repository: IProductRepository = {
      findById: vi.fn(), findBySlug: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
      findMany: vi.fn().mockResolvedValue({ items: [], hasMore: false }),
    };
    const query = new ListProductsQuery(repository);
    await query.execute({ filter: { status: 'draft', sellerId: 'competitor-seller' }, limit: 20 });

    expect(repository.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ status: 'approved', sellerId: 'competitor-seller' }),
      null,
      20,
    );
  });

  it('pins status=approved even when the caller supplies no status filter at all', async () => {
    const repository: IProductRepository = {
      findById: vi.fn(), findBySlug: vi.fn(), existsBySlug: vi.fn(), save: vi.fn(),
      findMany: vi.fn().mockResolvedValue({ items: [], hasMore: false }),
    };
    const query = new ListProductsQuery(repository);
    await query.execute({ filter: {}, limit: 20 });
    expect(repository.findMany).toHaveBeenCalledWith(expect.objectContaining({ status: 'approved' }), null, 20);
  });
});
