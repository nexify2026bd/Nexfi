import { Money } from '../../domain/value-objects/money.vo';
import { ProductUpdatedEvent } from '../../domain/events/product-updated.event';
import { IProductRepository } from '../ports/product.repository.port';
import { IProductCache } from '../ports/product-cache.port';
import { UpdateProductDTO } from '../dto/update-product.dto';
import { ProductResponseDTO, toProductResponseDTO } from '../dto/product-response.dto';
import { ITransactionManager } from '../../../../core/database/transaction-manager';
import { IOutboxRepository } from '../../../../core/events/outbox/transactional-outbox.repository';
import { NotFoundError } from '../../../../core/errors/error-catalog';
import { ProductOwnershipViolationError } from '../errors/product-ownership-violation.error';
import { newCorrelationId } from '../../../../core/events/domain-event.base';
import { translateDomainError } from '../errors/translate-domain-error';
import { PolicyEngine } from '../../../../core/rbac/policy.engine';
import { AuthenticatedIdentity } from '../../../../core/types/express';
import { logger } from '../../../../core/logger/logger';
import { getRequestId } from '../../../../core/logger/request-context';

export interface UpdateProductInput {
  productId: string;
  actor: AuthenticatedIdentity;
  dto: UpdateProductDTO;
}

export class UpdateProductCommand {
  constructor(
    private readonly repository: IProductRepository,
    private readonly cache: IProductCache,
    private readonly transactionManager: ITransactionManager,
    private readonly outbox: IOutboxRepository,
    private readonly policyEngine: PolicyEngine,
  ) {}

  async execute(input: UpdateProductInput): Promise<ProductResponseDTO> {
    const product = await this.repository.findById(input.productId);
    if (!product) throw new NotFoundError('PRODUCT_NOT_FOUND', `Product ${input.productId} not found`);

    const allowed = await this.policyEngine.can('product', input.actor, 'update', product);
    if (!allowed) throw new ProductOwnershipViolationError(input.productId);

    try {
      product.updateDetails({
        categoryId: input.dto.categoryId,
        brandId: input.dto.brandId,
        title: input.dto.title,
        description: input.dto.description,
        basePrice: input.dto.basePrice !== undefined ? Money.from(input.dto.basePrice) : undefined,
      });
    } catch (err) {
      translateDomainError(err); // maps domain InvalidProductStateTransitionError → AppError
    }

    const correlationId = newCorrelationId();
    const event = new ProductUpdatedEvent(
      { productId: product.id.toString(), sellerId: product.sellerId },
      correlationId,
    );

    await this.transactionManager.runInTransaction(async (trx) => {
      await this.repository.save(product, trx);
      await this.outbox.append(trx, event);
    });

    const props = product.toProps();
    await this.cache.invalidate(product.id.toString(), product.sellerId, props.slug);

    logger.info(
      { productId: product.id.toString(), sellerId: product.sellerId, requestId: getRequestId() },
      'product.updated',
    );

    return toProductResponseDTO(product);
  }
}
