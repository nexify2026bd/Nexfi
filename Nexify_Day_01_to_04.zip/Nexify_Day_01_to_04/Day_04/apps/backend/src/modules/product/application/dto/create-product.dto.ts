export interface CreateProductDTO {
  categoryId: string;
  brandId?: string | null;
  title: string;
  description?: string | null;
  basePrice: number;
  /** slug is optional client input; if omitted, ProductDomainService derives it from title. */
  slug?: string;
}
