import { Router } from 'express';
import { Container } from '../../core/di/container';
import { policyEngine } from '../../core/rbac/policy.engine';
import { RedisCacheService } from '../../core/cache/cache.service';
import { PgTransactionManager } from '../../core/database/transaction-manager';
import { PgOutboxRepository } from '../../core/events/outbox/transactional-outbox.repository';

import { PostgresProductRepository } from './infrastructure/repositories/postgres-product.repository';
import { RedisProductCache } from './infrastructure/cache/redis-product.cache';
import { ProductDomainService } from './domain/services/product-domain.service';
import { ProductOwnershipPolicy } from './application/policies/product-ownership.policy';

import { CreateProductCommand } from './application/commands/create-product.command';
import { UpdateProductCommand } from './application/commands/update-product.command';
import { PublishProductCommand } from './application/commands/publish-product.command';
import { ArchiveProductCommand } from './application/commands/archive-product.command';
import { GetProductQuery } from './application/queries/get-product.query';
import { ListProductsQuery } from './application/queries/list-products.query';

import { ProductController } from './presentation/controllers/product.controller';
import { buildProductRoutes } from './presentation/routes/product.routes';

/**
 * Day 3 §14/§25 — clean registration interface. Called once from bootstrap.ts.
 * Dependency order matches Day 4 §24: Repository → Cache → DomainService → Commands
 * → Queries → Controller → Routes. Nothing outside this file `new`s a Product class.
 */
export function registerProductModule(container: Container): Router {
  container.registerSingleton('IProductRepository', () => new PostgresProductRepository());
  container.registerSingleton('ICacheService', () => new RedisCacheService());
  container.registerSingleton('IProductCache', () => new RedisProductCache(container.resolve('ICacheService')));
  container.registerSingleton('ProductDomainService', () => new ProductDomainService());
  container.registerSingleton('ITransactionManager', () => new PgTransactionManager());
  container.registerSingleton('IOutboxRepository', () => new PgOutboxRepository());

  // Resource-level authorization (Day 4 §7) — registered against the shared Day 3
  // PolicyEngine. Routed through the container (audit fix: previously instantiated
  // inline with `new`, inconsistent with the "no direct instantiation outside DI" rule).
  container.registerSingleton('ProductOwnershipPolicy', () => new ProductOwnershipPolicy());
  policyEngine.register('product', container.resolve<ProductOwnershipPolicy>('ProductOwnershipPolicy'));

  container.registerSingleton(
    'CreateProductCommand',
    () =>
      new CreateProductCommand(
        container.resolve('IProductRepository'),
        container.resolve('IProductCache'),
        container.resolve('ProductDomainService'),
        container.resolve('ITransactionManager'),
        container.resolve('IOutboxRepository'),
      ),
  );
  container.registerSingleton(
    'UpdateProductCommand',
    () =>
      new UpdateProductCommand(
        container.resolve('IProductRepository'),
        container.resolve('IProductCache'),
        container.resolve('ITransactionManager'),
        container.resolve('IOutboxRepository'),
        policyEngine,
      ),
  );
  container.registerSingleton(
    'PublishProductCommand',
    () =>
      new PublishProductCommand(
        container.resolve('IProductRepository'),
        container.resolve('IProductCache'),
        container.resolve('ITransactionManager'),
        container.resolve('IOutboxRepository'),
        policyEngine,
      ),
  );
  container.registerSingleton(
    'ArchiveProductCommand',
    () =>
      new ArchiveProductCommand(
        container.resolve('IProductRepository'),
        container.resolve('IProductCache'),
        container.resolve('ITransactionManager'),
        container.resolve('IOutboxRepository'),
        policyEngine,
      ),
  );
  container.registerSingleton(
    'GetProductQuery',
    () => new GetProductQuery(container.resolve('IProductRepository'), container.resolve('IProductCache')),
  );
  container.registerSingleton('ListProductsQuery', () => new ListProductsQuery(container.resolve('IProductRepository')));

  container.registerSingleton(
    'ProductController',
    () =>
      new ProductController(
        container.resolve('CreateProductCommand'),
        container.resolve('UpdateProductCommand'),
        container.resolve('PublishProductCommand'),
        container.resolve('ArchiveProductCommand'),
        container.resolve('GetProductQuery'),
        container.resolve('ListProductsQuery'),
      ),
  );

  return buildProductRoutes(container.resolve('ProductController'));
}
