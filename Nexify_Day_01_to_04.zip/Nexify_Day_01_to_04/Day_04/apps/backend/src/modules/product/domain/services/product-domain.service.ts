import { InvalidProductDataError } from '../errors/product.errors';

/**
 * Domain service for cross-entity rules that don't belong on the Product entity itself.
 * Day 4 scope keeps this intentionally small — slug normalization is the only rule that
 * doesn't depend on persistence (uniqueness check is a repository concern, §14 below).
 */
export class ProductDomainService {
  /** URL-safe, normalized slug generation (Day 4 §14). Uniqueness is enforced by the
   *  repository against the DB unique constraint (catalog.products (seller_id, slug), Day 2 §3) —
   *  this method only produces a well-formed candidate, never guarantees uniqueness alone.
   *
   *  Day 9 audit fix: a title made entirely of non-alphanumeric characters (e.g. "!!! ???")
   *  passes both the Zod length check and Product.validateTitle (neither checks content),
   *  but previously collapsed to an EMPTY STRING here — nothing downstream validated the
   *  generated slug before it reached catalog.products.slug, so a degenerate title could
   *  silently persist a broken empty-string slug (and every other symbol-only title from
   *  the same seller would then collide on that same empty slug via the uniqueness check,
   *  surfacing a confusing PRODUCT_SLUG_ALREADY_EXISTS error unrelated to the actual title).
   *  Now raises a domain-native error instead, asking the client to supply an explicit
   *  `slug` for that edge case — the minimal fix, not inventing new fallback-suffix logic. */
  generateSlugCandidate(title: string): string {
    const slug = title
      .toLowerCase()
      .trim()
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '') // strip diacritics
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');

    if (slug.length === 0) {
      throw new InvalidProductDataError(
        'Could not generate a URL slug from the given title — it must contain at least one letter or number. Provide an explicit slug instead.',
      );
    }
    return slug;
  }
}
