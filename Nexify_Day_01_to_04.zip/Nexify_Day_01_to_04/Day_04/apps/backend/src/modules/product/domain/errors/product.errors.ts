/**
 * Domain-native errors — plain Error subclasses with ZERO imports from core/ or any
 * infrastructure package. This is what makes the Domain layer genuinely independent
 * (Day 4 §12 audit requirement: "Domain MUST NOT import ... core infrastructure
 * implementations"). The Application layer catches these and translates them into the
 * Day 3 AppError catalog (see application/errors/translate-domain-error.ts) — that
 * translation, not the domain layer itself, is where HTTP-status-aware error handling
 * belongs.
 */
export class InvalidProductStateTransitionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidProductStateTransitionError';
  }
}

export class InvalidProductDataError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidProductDataError';
  }
}
