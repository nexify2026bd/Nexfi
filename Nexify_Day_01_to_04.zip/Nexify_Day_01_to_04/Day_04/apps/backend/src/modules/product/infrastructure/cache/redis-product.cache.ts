import { ICacheService } from '../../../../core/cache/cache.service';
import { IProductCache } from '../../application/ports/product-cache.port';
import { env } from '../../../../core/config/env.schema';

/**
 * Day 4 §10 key patterns: cache:product:<id>, cache:product:slug:<sellerId>:<slug>,
 * plus a list-cache prefix invalidated on any write for that seller. TTL is
 * environment-configurable (PRODUCT_CACHE_TTL_SECONDS), per Day 3 §6.1 convention.
 */
export class RedisProductCache implements IProductCache {
  constructor(private readonly cacheService: ICacheService) {}

  private idKey(id: string): string {
    return `cache:product:${id}`;
  }
  private slugKey(sellerId: string, slug: string): string {
    return `cache:product:slug:${sellerId}:${slug}`;
  }
  private listPattern(sellerId: string): string {
    return `cache:product:list:${sellerId}:*`;
  }

  async getById(id: string): Promise<unknown | null> {
    return this.cacheService.get(this.idKey(id));
  }

  async getBySlug(sellerId: string, slug: string): Promise<unknown | null> {
    return this.cacheService.get(this.slugKey(sellerId, slug));
  }

  async setById(id: string, value: unknown): Promise<void> {
    await this.cacheService.set(this.idKey(id), value, env.PRODUCT_CACHE_TTL_SECONDS);
  }

  async setBySlug(sellerId: string, slug: string, value: unknown): Promise<void> {
    await this.cacheService.set(this.slugKey(sellerId, slug), value, env.PRODUCT_CACHE_TTL_SECONDS);
  }

  async invalidate(id: string, sellerId: string, slug: string): Promise<void> {
    await Promise.all([
      this.cacheService.invalidate(this.idKey(id)),
      this.cacheService.invalidate(this.slugKey(sellerId, slug)),
    ]);
  }

  async invalidateListCaches(sellerId: string): Promise<void> {
    // SCAN-based pattern invalidation (core/cache/cache.service.ts) — never KEYS (Day 3 §6.2).
    await this.cacheService.invalidatePattern(this.listPattern(sellerId));
  }
}
