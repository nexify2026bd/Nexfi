import { IProductRepository } from '../ports/product.repository.port';
import { IProductCache } from '../ports/product-cache.port';
import { ProductResponseDTO, toProductResponseDTO } from '../dto/product-response.dto';
import { NotFoundError } from '../../../../core/errors/error-catalog';

/**
 * Day 4 §6 — GetProductQuery: cache → DB(read pool via repository) → cache.
 *
 * Day 7 STEP 12 security fix: this endpoint is public/unauthenticated (Day 4 §11 —
 * no `authenticate` middleware on `GET /products/:id`, by design, for marketplace
 * browsing). Before this fix it returned a product regardless of status, meaning any
 * anonymous caller could fetch a competing seller's draft/pending_approval/rejected
 * product by guessing or enumerating IDs — an information-disclosure / IDOR-adjacent
 * gap (Day 1's Admin "Product Approval" feature implies non-approved products are NOT
 * meant to be publicly visible yet). Since this route has no identity to check
 * ownership against, the only safe fix without inventing new auth architecture is to
 * gate visibility on status: only 'approved' products are servable through the public
 * read path. A 404 (not 403) is returned for a non-approved product, matching standard
 * practice for avoiding existence-confirmation to an unauthorized caller. Owners/admins
 * viewing their own non-approved products is out of Day 4–7's built scope (they already
 * get the full state back from the create/update/publish/archive command responses).
 */
export class GetProductQuery {
  constructor(
    private readonly repository: IProductRepository,
    private readonly cache: IProductCache,
  ) {}

  async execute(productId: string): Promise<ProductResponseDTO> {
    const cached = await this.cache.getById(productId);
    if (cached) return cached as ProductResponseDTO;

    const product = await this.repository.findById(productId);
    if (!product || product.status.value !== 'approved') {
      throw new NotFoundError('PRODUCT_NOT_FOUND', `Product ${productId} not found`);
    }

    const dto = toProductResponseDTO(product);
    await this.cache.setById(productId, dto); // only approved products are ever cached
    return dto;
  }
}
