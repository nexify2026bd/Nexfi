export interface IProductCache {
  getById(id: string): Promise<unknown | null>;
  getBySlug(sellerId: string, slug: string): Promise<unknown | null>;
  setById(id: string, value: unknown): Promise<void>;
  setBySlug(sellerId: string, slug: string, value: unknown): Promise<void>;
  invalidate(id: string, sellerId: string, slug: string): Promise<void>;
  invalidateListCaches(sellerId: string): Promise<void>;
}
