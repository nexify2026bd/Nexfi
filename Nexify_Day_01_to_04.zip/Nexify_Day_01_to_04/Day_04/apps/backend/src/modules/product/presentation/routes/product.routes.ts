import { Router } from 'express';
import { ProductController } from '../controllers/product.controller';
import { authenticate } from '../../../../core/auth/authenticate.middleware';
import { requirePermission } from '../../../../core/rbac/rbac.middleware';
import { validate } from '../../../../core/validation/validate.middleware';
import { PRODUCT_PERMISSIONS } from '../../../../core/rbac/permission.registry';
import {
  CreateProductSchema,
  UpdateProductSchema,
  ProductIdParamsSchema,
  ListProductsQuerySchema,
} from '../validators/product.schemas';

/** Day 4 §11 — exactly the six endpoints in scope, no future-module routes. */
export function buildProductRoutes(controller: ProductController): Router {
  const router = Router();

  router.post(
    '/products',
    authenticate,
    requirePermission(PRODUCT_PERMISSIONS.CREATE),
    validate(CreateProductSchema, 'body'),
    controller.create,
  );

  router.get(
    '/products/:id',
    validate(ProductIdParamsSchema, 'params'),
    controller.getById,
  );

  router.get(
    '/products',
    validate(ListProductsQuerySchema, 'query'),
    controller.list,
  );

  router.patch(
    '/products/:id',
    authenticate,
    requirePermission(PRODUCT_PERMISSIONS.UPDATE),
    validate(ProductIdParamsSchema, 'params'),
    validate(UpdateProductSchema, 'body'),
    controller.update,
  );

  router.post(
    '/products/:id/publish',
    authenticate,
    requirePermission(PRODUCT_PERMISSIONS.PUBLISH),
    validate(ProductIdParamsSchema, 'params'),
    controller.publish,
  );

  router.post(
    '/products/:id/archive',
    authenticate,
    requirePermission(PRODUCT_PERMISSIONS.ARCHIVE),
    validate(ProductIdParamsSchema, 'params'),
    controller.archive,
  );

  return router;
}
