import { InvalidProductDataError } from '../errors/product.errors';

/**
 * Mirrors catalog.product_status EXACTLY as defined in Day 2 §3 — this enum has no
 * 'published' value in the actual schema. Reconciliation of Day 4's "publish/archive"
 * command vocabulary against this real enum:
 *
 *   draft              — seller is authoring, not visible in marketplace
 *   pending_approval    — seller has submitted for review ("PublishProductCommand" target)
 *   approved             — admin-approved, live in marketplace (Day 1 Admin "Product Approval"
 *                           feature owns this transition — OUT OF SCOPE for Day 4)
 *   rejected              — admin-rejected (also owned by the future Admin module)
 *   archived               — terminal, seller/admin retired the listing
 *
 * Day 4's PublishProductCommand therefore transitions draft → pending_approval (submits
 * the product into the existing admin approval queue), NOT directly to a live state —
 * there is no schema-level "instant publish" for a marketplace where Day 1 explicitly
 * requires admin product approval. This is a deliberate mapping, not an invented column.
 */
export type ProductStatusValue = 'draft' | 'pending_approval' | 'approved' | 'rejected' | 'archived';

const ALLOWED_TRANSITIONS: Record<ProductStatusValue, ProductStatusValue[]> = {
  draft: ['pending_approval', 'archived'],
  pending_approval: ['archived'], // approved/rejected are admin-module transitions, not Day 4
  approved: ['archived'],
  rejected: ['archived'],
  archived: [], // terminal — no automatic restoration, matches Day 4 §4 example rule
};

export class ProductStatus {
  private constructor(readonly value: ProductStatusValue) {}

  static draft(): ProductStatus {
    return new ProductStatus('draft');
  }

  static from(value: string): ProductStatus {
    if (!(value in ALLOWED_TRANSITIONS)) {
      // Day 6 STEP 12 audit fix: was a plain `throw new Error(...)`, inconsistent with
      // every other value object (Money, ProductId) using the domain-native error
      // taxonomy. Fixed for consistency — translate-domain-error.ts already handles
      // InvalidProductDataError, so this now maps to a 422 ValidationError like the rest.
      throw new InvalidProductDataError(`Unknown product status: ${value}`);
    }
    return new ProductStatus(value as ProductStatusValue);
  }

  canTransitionTo(target: ProductStatusValue): boolean {
    return ALLOWED_TRANSITIONS[this.value].includes(target);
  }

  equals(other: ProductStatusValue): boolean {
    return this.value === other;
  }
}
