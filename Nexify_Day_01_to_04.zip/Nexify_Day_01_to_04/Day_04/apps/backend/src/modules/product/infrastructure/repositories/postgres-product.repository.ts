import { Pool, PoolClient } from 'pg';
import { readPool, writePool } from '../../../../core/database/pg-pool';
import { DbTransaction } from '../../../../core/database/transaction-manager';
import { DecodedCursor } from '../../../../core/http/pagination';
import { ConflictError } from '../../../../core/errors/error-catalog';
import { IProductRepository, ListProductsFilter, ListProductsResult } from '../../application/ports/product.repository.port';
import { Product } from '../../domain/entities/product.entity';
import { ProductId } from '../../domain/value-objects/product-id.vo';
import { Money } from '../../domain/value-objects/money.vo';
import { ProductStatus } from '../../domain/value-objects/product-status.vo';

/** A `Pool` and a `PoolClient` (transaction handle) share a compatible `.query()` shape —
 *  this alias lets `save()` accept either without an unsound cast (audit fix). */
type Queryable = Pool | PoolClient;

/** Row shape as it physically exists in catalog.products (Day 2 §3) — no invented columns. */
interface ProductRow {
  id: string;
  seller_id: string;
  category_id: string;
  brand_id: string | null;
  title: string;
  slug: string;
  description: string | null;
  base_price: string; // NUMERIC comes back as string from node-pg by default
  status: string;
  approved_by: string | null;
  approved_at: Date | null;
  rating_avg: string;
  rating_count: number;
  version: number;
  created_at: Date;
  updated_at: Date;
  deleted_at: Date | null;
}

function rowToProduct(row: ProductRow): Product {
  return Product.rehydrate({
    id: ProductId.from(row.id),
    sellerId: row.seller_id,
    categoryId: row.category_id,
    brandId: row.brand_id,
    title: row.title,
    slug: row.slug,
    description: row.description,
    basePrice: Money.from(Number(row.base_price)),
    status: ProductStatus.from(row.status),
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    ratingAvg: Number(row.rating_avg),
    ratingCount: row.rating_count,
    version: row.version,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    deletedAt: row.deleted_at,
  });
}

const SELECT_COLUMNS = `
  id, seller_id, category_id, brand_id, title, slug, description, base_price,
  status, approved_by, approved_at, rating_avg, rating_count, version,
  created_at, updated_at, deleted_at
`; // explicit column list — Day 4 §21 "no SELECT * if avoidable"

export class PostgresProductRepository implements IProductRepository {
  async findById(id: string): Promise<Product | null> {
    const { rows } = await readPool.query<ProductRow>(
      `SELECT ${SELECT_COLUMNS} FROM catalog.products WHERE id = $1 AND deleted_at IS NULL`,
      [id],
    );
    return rows[0] ? rowToProduct(rows[0]) : null;
  }

  async findBySlug(sellerId: string, slug: string): Promise<Product | null> {
    const { rows } = await readPool.query<ProductRow>(
      `SELECT ${SELECT_COLUMNS} FROM catalog.products
       WHERE seller_id = $1 AND slug = $2 AND deleted_at IS NULL`,
      [sellerId, slug],
    );
    return rows[0] ? rowToProduct(rows[0]) : null;
  }

  async existsBySlug(sellerId: string, slug: string): Promise<boolean> {
    const { rows } = await readPool.query(
      `SELECT 1 FROM catalog.products WHERE seller_id = $1 AND slug = $2 AND deleted_at IS NULL LIMIT 1`,
      [sellerId, slug],
    );
    return rows.length > 0;
  }

  async findMany(filter: ListProductsFilter, cursor: DecodedCursor | null, limit: number): Promise<ListProductsResult> {
    const conditions: string[] = ['deleted_at IS NULL'];
    const params: unknown[] = [];

    if (filter.sellerId) {
      params.push(filter.sellerId);
      conditions.push(`seller_id = $${params.length}`);
    }
    if (filter.categoryId) {
      params.push(filter.categoryId);
      conditions.push(`category_id = $${params.length}`);
    }
    if (filter.status) {
      params.push(filter.status);
      conditions.push(`status = $${params.length}`);
    }
    if (cursor) {
      // keyset pagination: strictly-after the (created_at, id) tuple of the last seen row —
      // indexed via idx_products_seller_id / idx_products_category_id (Day 2 §3), never OFFSET.
      params.push(cursor.createdAt, cursor.id);
      conditions.push(`(created_at, id) > ($${params.length - 1}, $${params.length})`);
    }

    // fetch limit+1 to detect hasMore without a second COUNT query
    params.push(limit + 1);
    const sql = `
      SELECT ${SELECT_COLUMNS} FROM catalog.products
      WHERE ${conditions.join(' AND ')}
      ORDER BY created_at ASC, id ASC
      LIMIT $${params.length}
    `;

    const { rows } = await readPool.query<ProductRow>(sql, params);
    const hasMore = rows.length > limit;
    const pageRows = hasMore ? rows.slice(0, limit) : rows;
    return { items: pageRows.map(rowToProduct), hasMore };
  }

  async save(product: Product, trx?: DbTransaction): Promise<void> {
    const p = product.toProps();
    const client: Queryable = trx ?? writePool;
    const isUpdate = p.version > 1;

    try {
      const result = await client.query(
        `INSERT INTO catalog.products
           (id, seller_id, category_id, brand_id, title, slug, description, base_price,
            status, approved_by, approved_at, rating_avg, rating_count, version,
            created_at, updated_at, deleted_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
         ON CONFLICT (id) DO UPDATE SET
           category_id = EXCLUDED.category_id,
           brand_id = EXCLUDED.brand_id,
           title = EXCLUDED.title,
           slug = EXCLUDED.slug,
           description = EXCLUDED.description,
           base_price = EXCLUDED.base_price,
           status = EXCLUDED.status,
           approved_by = EXCLUDED.approved_by,
           approved_at = EXCLUDED.approved_at,
           version = EXCLUDED.version,
           updated_at = EXCLUDED.updated_at
         WHERE catalog.products.version = $18 -- optimistic concurrency guard (Day 2 §0 convention)
         RETURNING id`,
        [
          p.id.toString(), p.sellerId, p.categoryId, p.brandId, p.title, p.slug, p.description,
          p.basePrice.toNumber(), p.status.value, p.approvedBy, p.approvedAt, p.ratingAvg,
          p.ratingCount, p.version, p.createdAt, p.updatedAt, p.deletedAt, p.version - 1,
        ],
      );

      // AUDIT FIX: Postgres does NOT raise an error when an `ON CONFLICT DO UPDATE ...
      // WHERE` predicate fails to match — it silently updates zero rows. The original
      // Day 4 implementation never checked this, so a concurrent-write version mismatch
      // was swallowed instead of surfacing as a conflict. `isUpdate` distinguishes this
      // from a first-time INSERT (which always affects exactly one row regardless of the
      // WHERE clause, since that clause only applies to the conflict/UPDATE branch).
      if (isUpdate && result.rowCount === 0) {
        throw new ConflictError(
          'PRODUCT_VERSION_CONFLICT',
          `Product ${p.id.toString()} was modified concurrently; reload and retry`,
        );
      }
    } catch (err: unknown) {
      if (err instanceof ConflictError) throw err;
      // Postgres unique_violation on uq_products_seller_slug (Day 2 §3) — never leak raw DB error (§16).
      if (isUniqueViolation(err)) {
        throw new ConflictError('PRODUCT_SLUG_ALREADY_EXISTS', `Slug '${p.slug}' is already in use for this seller`);
      }
      throw err;
    }
  }
}

function isUniqueViolation(err: unknown): boolean {
  return typeof err === 'object' && err !== null && (err as { code?: string }).code === '23505';
}
