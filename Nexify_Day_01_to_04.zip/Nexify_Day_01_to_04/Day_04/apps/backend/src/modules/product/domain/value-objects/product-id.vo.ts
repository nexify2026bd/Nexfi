import { InvalidProductDataError } from '../errors/product.errors';
/** Wraps the UUIDv7 primary key of catalog.products (Day 2 §3) as a typed value object. */
export class ProductId {
  private constructor(readonly value: string) {}

  static from(value: string): ProductId {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
      throw new InvalidProductDataError('Invalid ProductId format');
    }
    return new ProductId(value);
  }

  equals(other: ProductId): boolean {
    return this.value === other.value;
  }

  toString(): string {
    return this.value;
  }
}
