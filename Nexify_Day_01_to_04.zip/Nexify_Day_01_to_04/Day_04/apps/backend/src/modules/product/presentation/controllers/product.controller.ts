import { NextFunction, Request, Response } from 'express';
import { CreateProductCommand } from '../../application/commands/create-product.command';
import { UpdateProductCommand } from '../../application/commands/update-product.command';
import { PublishProductCommand } from '../../application/commands/publish-product.command';
import { ArchiveProductCommand } from '../../application/commands/archive-product.command';
import { GetProductQuery } from '../../application/queries/get-product.query';
import { ListProductsQuery } from '../../application/queries/list-products.query';
import { sendSuccess } from '../../../../core/http/response-envelope';
import { AuthError } from '../../../../core/errors/error-catalog';

/**
 * Thin controller (Day 3 §5.6 rule): extract identity/DTO, delegate to the use-case,
 * map the result to the response envelope. No business logic, no direct repository/cache
 * access, no `new` of any application/infrastructure class — all injected via constructor.
 */
export class ProductController {
  constructor(
    private readonly createProduct: CreateProductCommand,
    private readonly updateProduct: UpdateProductCommand,
    private readonly publishProduct: PublishProductCommand,
    private readonly archiveProduct: ArchiveProductCommand,
    private readonly getProduct: GetProductQuery,
    private readonly listProducts: ListProductsQuery,
  ) {}

  create = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const identity = this.requireIdentity(req);
      // sellerId is resolved from the authenticated identity, never trusted from the body (§20).
      const result = await this.createProduct.execute({ sellerId: identity.userId, dto: req.body });
      sendSuccess(res, result, 201);
    } catch (err) {
      next(err);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const identity = this.requireIdentity(req);
      const result = await this.updateProduct.execute({
        productId: req.params.id,
        actor: identity,
        dto: req.body,
      });
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };

  publish = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const identity = this.requireIdentity(req);
      const result = await this.publishProduct.execute({ productId: req.params.id, actor: identity });
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };

  archive = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const identity = this.requireIdentity(req);
      const result = await this.archiveProduct.execute({ productId: req.params.id, actor: identity });
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const result = await this.getProduct.execute(req.params.id);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const q = req.query as unknown as {
        cursor?: string; limit: number; sellerId?: string; categoryId?: string; status?: string;
      };
      const result = await this.listProducts.execute({
        cursor: q.cursor,
        limit: q.limit,
        filter: { sellerId: q.sellerId, categoryId: q.categoryId, status: q.status },
      });
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };

  private requireIdentity(req: Request) {
    if (!req.identity) throw new AuthError('No authenticated identity on request');
    return req.identity;
  }
}
