import { ProductPublishedEvent } from '../../domain/events/product-published.event';
import { IProductRepository } from '../ports/product.repository.port';
import { IProductCache } from '../ports/product-cache.port';
import { ProductResponseDTO, toProductResponseDTO } from '../dto/product-response.dto';
import { ITransactionManager } from '../../../../core/database/transaction-manager';
import { IOutboxRepository } from '../../../../core/events/outbox/transactional-outbox.repository';
import { NotFoundError } from '../../../../core/errors/error-catalog';
import { ProductOwnershipViolationError } from '../errors/product-ownership-violation.error';
import { newCorrelationId } from '../../../../core/events/domain-event.base';
import { PolicyEngine } from '../../../../core/rbac/policy.engine';
import { AuthenticatedIdentity } from '../../../../core/types/express';
import { logger } from '../../../../core/logger/logger';
import { getRequestId } from '../../../../core/logger/request-context';
import { translateDomainError } from '../errors/translate-domain-error';

export interface PublishProductInput {
  productId: string;
  actor: AuthenticatedIdentity;
}

/**
 * Submits a draft product into the admin approval queue (status → pending_approval).
 * See ProductStatus VO for why this does not jump directly to a "live" state — Day 2's
 * schema and Day 1's Admin "Product Approval" feature require an explicit approval step
 * that Day 4 does not own.
 */
export class PublishProductCommand {
  constructor(
    private readonly repository: IProductRepository,
    private readonly cache: IProductCache,
    private readonly transactionManager: ITransactionManager,
    private readonly outbox: IOutboxRepository,
    private readonly policyEngine: PolicyEngine,
  ) {}

  async execute(input: PublishProductInput): Promise<ProductResponseDTO> {
    const product = await this.repository.findById(input.productId);
    if (!product) throw new NotFoundError('PRODUCT_NOT_FOUND', `Product ${input.productId} not found`);

    const allowed = await this.policyEngine.can('product', input.actor, 'publish', product);
    if (!allowed) throw new ProductOwnershipViolationError(input.productId);

    try {
      product.submitForApproval(); // throws domain error if not currently 'draft'
    } catch (err) {
      translateDomainError(err);
    }

    const correlationId = newCorrelationId();
    const event = new ProductPublishedEvent(
      { productId: product.id.toString(), sellerId: product.sellerId },
      correlationId,
    );

    await this.transactionManager.runInTransaction(async (trx) => {
      await this.repository.save(product, trx);
      await this.outbox.append(trx, event);
    });

    const props = product.toProps();
    await this.cache.invalidate(product.id.toString(), product.sellerId, props.slug);
    await this.cache.invalidateListCaches(product.sellerId);

    logger.info(
      { productId: product.id.toString(), sellerId: product.sellerId, requestId: getRequestId() },
      'product.published',
    );

    return toProductResponseDTO(product);
  }
}
