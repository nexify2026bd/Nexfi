import { IPolicy } from '../../../../core/rbac/policy.engine';
import { AuthenticatedIdentity } from '../../../../core/types/express';
import { Product } from '../../domain/entities/product.entity';

/**
 * Day 4 §7/§12 audit fix: this adapter depends on core/rbac's IPolicy contract and
 * core/types — it therefore belongs in the Application layer (which is explicitly
 * permitted to depend on ports/interfaces from core), NOT in Domain. It was originally
 * placed under domain/services/ in the first Day 4 pass; that was a boundary violation,
 * caught and corrected during this audit. The underlying business rule it wraps
 * (`Product.isOwnedBy`) correctly remains a method on the Domain entity itself —
 * only the Day-3-PolicyEngine-shaped adapter moved.
 */
export class ProductOwnershipPolicy implements IPolicy<Product> {
  can(actor: AuthenticatedIdentity, _action: string, resource?: Product): boolean {
    if (!resource) return false;
    return resource.isOwnedBy(actor.userId);
  }
}
