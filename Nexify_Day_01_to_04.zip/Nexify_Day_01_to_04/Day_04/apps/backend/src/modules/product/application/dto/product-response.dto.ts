import { Product } from '../../domain/entities/product.entity';

export interface ProductResponseDTO {
  id: string;
  sellerId: string;
  categoryId: string;
  brandId: string | null;
  title: string;
  slug: string;
  description: string | null;
  basePrice: number;
  status: string;
  ratingAvg: number;
  ratingCount: number;
  createdAt: string;
  updatedAt: string;
}

/** Entity → DTO mapping lives in application layer, never in the controller (thin controller rule). */
export function toProductResponseDTO(product: Product): ProductResponseDTO {
  const p = product.toProps();
  return {
    id: p.id.toString(),
    sellerId: p.sellerId,
    categoryId: p.categoryId,
    brandId: p.brandId,
    title: p.title,
    slug: p.slug,
    description: p.description,
    basePrice: p.basePrice.toNumber(),
    status: p.status.value,
    ratingAvg: p.ratingAvg,
    ratingCount: p.ratingCount,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}
