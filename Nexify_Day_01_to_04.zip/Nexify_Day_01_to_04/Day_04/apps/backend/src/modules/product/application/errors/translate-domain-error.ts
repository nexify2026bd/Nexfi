import { InvalidProductStateTransitionError, InvalidProductDataError } from '../../domain/errors/product.errors';
import { InvalidStateTransitionError, ValidationError } from '../../../../core/errors/error-catalog';

/**
 * Boundary translation (Day 4 audit fix): the Domain layer throws plain, framework-free
 * errors; this function — living in the Application layer, which IS permitted to depend
 * on core/errors — maps them onto the Day 3 AppError catalog so the global error handler
 * can format an HTTP response. Any error not recognized here is rethrown unchanged for the
 * caller (or the global handler's generic 500 fallback) to deal with.
 */
export function translateDomainError(err: unknown): never {
  if (err instanceof InvalidProductStateTransitionError) {
    throw new InvalidStateTransitionError(err.message);
  }
  if (err instanceof InvalidProductDataError) {
    throw new ValidationError(err.message);
  }
  throw err;
}
