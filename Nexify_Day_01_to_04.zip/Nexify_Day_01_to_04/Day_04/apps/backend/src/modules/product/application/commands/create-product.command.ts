import { randomUUID } from 'node:crypto';
import { Product } from '../../domain/entities/product.entity';
import { ProductId } from '../../domain/value-objects/product-id.vo';
import { Money } from '../../domain/value-objects/money.vo';
import { ProductDomainService } from '../../domain/services/product-domain.service';
import { ProductCreatedEvent } from '../../domain/events/product-created.event';
import { IProductRepository } from '../ports/product.repository.port';
import { IProductCache } from '../ports/product-cache.port';
import { CreateProductDTO } from '../dto/create-product.dto';
import { ProductResponseDTO, toProductResponseDTO } from '../dto/product-response.dto';
import { ITransactionManager } from '../../../../core/database/transaction-manager';
import { IOutboxRepository } from '../../../../core/events/outbox/transactional-outbox.repository';
import { ConflictError } from '../../../../core/errors/error-catalog';
import { newCorrelationId } from '../../../../core/events/domain-event.base';
import { logger } from '../../../../core/logger/logger';
import { getRequestId } from '../../../../core/logger/request-context';
import { translateDomainError } from '../errors/translate-domain-error';

export interface CreateProductInput {
  /** sellerId comes from the authenticated identity's resolved seller profile —
   *  NEVER from client-supplied input (Day 4 §20 "never trust sellerId from client"). */
  sellerId: string;
  dto: CreateProductDTO;
}

export class CreateProductCommand {
  constructor(
    private readonly repository: IProductRepository,
    private readonly cache: IProductCache,
    private readonly domainService: ProductDomainService,
    private readonly transactionManager: ITransactionManager,
    private readonly outbox: IOutboxRepository,
  ) {}

  async execute(input: CreateProductInput): Promise<ProductResponseDTO> {
    const { sellerId, dto } = input;

    // Day 9 audit fix: slug generation can now throw a domain-native error (empty-slug
    // guard, see ProductDomainService) — must be inside the same translate-domain-error
    // boundary as Product.create(), not left uncaught like the cursor-decoding bug found
    // in the same audit pass.
    let slug: string;
    try {
      slug = dto.slug ?? this.domainService.generateSlugCandidate(dto.title);
    } catch (err) {
      translateDomainError(err);
    }

    // Application-level pre-check for a fast, friendly error — the DB unique constraint
    // (catalog.products (seller_id, slug), Day 2 §3) remains the authoritative guard
    // against a race between this check and the insert (Day 4 §14).
    const slugTaken = await this.repository.existsBySlug(sellerId, slug);
    if (slugTaken) {
      throw new ConflictError('PRODUCT_SLUG_ALREADY_EXISTS', `Slug '${slug}' is already in use for this seller`);
    }

    let product: Product;
    try {
      product = Product.create({
        id: ProductId.from(randomUUID()), // real repo: uuidv7() per Day 2 PK convention
        sellerId,
        categoryId: dto.categoryId,
        brandId: dto.brandId ?? null,
        title: dto.title,
        slug,
        description: dto.description ?? null,
        basePrice: Money.from(dto.basePrice),
      });
    } catch (err) {
      translateDomainError(err); // e.g. Money precision violation slipping past Zod → 422, not 500
    }

    const correlationId = newCorrelationId();
    const event = new ProductCreatedEvent({ productId: product.id.toString(), sellerId }, correlationId);

    await this.transactionManager.runInTransaction(async (trx) => {
      // Duplicate-slug races surface here as a Postgres unique_violation (23505);
      // the repository maps that to ConflictError — no raw DB error reaches the client (§16).
      await this.repository.save(product, trx);
      await this.outbox.append(trx, event);
    });

    await this.cache.invalidateListCaches(sellerId);

    logger.info(
      { productId: product.id.toString(), sellerId, requestId: getRequestId() },
      'product.created',
    );

    return toProductResponseDTO(product);
  }
}
