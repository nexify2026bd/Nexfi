export interface UpdateProductDTO {
  categoryId?: string;
  brandId?: string | null;
  title?: string;
  description?: string | null;
  basePrice?: number;
}
