import { Product } from '../../domain/entities/product.entity';
import { DbTransaction } from '../../../../core/database/transaction-manager';
import { DecodedCursor } from '../../../../core/http/pagination';

export interface ListProductsFilter {
  sellerId?: string;
  categoryId?: string;
  status?: string;
}

export interface ListProductsResult {
  items: Product[];
  hasMore: boolean;
}

/**
 * Day 3 §4.1 base contract, specialized for Product. Implemented by
 * infrastructure/repositories/postgres-product.repository.ts against catalog.products
 * (Day 2 §3). No business rules live here — pure persistence contract (§8 rule).
 */
export interface IProductRepository {
  findById(id: string): Promise<Product | null>;
  findBySlug(sellerId: string, slug: string): Promise<Product | null>;
  findMany(filter: ListProductsFilter, cursor: DecodedCursor | null, limit: number): Promise<ListProductsResult>;
  existsBySlug(sellerId: string, slug: string): Promise<boolean>;
  /** save() participates in the caller's transaction when trx is provided (Day 3 §4.4). */
  save(product: Product, trx?: DbTransaction): Promise<void>;
}
