import { IProductRepository, ListProductsFilter } from '../ports/product.repository.port';
import { ProductResponseDTO, toProductResponseDTO } from '../dto/product-response.dto';
import { CursorPage, decodeCursor, encodeCursor } from '../../../../core/http/pagination';

export interface ListProductsInput {
  filter: ListProductsFilter;
  cursor?: string;
  limit: number;
}

/**
 * Day 4 §6 — ListProductsQuery: cursor pagination ONLY, always via read pool (repository-routed).
 *
 * Day 7 STEP 12 security fix: same information-disclosure gap as GetProductQuery (see its
 * doc comment) — `GET /products` is public/unauthenticated, so a caller could previously
 * pass `?status=draft&sellerId=<any-seller>` and enumerate a competitor's unpublished
 * catalog. Since this is the public browse endpoint with no identity to authorize against,
 * the status filter is now hard-pinned to 'approved' regardless of what the caller
 * requests — the only status a public, unauthenticated listing may ever expose.
 */
export class ListProductsQuery {
  constructor(private readonly repository: IProductRepository) {}

  async execute(input: ListProductsInput): Promise<CursorPage<ProductResponseDTO>> {
    const decoded = input.cursor ? decodeCursor(input.cursor) : null;
    const publicFilter: ListProductsFilter = { ...input.filter, status: 'approved' };
    // fetch one extra row to determine hasMore without a separate COUNT(*) query
    const { items, hasMore } = await this.repository.findMany(publicFilter, decoded, input.limit);

    const dtoItems = items.map(toProductResponseDTO);
    const last = items[items.length - 1];
    const nextCursor =
      hasMore && last ? encodeCursor({ createdAt: last.toProps().createdAt.toISOString(), id: last.id.toString() }) : null;

    return { items: dtoItems, nextCursor, hasMore };
  }
}
