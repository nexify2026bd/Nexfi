import { z } from 'zod';

const uuidSchema = z.string().uuid();
// slug: URL-safe, normalized (Day 4 §14)
const slugSchema = z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Slug must be lowercase, alphanumeric, hyphen-separated');

export const CreateProductSchema = z.object({
  categoryId: uuidSchema,
  brandId: uuidSchema.nullable().optional(),
  title: z.string().trim().min(3).max(200),
  description: z.string().trim().max(5000).nullable().optional(),
  basePrice: z.number().nonnegative().multipleOf(0.01), // matches NUMERIC(14,2), Day 2 §3
  slug: slugSchema.optional(),
}).strict(); // Day 6 STEP 11: reject unknown fields outright (e.g. a client-supplied
             // sellerId/status/id) rather than silently stripping them — makes an attempt
             // to smuggle a server-controlled field a visible 422, not a silent no-op.

export const UpdateProductSchema = z.object({
  categoryId: uuidSchema.optional(),
  brandId: uuidSchema.nullable().optional(),
  title: z.string().trim().min(3).max(200).optional(),
  description: z.string().trim().max(5000).nullable().optional(),
  basePrice: z.number().nonnegative().multipleOf(0.01).optional(),
}).strict();

export const ProductIdParamsSchema = z.object({
  id: uuidSchema,
});

export const ListProductsQuerySchema = z.object({
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20), // bounded pagination limit (Day 4 §21)
  sellerId: uuidSchema.optional(),
  categoryId: uuidSchema.optional(),
  status: z.enum(['draft', 'pending_approval', 'approved', 'rejected', 'archived']).optional(),
});
