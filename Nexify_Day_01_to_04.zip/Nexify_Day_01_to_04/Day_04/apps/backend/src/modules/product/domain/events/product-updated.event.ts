import { DomainEvent } from '../../../../core/events/domain-event.base';

export interface ProductUpdatedPayload {
  productId: string;
  sellerId: string;
  occurredAt: string;
}

export class ProductUpdatedEvent extends DomainEvent<ProductUpdatedPayload> {
  readonly eventName = 'product.updated';
  constructor(payload: Omit<ProductUpdatedPayload, 'occurredAt'>, correlationId: string) {
    super({ ...payload, occurredAt: new Date().toISOString() }, correlationId);
  }
}

// AUDIT FIX: correlationId removed from the payload interface — it was previously
// duplicated here AND on DomainEvent.correlationId, which made every call site's
// literal payload object fail type-checking (TS2345: missing required property).
// DomainEvent.correlationId (constructor's 2nd argument) is now the single source.
