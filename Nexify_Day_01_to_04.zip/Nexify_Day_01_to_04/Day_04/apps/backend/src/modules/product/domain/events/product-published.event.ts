import { DomainEvent } from '../../../../core/events/domain-event.base';

/** Fired on submitForApproval() — see ProductStatus VO doc comment for the naming reconciliation. */
export interface ProductPublishedPayload {
  productId: string;
  sellerId: string;
  occurredAt: string;
}

export class ProductPublishedEvent extends DomainEvent<ProductPublishedPayload> {
  readonly eventName = 'product.published';
  constructor(payload: Omit<ProductPublishedPayload, 'occurredAt'>, correlationId: string) {
    super({ ...payload, occurredAt: new Date().toISOString() }, correlationId);
  }
}

// AUDIT FIX: correlationId removed from the payload interface — it was previously
// duplicated here AND on DomainEvent.correlationId, which made every call site's
// literal payload object fail type-checking (TS2345: missing required property).
// DomainEvent.correlationId (constructor's 2nd argument) is now the single source.
