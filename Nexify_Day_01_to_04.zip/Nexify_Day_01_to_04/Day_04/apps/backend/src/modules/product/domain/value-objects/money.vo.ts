import { InvalidProductDataError } from '../errors/product.errors';
/**
 * catalog.products.base_price is NUMERIC(14,2) with no currency column (Day 2 §3) —
 * NEXFIY operates a single-currency ledger for now (BDT, per Day 1 payment methods:
 * bKash/Nagad/Rocket). Money therefore does NOT carry a currency field; multi-currency
 * support would require a Day 2 schema migration (adding `currency CHAR(3)` to
 * catalog.products and catalog.product_variants) and is explicitly out of scope here.
 */
export class Money {
  private constructor(readonly amount: number) {}

  static from(amount: number): Money {
    if (!Number.isFinite(amount) || amount < 0) {
      throw new InvalidProductDataError('Money amount must be a non-negative finite number');
    }
    // NUMERIC(14,2) — reject more than 2 decimal places to match the DB constraint exactly.
    if (Math.round(amount * 100) / 100 !== amount) {
      throw new InvalidProductDataError('Money amount must have at most 2 decimal places');
    }
    return new Money(amount);
  }

  toNumber(): number {
    return this.amount;
  }
}
