-- MISSING-SCHEMA REPORT (Day 4 §23): Day 2 did not define an outbox table, but Day 3 §8.4
-- (Transactional Outbox Pattern) and Day 4 §9 both require one. This migration adds it
-- under the existing `audit` schema (Day 2 §0 schema-per-domain convention) rather than
-- inventing a new schema.

CREATE TABLE IF NOT EXISTS audit.event_outbox (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    event_name      TEXT NOT NULL,
    payload         JSONB NOT NULL,
    correlation_id  TEXT NOT NULL,
    occurred_at     TIMESTAMPTZ NOT NULL,
    dispatched_at   TIMESTAMPTZ,
    attempts        INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_event_outbox_undispatched ON audit.event_outbox (created_at)
    WHERE dispatched_at IS NULL;
-- Partial index keeps the relay worker's poll query (Day 3 §8.4) cheap even as the
-- dispatched-and-archived portion of this table grows large.
