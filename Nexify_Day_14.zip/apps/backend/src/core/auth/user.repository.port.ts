/**
 * Day 13 — minimal typed port for the identity.users lookups/inserts the login flow
 * needs. Deliberately NOT a general-purpose user repository (no update/delete/list) —
 * this exists only to serve VerifyIdentityUseCase, per Day 3 §2.4 step 2.
 */
export interface IdentityUser {
  id: string;
  firebaseUid: string;
  email: string | null;
  phone: string | null;
}

export interface NewIdentityUser {
  firebaseUid: string;
  fullName: string;
  email: string;
  phone: string;
}

export interface IUserRepository {
  findByFirebaseUid(firebaseUid: string): Promise<IdentityUser | null>;

  /** Creates the identity.users row for a first-time sign-in. All four fields are
   *  NOT NULL in the Day 2 schema — the caller (VerifyIdentityUseCase) is responsible
   *  for only calling this once it has real values for all of them (from the verified
   *  Firebase claims and/or explicit client input), never placeholders. */
  create(data: NewIdentityUser): Promise<IdentityUser>;
}
