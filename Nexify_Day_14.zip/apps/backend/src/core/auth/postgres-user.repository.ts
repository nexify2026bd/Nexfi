import { writePool, readPool } from '../database/pg-pool';
import { IdentityUser, IUserRepository, NewIdentityUser } from './user.repository.port';

/**
 * Day 13/14 — real, parameterized queries against identity.users (Day 2 §1).
 *
 * create() inserts the four NOT NULL columns the schema actually requires
 * (full_name, email, phone, firebase_uid) with whatever real values the caller
 * supplied — never a placeholder. status/password_hash are left to their real schema
 * defaults ('pending_verification', NULL — "nullable: social-login-only users" per the
 * Day 2 comment). Unique-constraint violations (uq_users_email/phone/firebase_uid) are
 * NOT caught here — they propagate as a real Postgres error, which is correct: a
 * concurrent duplicate registration is a genuine conflict, not something to paper over.
 */
export class PostgresUserRepository implements IUserRepository {
  async findByFirebaseUid(firebaseUid: string): Promise<IdentityUser | null> {
    const result = await readPool.query<{ id: string; firebase_uid: string; email: string | null; phone: string | null }>(
      `SELECT id, firebase_uid, email, phone
         FROM identity.users
        WHERE firebase_uid = $1 AND deleted_at IS NULL`,
      [firebaseUid],
    );
    const row = result.rows[0];
    if (!row) return null;
    return { id: row.id, firebaseUid: row.firebase_uid, email: row.email, phone: row.phone };
  }

  async create(data: NewIdentityUser): Promise<IdentityUser> {
    const result = await writePool.query<{ id: string; firebase_uid: string; email: string; phone: string }>(
      `INSERT INTO identity.users (full_name, email, phone, firebase_uid)
       VALUES ($1, $2, $3, $4)
       RETURNING id, firebase_uid, email, phone`,
      [data.fullName, data.email, data.phone, data.firebaseUid],
    );
    const row = result.rows[0];
    return { id: row.id, firebaseUid: row.firebase_uid, email: row.email, phone: row.phone };
  }
}
