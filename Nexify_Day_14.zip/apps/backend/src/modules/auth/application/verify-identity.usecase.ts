import { ValidationError } from '../../../core/errors/error-catalog';
import { IIdentityProvider, IAuthTokenService } from '../../../core/auth/auth.ports';
import { IUserRepository } from '../../../core/auth/user.repository.port';

export interface VerifyIdentityInput {
  firebaseIdToken: string;
  /** Only consulted for first-time sign-in (see class doc comment) — ignored entirely
   *  for an existing user, never overwrites anything already on file. */
  fullName?: string;
  email?: string;
  phone?: string;
}

export interface VerifyIdentityResult {
  accessToken: string;
  refreshToken: string;
  user: { id: string; email: string | null; phone: string | null };
}

/**
 * Day 13/14 — real implementation of the Day 3 §2.4 login flow, steps 1-4:
 *   1. IIdentityProvider.verifyIdentityToken() [Firebase]
 *   2. find-or-provision identity.users row
 *   3. IAuthTokenService.issueTokenPair()
 *   4. (persisting the refresh token hash happens inside issueTokenPair itself, Day 13)
 *
 * PROVISIONING (Day 14): the Day 2 schema requires identity.users.full_name/email/phone
 * as NOT NULL, but a verified Firebase identity only reliably supplies uid (email/phone
 * are present only for some sign-in methods, full_name is never a standard claim at
 * all). Rather than fabricate placeholder values for a first-time user — which was
 * correctly refused last round — this now accepts those three fields as OPTIONAL,
 * CLIENT-SUPPLIED input, used ONLY to fill in whatever the verified Firebase claims
 * didn't already provide, and ONLY when provisioning a brand-new user:
 *   - fullName: always client-supplied (Firebase never supplies it)
 *   - email/phone: Firebase-verified value wins if present; client-supplied value is
 *     used only as a fallback when Firebase didn't return one
 * This is real data either way — verified by Firebase or explicitly typed by the user
 * in a signup form the client is expected to show on first sign-in — never invented by
 * this code. If required fields are still missing after that, provisioning fails closed
 * with a distinct, actionable validation error rather than guessing.
 *
 * For an EXISTING user, fullName/email/phone in the input are ignored entirely — this
 * endpoint is login, not a profile-edit endpoint; changing an existing identity's
 * contact details is deliberately out of scope here.
 */
export class VerifyIdentityUseCase {
  constructor(
    private readonly identityProvider: IIdentityProvider,
    private readonly users: IUserRepository,
    private readonly authTokens: IAuthTokenService,
  ) {}

  async execute(input: VerifyIdentityInput): Promise<VerifyIdentityResult> {
    // Step 1: verify the Firebase ID token — the root of trust. Nothing from the
    // request body is trusted as identity; fullName/email/phone below are trusted only
    // as PROFILE data, gated entirely behind a successful, server-verified uid.
    const identity = await this.identityProvider.verifyIdentityToken(input.firebaseIdToken);

    let user = await this.users.findByFirebaseUid(identity.uid);

    if (!user) {
      const fullName = input.fullName?.trim();
      const email = identity.email ?? input.email?.trim();
      const phone = identity.phone ?? input.phone?.trim();

      const missing: string[] = [];
      if (!fullName) missing.push('fullName');
      if (!email) missing.push('email');
      if (!phone) missing.push('phone');
      if (missing.length > 0) {
        throw new ValidationError(
          `No account exists for this identity yet, and required profile field(s) are missing to create one: ${missing.join(', ')}`,
        );
      }

      user = await this.users.create({ firebaseUid: identity.uid, fullName: fullName!, email: email!, phone: phone! });
    }

    // Step 3+4: issue + persist NEXFIY's own token pair (RealAuthTokenService.issueTokenPair
    // already stores the hashed refresh token, Day 13).
    const roles: string[] = []; // roles are resolved by RBAC per-request (Day 3 §3.2), not embedded here
    const { accessToken, refreshToken } = await this.authTokens.issueTokenPair({ userId: user.id, roles });

    return {
      accessToken,
      refreshToken,
      user: { id: user.id, email: user.email, phone: user.phone },
    };
  }
}
