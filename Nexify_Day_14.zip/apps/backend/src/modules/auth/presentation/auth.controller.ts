import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { VerifyIdentityUseCase } from '../application/verify-identity.usecase';
import { ValidationError } from '../../../core/errors/error-catalog';
import { sendSuccess } from '../../../core/http/response-envelope';

/**
 * Day 14: fullName/email/phone are optional and consulted ONLY by VerifyIdentityUseCase
 * when provisioning a brand-new user (see that class's doc comment) — they are never
 * treated as identity and never override anything for an existing user. .strict() still
 * rejects any other field, including userId/sellerId/roles injection attempts.
 */
const VerifySchema = z
  .object({
    firebaseIdToken: z.string().min(1),
    fullName: z.string().min(1).max(200).optional(),
    email: z.string().email().optional(),
    phone: z.string().min(1).max(32).optional(),
  })
  .strict();

export class AuthController {
  constructor(private readonly verifyIdentity: VerifyIdentityUseCase) {}

  verify = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const parsed = VerifySchema.safeParse(req.body);
      if (!parsed.success) {
        throw new ValidationError('Invalid request body', parsed.error.issues);
      }
      const result = await this.verifyIdentity.execute(parsed.data);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  };
}
