import { describe, it, expect, vi } from 'vitest';
import { VerifyIdentityUseCase } from '../../../../modules/auth/application/verify-identity.usecase';
import type { IIdentityProvider, IAuthTokenService } from '../../../../core/auth/auth.ports';
import type { IUserRepository, IdentityUser } from '../../../../core/auth/user.repository.port';

/**
 * Day 13/14 — VerifyIdentityUseCase tests, using mocked IIdentityProvider/
 * IUserRepository/IAuthTokenService (no real Firebase credentials or database
 * required). Day 14 adds coverage for real, non-fabricating first-time provisioning.
 */
function makeDeps(overrides: {
  identity?: Partial<IIdentityProvider>;
  users?: Partial<IUserRepository>;
  authTokens?: Partial<IAuthTokenService>;
} = {}) {
  const identityProvider: IIdentityProvider = {
    verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'firebase-uid-1', email: 'a@example.com' }),
    ...overrides.identity,
  };
  const users: IUserRepository = {
    findByFirebaseUid: vi.fn().mockResolvedValue(null),
    create: vi.fn(),
    ...overrides.users,
  };
  const authTokens: IAuthTokenService = {
    issueTokenPair: vi.fn().mockResolvedValue({ accessToken: 'access-tok', refreshToken: 'refresh-tok' }),
    verifyAccessToken: vi.fn(),
    rotateRefreshToken: vi.fn(),
    revokeRefreshToken: vi.fn(),
    ...overrides.authTokens,
  };
  return { identityProvider, users, authTokens };
}

describe('VerifyIdentityUseCase — existing user (login)', () => {
  it('verifies the Firebase token, finds the existing user, and issues a NEXFIY token pair', async () => {
    const existingUser: IdentityUser = { id: 'user-abc', firebaseUid: 'firebase-uid-1', email: 'a@example.com', phone: null };
    const { identityProvider, users, authTokens } = makeDeps({
      users: { findByFirebaseUid: vi.fn().mockResolvedValue(existingUser) },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    const result = await useCase.execute({ firebaseIdToken: 'some-firebase-id-token' });

    expect(identityProvider.verifyIdentityToken).toHaveBeenCalledWith('some-firebase-id-token');
    expect(users.findByFirebaseUid).toHaveBeenCalledWith('firebase-uid-1');
    expect(users.create).not.toHaveBeenCalled(); // existing user — never re-provisioned
    expect(authTokens.issueTokenPair).toHaveBeenCalledWith({ userId: 'user-abc', roles: [] });
    expect(result).toEqual({
      accessToken: 'access-tok',
      refreshToken: 'refresh-tok',
      user: { id: 'user-abc', email: 'a@example.com', phone: null },
    });
  });

  it('ignores client-supplied fullName/email/phone entirely for an existing user (never overwrites)', async () => {
    const existingUser: IdentityUser = { id: 'user-abc', firebaseUid: 'firebase-uid-1', email: 'real@example.com', phone: '+15551234567' };
    const { identityProvider, users, authTokens } = makeDeps({
      users: { findByFirebaseUid: vi.fn().mockResolvedValue(existingUser) },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    const result = await useCase.execute({
      firebaseIdToken: 'tok',
      fullName: 'Attacker Name',
      email: 'attacker@evil.com',
      phone: '+10000000000',
    });

    expect(users.create).not.toHaveBeenCalled();
    expect(result.user).toEqual({ id: 'user-abc', email: 'real@example.com', phone: '+15551234567' }); // real DB values, untouched
  });

  it('propagates a Firebase verification failure without ever reaching the user lookup', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockRejectedValue(new Error('Invalid identity token')) },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await expect(useCase.execute({ firebaseIdToken: 'bad-token' })).rejects.toThrow(/Invalid identity token/);
    expect(users.findByFirebaseUid).not.toHaveBeenCalled();
  });
});

describe('VerifyIdentityUseCase — first-time provisioning', () => {
  it('provisions a new user when Firebase supplies email+phone and the client supplies fullName', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-1', email: 'new@example.com', phone: '+15559999999' }) },
      users: {
        create: vi.fn().mockResolvedValue({ id: 'user-new-1', firebaseUid: 'fb-new-1', email: 'new@example.com', phone: '+15559999999' }),
      },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    const result = await useCase.execute({ firebaseIdToken: 'tok', fullName: 'Jane Example' });

    expect(users.create).toHaveBeenCalledWith({
      firebaseUid: 'fb-new-1',
      fullName: 'Jane Example',
      email: 'new@example.com', // Firebase-verified value used, not fabricated
      phone: '+15559999999',
    });
    expect(authTokens.issueTokenPair).toHaveBeenCalledWith({ userId: 'user-new-1', roles: [] });
    expect(result.accessToken).toBe('access-tok');
  });

  it('falls back to client-supplied email/phone only when Firebase did not provide them', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-2' }) }, // no email/phone from Firebase
      users: {
        create: vi.fn().mockResolvedValue({ id: 'user-new-2', firebaseUid: 'fb-new-2', email: 'client@example.com', phone: '+15551112222' }),
      },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await useCase.execute({
      firebaseIdToken: 'tok',
      fullName: 'John Example',
      email: 'client@example.com',
      phone: '+15551112222',
    });

    expect(users.create).toHaveBeenCalledWith({
      firebaseUid: 'fb-new-2',
      fullName: 'John Example',
      email: 'client@example.com',
      phone: '+15551112222',
    });
  });

  it('a Firebase-verified email/phone always wins over a conflicting client-supplied value', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-3', email: 'verified@example.com' }) },
      users: {
        create: vi.fn().mockResolvedValue({ id: 'user-new-3', firebaseUid: 'fb-new-3', email: 'verified@example.com', phone: '+15550000000' }),
      },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await useCase.execute({
      firebaseIdToken: 'tok',
      fullName: 'Jane Doe',
      email: 'spoofed@evil.com', // attempted override of a Firebase-verified email
      phone: '+15550000000',
    });

    expect(users.create).toHaveBeenCalledWith(
      expect.objectContaining({ email: 'verified@example.com' }), // Firebase value wins, never the client-supplied one
    );
  });

  it('fails closed with a validation error (never fabricates data) when fullName is missing for a new user', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-4', email: 'e@example.com', phone: '+1555' }) },
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await expect(useCase.execute({ firebaseIdToken: 'tok' })).rejects.toThrow(/fullName/);
    expect(users.create).not.toHaveBeenCalled();
    expect(authTokens.issueTokenPair).not.toHaveBeenCalled();
  });

  it('fails closed when email is available from neither Firebase nor the client', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-5', phone: '+1555' }) }, // no email
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await expect(useCase.execute({ firebaseIdToken: 'tok', fullName: 'Name Only' })).rejects.toThrow(/email/);
    expect(users.create).not.toHaveBeenCalled();
  });

  it('fails closed when phone is available from neither Firebase nor the client', async () => {
    const { identityProvider, users, authTokens } = makeDeps({
      identity: { verifyIdentityToken: vi.fn().mockResolvedValue({ uid: 'fb-new-6', email: 'e@example.com' }) }, // no phone
    });
    const useCase = new VerifyIdentityUseCase(identityProvider, users, authTokens);

    await expect(useCase.execute({ firebaseIdToken: 'tok', fullName: 'Name Only' })).rejects.toThrow(/phone/);
    expect(users.create).not.toHaveBeenCalled();
  });
});
