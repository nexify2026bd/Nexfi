import { describe, it, expect, vi } from 'vitest';

/** Day 13 — query-shape tests for PostgresUserRepository, mocking the pg pool. */
vi.mock('../../../core/database/pg-pool', () => ({
  readPool: { query: vi.fn() },
  writePool: { query: vi.fn() },
}));

describe('PostgresUserRepository', () => {
  it('findByFirebaseUid() queries identity.users by firebase_uid, excludes soft-deleted rows, parameterized', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      rows: [{ id: 'user-1', firebase_uid: 'fb-uid-1', email: 'a@example.com', phone: '+15551234567' }],
    });
    const { PostgresUserRepository } = await import('../../../core/auth/postgres-user.repository');
    const repo = new PostgresUserRepository();

    const result = await repo.findByFirebaseUid('fb-uid-1');

    const [sql, params] = (readPool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('identity.users');
    expect(sql).toContain('firebase_uid = $1');
    expect(sql).toContain('deleted_at IS NULL');
    expect(sql).not.toContain('fb-uid-1'); // never string-interpolated
    expect(params).toEqual(['fb-uid-1']);
    expect(result).toEqual({ id: 'user-1', firebaseUid: 'fb-uid-1', email: 'a@example.com', phone: '+15551234567' });
  });

  it('returns null for an unknown firebase_uid rather than throwing', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresUserRepository } = await import('../../../core/auth/postgres-user.repository');
    const repo = new PostgresUserRepository();

    const result = await repo.findByFirebaseUid('nonexistent-uid');
    expect(result).toBeNull();
  });

  it('create() inserts the four NOT NULL columns via the write pool, parameterized', async () => {
    const { writePool } = await import('../../../core/database/pg-pool');
    (writePool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      rows: [{ id: 'user-new', firebase_uid: 'fb-new', email: 'new@example.com', phone: '+15551234567' }],
    });
    const { PostgresUserRepository } = await import('../../../core/auth/postgres-user.repository');
    const repo = new PostgresUserRepository();

    const result = await repo.create({
      firebaseUid: 'fb-new',
      fullName: 'New User',
      email: 'new@example.com',
      phone: '+15551234567',
    });

    const [sql, params] = (writePool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('INSERT INTO identity.users');
    expect(sql).toContain('full_name');
    expect(sql).not.toContain('New User'); // never string-interpolated
    expect(params).toEqual(['New User', 'new@example.com', '+15551234567', 'fb-new']);
    expect(result).toEqual({ id: 'user-new', firebaseUid: 'fb-new', email: 'new@example.com', phone: '+15551234567' });
  });
});
