# Deployment Checklist

This project has been developed and audited in a sandbox with **no network egress, no
PostgreSQL/Redis, and no Docker** — every piece of infrastructure code here is real and
carefully reviewed, but **none of it has been executed against real services**. This
checklist is what a developer needs to actually run it on a real machine.

## 1. Prerequisites

- Node.js 20.x and npm
- A PostgreSQL 14+ instance (a fresh database is fine — migrations create everything)
- A Redis 6+ instance
- A Firebase project with Admin SDK access (Project Settings → Service Accounts →
  Generate new private key)
- Docker + Docker Compose (optional — only needed if you want containerized local
  Postgres/Redis via `docker-compose.yml`, or to build the production image)

## 2. Get dependencies and a real lockfile

No `package-lock.json` is committed — it could not be generated in the sandbox this
project was built in (no registry access). Generate one for real, on your machine:

```bash
npm install
```

This also creates `node_modules`. **Commit the resulting `package-lock.json`** once
generated — after that, switch `Dockerfile`'s `RUN npm install` back to `RUN npm ci`
(faster, reproducible builds) — see the comment already in the Dockerfile marking
exactly where.

## 3. Configure environment

```bash
cp .env.example .env
```

Then fill in real values:

| Variable | Where to get it |
|---|---|
| `DATABASE_URL` | Your PostgreSQL connection string |
| `REDIS_URL` | Your Redis connection string |
| `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` | Generate two **different**, ≥32-character random values: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` (run twice) |
| `FIREBASE_PROJECT_ID` / `FIREBASE_CLIENT_EMAIL` / `FIREBASE_PRIVATE_KEY` | From the service-account JSON you downloaded in step 1. Keep `FIREBASE_PRIVATE_KEY`'s `\n` sequences literal — the app unescapes them at startup. |
| `ALLOWED_ORIGINS` | Comma-separated list of real frontend origin(s) |

**Never commit `.env`.** It's already covered by `.dockerignore`; add it to `.gitignore`
too if this repository is put under git.

In production (`NODE_ENV=production`), the app will refuse to start if any required
variable above is missing, too short, or an obviously-default placeholder — this is
intentional (`core/config/env.schema.ts`).

## 4. Build

```bash
npm run build
```

Verify it actually produced output:

```bash
test -f dist/server.js && test -f dist/scripts/migrate.js && echo OK
```

## 5. Run database migrations

```bash
npm run migrate
```

This connects to `DATABASE_URL`, creates a `schema_migrations` tracking table if
missing, and applies every `migrations/*.sql` file not already recorded, in order,
each inside its own transaction.

## 6. Start the server

```bash
npm run start
```

Or for local development against real Postgres/Redis containers:

```bash
docker compose up -d   # starts local Postgres + Redis only, per docker-compose.yml
npm run migrate
npm run start
```

## 7. Verify it's actually running

```bash
curl http://localhost:3000/healthz
# {"status":"ok"}

curl http://localhost:3000/readyz
# {"status":"ok","checks":{"database":"ok","redis":"ok"}}
```

If `/readyz` returns `503` with `"status":"degraded"`, check which of `database`/`redis`
reports `"error"` and verify that connection.

## 8. Run tests and lint (optional but recommended before deploying)

```bash
npm test
npm run lint
```

Neither could be executed in the sandbox this project was built in (no registry
access to install `vitest`/`eslint`) — this is the first real opportunity to run them.

## 9. Docker (optional)

```bash
docker build -t nexfiy .
docker compose up -d          # Postgres + Redis for local dev
docker run --env-file .env -p 3000:3000 nexfiy
```

The Dockerfile was written carefully and reviewed but **never actually run** in the
sandbox this project was built in (no Docker binary was available there). This is the
first real opportunity to build and run the image.

## 10. Known, disclosed gaps (not bugs — genuinely out of scope until you provide the missing piece)

- **First-time user provisioning** (`POST /auth/verify` for a brand-new Firebase user)
  requires the client to also send `fullName` (always) and `email`/`phone` (only if
  Firebase's token didn't already supply them) — see
  `modules/auth/application/verify-identity.usecase.ts` for exactly why these can't be
  auto-filled.
- **Refresh-token revocation** works, but there's no admin/support tooling yet to
  manually revoke a specific user's sessions outside the automatic replay-detection
  path.
- **Redis permission cache** has no explicit invalidation hook wired to a role/permission
  admin flow, because no such admin flow exists yet in this repository (Product-module
  scope only, throughout).
