/**
 * Day 17 — pure, unit-testable core of the migration runner: given the full list of
 * migration filenames on disk and the set already recorded as applied, returns exactly
 * which ones still need to run, IN ORDER. Filename-lexical order is what makes this
 * safe — every migration in this repo is already numbered (0021_..., 0022_...), so
 * sorted-filename order IS dependency order.
 *
 * Split out from scripts/migrate.ts (the real I/O — reading the migrations directory,
 * connecting to Postgres, running each file in a transaction) so this specific logic —
 * the part a bug in could genuinely apply migrations out of order or skip/re-run one —
 * is testable without a live database.
 */
export function pendingMigrations(allFilenames: string[], alreadyApplied: ReadonlySet<string>): string[] {
  return allFilenames
    .filter((name) => name.endsWith('.sql'))
    .sort()
    .filter((name) => !alreadyApplied.has(name));
}
