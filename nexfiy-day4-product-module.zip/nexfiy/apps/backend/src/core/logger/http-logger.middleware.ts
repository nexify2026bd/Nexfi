import { NextFunction, Request, Response } from 'express';
import { logger } from './logger';
import { getRequestId } from './request-context';

/**
 * Day 10/11 STEP 9 — no request/access logging middleware existed anywhere in this
 * repository before this (confirmed absent in the Day 10 audit; Day 3's design
 * document described one but it was never actually filed as code).
 *
 * Logs ONLY: correlation ID, HTTP method, route, status code, duration. Deliberately
 * does NOT log the Authorization header, any request body, query params, or headers in
 * general — logging any of those would risk leaking a bearer token, and even once real
 * authentication exists, the token itself must never appear in logs.
 */
export function httpLogger(req: Request, res: Response, next: NextFunction): void {
  const startedAt = Date.now();

  res.on('finish', () => {
    logger.info(
      {
        requestId: getRequestId(),
        method: req.method,
        route: req.route?.path ?? req.path,
        statusCode: res.statusCode,
        durationMs: Date.now() - startedAt,
      },
      'http.request',
    );
  });

  next();
}
