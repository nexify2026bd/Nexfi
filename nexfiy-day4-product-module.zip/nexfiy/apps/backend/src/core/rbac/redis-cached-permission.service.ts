import { redisCacheClient } from '../cache/redis-client';
import { logger } from '../logger/logger';
import { IPermissionService } from './permission.service.port';

const CACHE_KEY_PREFIX = 'permissions:'; // Day 3 §3.2
const CACHE_TTL_SECONDS = 600; // 10 minutes, per Day 3 §3.2

/**
 * Day 13 — Day 3 §3.2's permission cache, wrapping a real IPermissionService (cache-
 * aside pattern). Cache-only failures never affect correctness, only latency:
 *
 * - Redis GET failure → falls through to the wrapped service (Postgres) directly. A
 *   Redis outage degrades to "every request hits the DB", never to "grant access
 *   without checking" — the actual permission decision always comes from the real
 *   source of truth either way.
 * - Redis SET failure (after a successful DB lookup) → logged, swallowed, the correct
 *   result is still returned to the caller. A cache write failing must not fail the
 *   request that already got its real answer from Postgres.
 * - Values are cached ONLY after a successful database lookup (never speculatively,
 *   never on a failure path) — an errored lookup is never cached as if it succeeded.
 *
 * invalidateUser() exists for a future admin/role-management flow to call after
 * changing a user's roles — no such flow exists anywhere in this repository yet (no
 * admin endpoints were ever built, Product-module-only scope throughout), so nothing
 * currently calls it. Documented here rather than silently omitted.
 */
export class RedisCachedPermissionService implements IPermissionService {
  constructor(private readonly source: IPermissionService) {}

  async getPermissionsForUser(userId: string): Promise<string[]> {
    const key = CACHE_KEY_PREFIX + userId;

    try {
      const cached = await redisCacheClient.get(key);
      if (cached !== null) {
        return JSON.parse(cached) as string[];
      }
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'permission-cache.read-failed');
      // fall through to the database — do NOT grant access, do NOT fail the request
    }

    const permissions = await this.source.getPermissionsForUser(userId);

    try {
      await redisCacheClient.set(key, JSON.stringify(permissions), 'EX', CACHE_TTL_SECONDS);
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'permission-cache.write-failed');
      // the caller still gets the correct (uncached) result below
    }

    return permissions;
  }

  async invalidateUser(userId: string): Promise<void> {
    try {
      await redisCacheClient.del(CACHE_KEY_PREFIX + userId);
    } catch (err) {
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'permission-cache.invalidate-failed');
      // best-effort: a stale cache entry expires within CACHE_TTL_SECONDS regardless
    }
  }
}
