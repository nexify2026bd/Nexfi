import { AuthenticatedIdentity } from '../types/express';

export interface IPolicy<TResource> {
  can(actor: AuthenticatedIdentity, action: string, resource?: TResource): boolean | Promise<boolean>;
}

/**
 * Day 3 §3.3 — the extension point resource-owning modules register policies against.
 * Day 4 registers ONE policy: "a seller may only mutate their own product." No
 * authorization logic is hard-coded in the Product controller (rule §7/§20).
 */
export class PolicyEngine {
  private policies = new Map<string, IPolicy<unknown>>();

  register<TResource>(resourceType: string, policy: IPolicy<TResource>): void {
    this.policies.set(resourceType, policy as IPolicy<unknown>);
  }

  async can<TResource>(
    resourceType: string,
    actor: AuthenticatedIdentity,
    action: string,
    resource?: TResource,
  ): Promise<boolean> {
    const policy = this.policies.get(resourceType);
    if (!policy) return true; // no resource-level policy registered → permission check alone governs
    return policy.can(actor, action, resource);
  }
}

export const policyEngine = new PolicyEngine();
