import { createHash } from 'crypto';
import { writePool, readPool } from '../database/pg-pool';
import { IRefreshTokenRepository, StoredRefreshToken } from './refresh-token.repository.port';

/** SHA-256, not a password hash (argon2/bcrypt) — a refresh token is already a
 *  high-entropy random-looking JWT, not a low-entropy human-chosen secret. The purpose
 *  of hashing here is solely "a DB read/leak doesn't hand over a live, replayable
 *  token" (Day 2 §1 comment: "never store raw token"), which a fast cryptographic hash
 *  already achieves — a slow password-hashing KDF would add cost with no real benefit
 *  against this specific threat model. */
export function hashRefreshToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/**
 * Day 13 — real implementation of IRefreshTokenRepository against the actual
 * identity.refresh_tokens table (Day 2 §1, migrated in 0022_add_refresh_tokens.sql).
 * Real parameterized SQL, not fabricated — but like PostgresPermissionService, verified
 * by inspection and mocked-pool unit tests, not a live database run (no DB access in
 * this environment).
 */
export class PostgresRefreshTokenRepository implements IRefreshTokenRepository {
  async store(tokenHash: string, userId: string, expiresAt: Date, deviceInfo?: string): Promise<void> {
    await writePool.query(
      `INSERT INTO identity.refresh_tokens (user_id, token_hash, device_info, expires_at)
       VALUES ($1, $2, $3, $4)`,
      [userId, tokenHash, deviceInfo ?? null, expiresAt],
    );
  }

  async findByHash(tokenHash: string): Promise<StoredRefreshToken | null> {
    const result = await readPool.query<{ user_id: string; expires_at: Date; revoked_at: Date | null }>(
      `SELECT user_id, expires_at, revoked_at
         FROM identity.refresh_tokens
        WHERE token_hash = $1`,
      [tokenHash],
    );
    const row = result.rows[0];
    if (!row) return null;
    return { userId: row.user_id, expiresAt: row.expires_at, revokedAt: row.revoked_at };
  }

  async revoke(tokenHash: string): Promise<void> {
    await writePool.query(
      `UPDATE identity.refresh_tokens
          SET revoked_at = now()
        WHERE token_hash = $1 AND revoked_at IS NULL`,
      [tokenHash],
    );
  }

  async revokeAllForUser(userId: string): Promise<void> {
    await writePool.query(
      `UPDATE identity.refresh_tokens
          SET revoked_at = now()
        WHERE user_id = $1 AND revoked_at IS NULL`,
      [userId],
    );
  }
}
