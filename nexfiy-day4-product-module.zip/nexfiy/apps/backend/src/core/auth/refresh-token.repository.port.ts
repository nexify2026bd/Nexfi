/**
 * Day 13 — typed port for refresh-token persistence, per the Day 3 folder structure
 * (`core/auth/refresh-token.repository.ts # impl of IRefreshTokenRepository`) and the
 * Day 2 identity.refresh_tokens schema. Consumed by RealAuthTokenService; never
 * consumed directly by controllers/middleware.
 */
export interface StoredRefreshToken {
  userId: string;
  expiresAt: Date;
  revokedAt: Date | null;
}

export interface IRefreshTokenRepository {
  /** Persists a NEW refresh token's hash (never the raw token). */
  store(tokenHash: string, userId: string, expiresAt: Date, deviceInfo?: string): Promise<void>;

  /** Looks up a token by its hash. Returns null if no row exists (unknown token). */
  findByHash(tokenHash: string): Promise<StoredRefreshToken | null>;

  /** Marks a token's row as revoked (idempotent — revoking an already-revoked or
   *  unknown token is not an error, matching typical revoke-endpoint semantics). */
  revoke(tokenHash: string): Promise<void>;

  /** Revokes every non-revoked refresh token for a user. Used when a rotated (already-
   *  used) refresh token is presented again — per Day 3 §2.3, reuse of a rotated token
   *  is treated as a signal of possible theft, and the correct response is to burn the
   *  entire session, not just the one replayed token. */
  revokeAllForUser(userId: string): Promise<void>;
}
