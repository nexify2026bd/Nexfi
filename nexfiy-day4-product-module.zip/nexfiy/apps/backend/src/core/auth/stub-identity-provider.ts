import { IIdentityProvider } from './auth.ports';

/**
 * Day 13 — non-production stand-in for IIdentityProvider, matching the existing
 * StubAuthTokenService/StubPermissionService pattern exactly (fixed, non-verifying
 * response; own constructor production-guard as defense in depth). Needed because
 * FirebaseIdentityProvider's constructor legitimately throws without real Firebase
 * config — without this stub, importing the auth module in test/local-dev (where no
 * Firebase project is configured) would break outright, the same class of bug the
 * other two services already solved.
 */
export class StubIdentityProvider implements IIdentityProvider {
  constructor() {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        'FATAL: StubIdentityProvider performs no real Firebase verification and must never be ' +
          'instantiated with NODE_ENV=production. Configure FIREBASE_PROJECT_ID/CLIENT_EMAIL/' +
          'PRIVATE_KEY so FirebaseIdentityProvider is used instead.',
      );
    }
  }

  async verifyIdentityToken(_idToken: string): Promise<{ uid: string; email?: string; phone?: string }> {
    return { uid: 'stub-firebase-uid', email: 'stub@example.com' };
  }
}
