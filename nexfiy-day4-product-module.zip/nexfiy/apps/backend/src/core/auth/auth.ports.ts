/**
 * Day 10 production-readiness audit: these interfaces were described in prose in the
 * Day 3 architecture document (§2.2 "Interfaces (Application layer ports)") but no
 * actual TypeScript file existed for them anywhere in this repository — only the stub
 * `authenticate.middleware.ts` referenced them in a comment. This file is the minimum
 * safe abstraction the Day 10 prompt asks for: a concrete, typed contract for a future
 * engineer to implement against. It contains NO implementation and NO fake/simulated
 * token verification — creating that would violate the explicit "do not create fake
 * authentication" instruction. Wiring a real implementation of these interfaces (backed
 * by Firebase Admin SDK + real JWT signing/verification, per Day 3 §2) is the actual
 * missing production dependency; see authenticate.middleware.ts for the fail-fast guard
 * that prevents the current stub from ever running unnoticed in production.
 */

export interface TokenPayload {
  userId: string;
  roles: string[];
}

export interface IAuthTokenService {
  issueTokenPair(payload: TokenPayload): Promise<{ accessToken: string; refreshToken: string }>;
  verifyAccessToken(token: string): Promise<TokenPayload>;
  rotateRefreshToken(oldToken: string): Promise<{ accessToken: string; refreshToken: string }>;
  revokeRefreshToken(token: string): Promise<void>;
}

export interface IIdentityProvider {
  verifyIdentityToken(idToken: string): Promise<{ uid: string; email?: string; phone?: string }>;
}
