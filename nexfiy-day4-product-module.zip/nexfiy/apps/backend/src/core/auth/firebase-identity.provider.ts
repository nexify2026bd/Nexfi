import { env } from '../config/env.schema';
import { AuthError } from '../errors/error-catalog';
import { IIdentityProvider } from './auth.ports';

/**
 * Day 13 — real implementation of IIdentityProvider using the Firebase Admin SDK, per
 * Day 3 §2.1/§2.4. This is the ONE-TIME login/registration handshake step (verifying a
 * client-obtained Firebase ID token), distinct from RealAuthTokenService which verifies
 * NEXFIY's own subsequently-issued JWT on every other request.
 *
 * Environment note: `firebase-admin` cannot be installed or executed in this sandbox
 * (no network egress — confirmed, same limitation as every other package all along).
 * This class is written against firebase-admin's stable, documented
 * `admin.auth().verifyIdToken()` API and is real, correct integration code — but it has
 * never actually run against the real package or a real Firebase project here, and I
 * did not fabricate a project/credentials to test against. It requires:
 *   1. `npm install firebase-admin` to actually succeed (blocked here, not fabricated).
 *   2. Real FIREBASE_PROJECT_ID/FIREBASE_CLIENT_EMAIL/FIREBASE_PRIVATE_KEY values from
 *      an actual Firebase project — which only you can provide.
 * Until both are true, this class is a correct-by-inspection provider boundary, not a
 * verified-working one.
 */
export class FirebaseIdentityProvider implements IIdentityProvider {
  constructor() {
    if (!env.FIREBASE_PROJECT_ID || !env.FIREBASE_CLIENT_EMAIL || !env.FIREBASE_PRIVATE_KEY) {
      throw new Error(
        'FATAL: FirebaseIdentityProvider requires FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, and ' +
          'FIREBASE_PRIVATE_KEY to be set. Validated by env.schema.ts in production; this constructor ' +
          'guards against direct instantiation with missing config in any environment.',
      );
    }
  }

  async verifyIdentityToken(idToken: string): Promise<{ uid: string; email?: string; phone?: string }> {
    // Lazy require: firebase-admin is a real dependency (package.json), but importing it
    // at module load time would break every test/dev run in this sandbox where it was
    // never actually installable. Lazy-requiring inside the method means this class is
    // fully loadable and its constructor-guard testable without the package present;
    // only an actual call to verifyIdentityToken needs it to exist.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const admin = require('firebase-admin');

    if (!admin.apps?.length) {
      admin.initializeApp({
        credential: admin.credential.cert({
          projectId: env.FIREBASE_PROJECT_ID,
          clientEmail: env.FIREBASE_CLIENT_EMAIL,
          // Firebase service-account JSON escapes newlines as literal "\n" — env vars
          // universally do the same, so this unescape step is required, not optional.
          privateKey: env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        }),
      });
    }

    let decoded: { uid: string; email?: string; phone_number?: string };
    try {
      decoded = await admin.auth().verifyIdToken(idToken);
    } catch {
      // Never leak the underlying Firebase SDK error (may include internal details) —
      // same principle as RealAuthTokenService's own JWT error handling.
      throw new AuthError('Invalid identity token');
    }

    return { uid: decoded.uid, email: decoded.email, phone: decoded.phone_number };
  }
}
