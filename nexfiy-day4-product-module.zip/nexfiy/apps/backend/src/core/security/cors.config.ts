import { NextFunction, Request, Response } from 'express';
import { env } from '../config/env.schema';

/**
 * Day 10/11 STEP 8 — no CORS implementation existed anywhere in this repository before
 * this (confirmed absent in the Day 10 audit). Minimal, dependency-free middleware
 * (avoids adding an unverifiable third-party package in an environment where installs
 * can't be tested — see the type-check/test/lint sections of the final report).
 *
 * Origin allow-list is environment-driven via ALLOWED_ORIGINS (comma-separated). Never
 * a wildcard in production: the guard below refuses to boot if production has no
 * origins configured, and even once configured, only an exact match from that list is
 * ever echoed back — never '*'. In non-production with no ALLOWED_ORIGINS set, requests
 * are allowed through unrestricted, purely for local-dev convenience (no CORS policy
 * existed before this file, so this is strictly additive, not a loosening of anything).
 */
const allowedOrigins = env.ALLOWED_ORIGINS.split(',')
  .map((o) => o.trim())
  .filter(Boolean);

if (env.NODE_ENV === 'production' && allowedOrigins.length === 0) {
  throw new Error(
    'FATAL: ALLOWED_ORIGINS must be set to a comma-separated list of allowed origins in ' +
      'production — refusing to start with an unrestricted or unconfigured CORS policy.',
  );
}

export function corsMiddleware(req: Request, res: Response, next: NextFunction): void {
  const origin = req.header('origin');
  const permissiveDevFallback = env.NODE_ENV !== 'production' && allowedOrigins.length === 0;

  if (origin && (allowedOrigins.includes(origin) || permissiveDevFallback)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  }
  // Origin present but not allowed: no CORS headers are set, so the browser withholds
  // the response from the calling page's JS — the standard CORS deny path, not a thrown
  // error (the request may still complete server-side; the enforcement is browser-side).

  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
}
