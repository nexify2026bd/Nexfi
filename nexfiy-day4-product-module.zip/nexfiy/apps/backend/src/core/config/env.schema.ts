import { z } from 'zod';

/**
 * Day 10/11 STEP 7 — minimal typed environment configuration layer, replacing
 * core/config-placeholder.ts (deleted). Validates shape at import time; fails fast in
 * production if a variable that's actually REQUIRED for a live deployment is missing —
 * but stays lenient in non-production so existing tests (which don't set a real
 * DATABASE_URL/REDIS_URL in this sandbox) continue to import and run unaffected, exactly
 * matching the pattern already established by the NODE_ENV==='production' guards in
 * authenticate.middleware.ts and rbac.middleware.ts.
 *
 * UPDATED (this round): a real IAuthTokenService now exists (RealAuthTokenService,
 * core/auth/real-auth-token.service.ts) implementing NEXFIY's own JWT issuance/
 * verification per Day 3 §2.2-2.3 — it reads JWT_ACCESS_SECRET/JWT_REFRESH_SECRET,
 * both listed here and required in production. This does NOT include Firebase Admin SDK
 * config (FIREBASE_PROJECT_ID/CLIENT_EMAIL/PRIVATE_KEY, per Day 1 §15): those are only
 * needed for the /auth/verify login handshake (Day 3 §2.4 step 1-2), which is a
 * different, not-yet-built route — this repository only ever verifies NEXFIY's own
 * already-issued access token, never a raw Firebase ID token. If/when that login route
 * is built, its Firebase config must be added here the same way.
 */
const EnvSchema = z.object({
  NODE_ENV: z.string().default('development'),
  DATABASE_URL: z.string().optional().default(''),
  DATABASE_READ_REPLICA_URL: z.string().optional(),
  REDIS_URL: z.string().optional().default('redis://localhost:6379'),
  PRODUCT_CACHE_TTL_SECONDS: z.coerce.number().int().positive().default(300),
  ALLOWED_ORIGINS: z.string().optional().default(''), // comma-separated, see core/http/cors.config.ts
  PORT: z.coerce.number().int().min(1).max(65535).optional().default(3000),
  SHUTDOWN_TIMEOUT_MS: z.coerce.number().int().positive().optional().default(10000),
  JWT_ACCESS_SECRET: z.string().optional().default(''), // required in production, see below
  JWT_REFRESH_SECRET: z.string().optional().default(''), // required in production, see below
  JWT_ACCESS_EXPIRY: z.string().optional().default('15m'),
  JWT_REFRESH_EXPIRY: z.string().optional().default('30d'),
  FIREBASE_PROJECT_ID: z.string().optional().default(''),
  FIREBASE_CLIENT_EMAIL: z.string().optional().default(''),
  FIREBASE_PRIVATE_KEY: z.string().optional().default(''),
});

export type Env = z.infer<typeof EnvSchema>;

/** Keys with no safe default that a real production deployment cannot run without. */
const REQUIRED_IN_PRODUCTION: Array<keyof Env> = [
  'DATABASE_URL',
  'REDIS_URL',
  'JWT_ACCESS_SECRET',
  'JWT_REFRESH_SECRET',
  'FIREBASE_PROJECT_ID',
  'FIREBASE_CLIENT_EMAIL',
  'FIREBASE_PRIVATE_KEY',
];

/** Values that are obviously unsafe as an HMAC signing secret — trivially guessable,
 *  or common copy-paste placeholders left in .env.example files. This is defense in
 *  depth, NOT the primary control — the length check below is what actually matters
 *  cryptographically (a 256-bit HMAC-SHA256 key should be at least 32 bytes; we require
 *  32 characters as a practical floor). Includes both short obvious values AND longer
 *  template-style placeholders (≥32 chars) that would otherwise slip past the length
 *  check unchanged — a blocklist of only short values would never fire, since the
 *  length check always rejects those first. */
const OBVIOUSLY_WEAK_SECRETS = new Set([
  'secret',
  'changeme',
  'change-me',
  'password',
  'test',
  'example',
  'default',
  'jwt_secret',
  'jwtsecret',
  '12345678',
  'your-secret-key-here-change-this-in-production',
  'replace-with-your-secret-key-min-32-characters',
  'replace_with_your_secret_key_min_32_characters',
  'change-this-to-a-random-secret-in-production-min-32-chars',
]);

const MIN_SECRET_LENGTH = 32;

function loadEnv(): Env {
  const parsed = EnvSchema.safeParse(process.env);
  if (!parsed.success) {
    throw new Error(`FATAL: invalid environment configuration — ${parsed.error.message}`);
  }
  const env = parsed.data;

  if (env.NODE_ENV === 'production') {
    const missing = REQUIRED_IN_PRODUCTION.filter((key) => {
      const value = env[key];
      return typeof value !== 'string' || value.length === 0;
    });
    if (missing.length > 0) {
      throw new Error(
        `FATAL: missing required production environment variable(s): ${missing.join(', ')}. ` +
          'The application refuses to start rather than run with unsafe defaults.',
      );
    }

    // STEP 3 (deep audit): non-empty is not the same as safe. A short or obviously
    // default JWT secret lets anyone forge valid tokens — the app must refuse to start
    // rather than boot with a guessable signing key.
    for (const key of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET'] as const) {
      const value = env[key];
      if (value.length < MIN_SECRET_LENGTH) {
        throw new Error(
          `FATAL: ${key} is too short (${value.length} chars, minimum ${MIN_SECRET_LENGTH}) to be a safe ` +
            'HMAC-SHA256 signing key. The application refuses to start with a weak secret.',
        );
      }
      if (OBVIOUSLY_WEAK_SECRETS.has(value.toLowerCase())) {
        throw new Error(`FATAL: ${key} is set to an obviously default/example value. Refusing to start.`);
      }
    }
    if (env.JWT_ACCESS_SECRET === env.JWT_REFRESH_SECRET) {
      throw new Error(
        'FATAL: JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must be different values — reusing the same ' +
          'secret for both lets a stolen access token be replayed as a refresh token (and vice versa).',
      );
    }
  }

  return env;
}

export const env = loadEnv();
