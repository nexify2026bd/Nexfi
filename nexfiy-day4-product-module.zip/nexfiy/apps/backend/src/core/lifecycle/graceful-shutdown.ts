import type { Server } from 'http';
import { logger } from '../logger/logger';

export interface ShutdownDeps {
  server: Pick<Server, 'close'>;
  cleanup: () => Promise<unknown>;
  timeoutMs: number;
  exit: (code: number) => void;
}

/**
 * Day 16 — graceful shutdown, extracted out of server.ts so it's unit-testable without
 * needing to actually bind a real HTTP port (server.ts calls `app.listen()` as a module-
 * level side effect on import, which would make directly importing/testing it start a
 * real listener — this function takes its dependencies as parameters instead).
 *
 * Sequence: stop accepting new connections → let in-flight requests finish (Node's
 * `server.close()` callback only fires once all active connections have ended) → run
 * the caller's cleanup (closing DB pools / Redis) → exit 0. A timer forces exit(1) if
 * any of that hangs, so a stuck connection can't block a deploy/restart indefinitely.
 * Guards against being invoked twice (e.g. SIGTERM followed immediately by SIGINT).
 */
export function createShutdownHandler(deps: ShutdownDeps): (signal: string) => Promise<void> {
  let shuttingDown = false;

  return async function shutdown(signal: string): Promise<void> {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info({ signal }, 'server.shutdown.start');

    const forceExitTimer = setTimeout(() => {
      logger.error({ signal }, 'server.shutdown.timeout — forcing exit');
      deps.exit(1);
    }, deps.timeoutMs);
    forceExitTimer.unref?.();

    await new Promise<void>((resolve) => {
      deps.server.close((err) => {
        if (err) {
          logger.error({ err: err.message }, 'server.shutdown.http-close-failed');
        }
        resolve();
      });
    });

    try {
      await deps.cleanup();
      logger.info({ signal }, 'server.shutdown.complete');
      clearTimeout(forceExitTimer);
      deps.exit(0);
    } catch (cleanupErr) {
      logger.error(
        { err: cleanupErr instanceof Error ? cleanupErr.message : String(cleanupErr) },
        'server.shutdown.cleanup-failed',
      );
      clearTimeout(forceExitTimer);
      deps.exit(1);
    }
  };
}
