import { DbTransaction } from '../../database/transaction-manager';
import { DomainEvent } from '../domain-event.base';

export interface IOutboxRepository {
  /** Writes the event row in the SAME transaction as the business write (Day 3 §8.4). */
  append(trx: DbTransaction, event: DomainEvent<unknown>): Promise<void>;
}

/**
 * Implementation writes to an `event_outbox` table (id, event_name, payload, correlation_id,
 * occurred_at, dispatched_at NULL). A separate relay worker (Day 3 §8.4, not part of the
 * request path) polls undispatched rows and publishes them to the Event Bus — guaranteeing
 * no event is lost to a crash between the DB commit and the publish step.
 */
export class PgOutboxRepository implements IOutboxRepository {
  async append(trx: DbTransaction, event: DomainEvent<unknown>): Promise<void> {
    await trx.query(
      `INSERT INTO audit.event_outbox (event_name, payload, correlation_id, occurred_at)
       VALUES ($1, $2, $3, $4)`,
      [event.eventName, JSON.stringify(event.payload), event.correlationId, event.occurredAt],
    );
  }
}
