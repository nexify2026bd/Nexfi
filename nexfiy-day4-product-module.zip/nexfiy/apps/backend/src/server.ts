import { createApp } from './app';
import { env } from './core/config/env.schema';
import { logger } from './core/logger/logger';
import { writePool, readPool } from './core/database/pg-pool';
import { redisCacheClient } from './core/cache/redis-client';
import { createShutdownHandler } from './core/lifecycle/graceful-shutdown';
import { createStartupErrorHandler } from './core/lifecycle/startup-error-handler';

/**
 * Day 16 — the actual runnable entrypoint. Previously absent entirely: app.ts only ever
 * exported `createApp()`; nothing anywhere called `.listen()` (confirmed by grepping the
 * whole repository). The application could not have been started as a real process
 * before now.
 *
 * uncaughtException/unhandledRejection: log with full detail server-side, then exit
 * non-zero — continuing to run after either is well-established bad practice, since the
 * process is in a state Node's own guarantees no longer cover. Graceful shutdown logic
 * itself lives in core/lifecycle/graceful-shutdown.ts (extracted so it's unit-testable
 * without this file's module-level `app.listen()` side effect getting in the way).
 */
const app = createApp();

const server = app.listen(env.PORT, () => {
  logger.info({ port: env.PORT, nodeEnv: env.NODE_ENV }, 'server.listening');
});

// Without this, a startup failure (e.g. EADDRINUSE — the port already in use) would
// still be caught by the uncaughtException handler below, since an EventEmitter throws
// an unhandled 'error' event as an uncaught exception — but with a generic message that
// doesn't say what actually went wrong. This gives a specific, actionable one instead.
server.on('error', createStartupErrorHandler(env.PORT, (code) => process.exit(code)));

const shutdown = createShutdownHandler({
  server,
  cleanup: () => Promise.all([writePool.end(), readPool.end(), redisCacheClient.quit()]),
  timeoutMs: env.SHUTDOWN_TIMEOUT_MS,
  exit: (code) => process.exit(code),
});

process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));

process.on('uncaughtException', (err) => {
  logger.error({ err: err.message, stack: err.stack }, 'process.uncaughtException');
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  logger.error({ reason: reason instanceof Error ? reason.message : String(reason) }, 'process.unhandledRejection');
  process.exit(1);
});
