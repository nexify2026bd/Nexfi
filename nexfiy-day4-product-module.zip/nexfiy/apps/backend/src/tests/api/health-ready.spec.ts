import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';

/**
 * Day 16 — tests for /healthz and /readyz. Mocks the pg pool and Redis client (no live
 * database/Redis in this environment) so /readyz's real ping behavior is exercised
 * against controlled success/failure responses rather than actually connecting anywhere.
 */
vi.mock('../../core/database/pg-pool', () => ({
  readPool: { query: vi.fn() },
  writePool: { query: vi.fn(), end: vi.fn() },
}));
vi.mock('../../core/cache/redis-client', () => ({
  redisCacheClient: { ping: vi.fn(), quit: vi.fn() },
}));

describe('/healthz and /readyz', () => {
  beforeEach(() => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
  });

  it('GET /healthz returns 200 with no dependency checks (pure liveness)', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { createApp } = await import('../../app');
    const app = createApp();

    const res = await request(app).get('/healthz');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
    expect(readPool.query).not.toHaveBeenCalled(); // liveness never touches dependencies
  });

  it('GET /readyz returns 200 when both PostgreSQL and Redis respond successfully', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { redisCacheClient } = await import('../../core/cache/redis-client');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [{ '?column?': 1 }] });
    (redisCacheClient.ping as ReturnType<typeof vi.fn>).mockResolvedValueOnce('PONG');
    const { createApp } = await import('../../app');
    const app = createApp();

    const res = await request(app).get('/readyz');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok', checks: { database: 'ok', redis: 'ok' } });
  });

  it('GET /readyz returns 503 when PostgreSQL is unreachable, without leaking the underlying error', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { redisCacheClient } = await import('../../core/cache/redis-client');
    (readPool.query as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('ECONNREFUSED 10.0.0.5:5432'));
    (redisCacheClient.ping as ReturnType<typeof vi.fn>).mockResolvedValueOnce('PONG');
    const { createApp } = await import('../../app');
    const app = createApp();

    const res = await request(app).get('/readyz');
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ status: 'degraded', checks: { database: 'error', redis: 'ok' } });
    expect(JSON.stringify(res.body)).not.toContain('10.0.0.5'); // no internal connection details leaked
  });

  it('GET /readyz returns 503 when Redis is unreachable', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { redisCacheClient } = await import('../../core/cache/redis-client');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    (redisCacheClient.ping as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('ECONNREFUSED'));
    const { createApp } = await import('../../app');
    const app = createApp();

    const res = await request(app).get('/readyz');
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ status: 'degraded', checks: { database: 'ok', redis: 'error' } });
  });

  it('GET /readyz returns 503 when both PostgreSQL and Redis are unreachable', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { redisCacheClient } = await import('../../core/cache/redis-client');
    (readPool.query as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('down'));
    (redisCacheClient.ping as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('down'));
    const { createApp } = await import('../../app');
    const app = createApp();

    const res = await request(app).get('/readyz');
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ status: 'degraded', checks: { database: 'error', redis: 'error' } });
  });

  it('/healthz and /readyz are not rate-limited or authenticated (available before any middleware that would block them)', async () => {
    const { readPool } = await import('../../core/database/pg-pool');
    const { redisCacheClient } = await import('../../core/cache/redis-client');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValue({ rows: [] });
    (redisCacheClient.ping as ReturnType<typeof vi.fn>).mockResolvedValue('PONG');
    const { createApp } = await import('../../app');
    const app = createApp();

    // hit /readyz far more than the auth-verify rate limit (10/60s) would allow —
    // confirms these routes share no rate-limit state with /auth/verify
    for (let i = 0; i < 15; i++) {
      const res = await request(app).get('/healthz');
      expect(res.status).toBe(200);
    }
  });
});
