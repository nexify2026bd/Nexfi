import { describe, it, expect, beforeEach, vi } from 'vitest';

/**
 * Day 10/11 STEP 10 item 12: production CORS does not allow arbitrary origins.
 * UPDATED (Day 13): now sets every other production-required var (JWT/Firebase) so
 * these tests exercise CORS's own check specifically, not env.schema's unrelated
 * fail-fast (a prior gap — this file never set JWT secrets either, so its first test
 * had been silently matching the wrong thrown error's message pattern since the round
 * JWT became required; caught and fixed here).
 */
const FULL_PRODUCTION_ENV = {
  DATABASE_URL: 'postgres://example-not-a-real-credential/db',
  REDIS_URL: 'redis://example-not-a-real-credential:6379',
  JWT_ACCESS_SECRET: 'access-secret-that-is-at-least-32-characters-long',
  JWT_REFRESH_SECRET: 'refresh-secret-that-is-at-least-32-characters-long',
  FIREBASE_PROJECT_ID: 'example-not-a-real-project',
  FIREBASE_CLIENT_EMAIL: 'example@example-not-a-real-project.iam.gserviceaccount.com',
  FIREBASE_PRIVATE_KEY: 'example-not-a-real-private-key',
};

describe('corsMiddleware — production origin restriction', () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
    process.env = { ...originalEnv };
  });

  it('throws at import time when NODE_ENV=production and ALLOWED_ORIGINS is unset (all other required vars present)', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, FULL_PRODUCTION_ENV);
    delete process.env.ALLOWED_ORIGINS;
    await expect(import('../../../core/security/cors.config')).rejects.toThrow(/ALLOWED_ORIGINS must be set/);
  });

  it('in production with ALLOWED_ORIGINS configured, echoes back only a listed origin, never a wildcard', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, FULL_PRODUCTION_ENV);
    process.env.ALLOWED_ORIGINS = 'https://app.example.com';
    const { corsMiddleware } = await import('../../../core/security/cors.config');

    const headers: Record<string, string> = {};
    const req = { header: () => 'https://app.example.com', method: 'GET' } as never;
    const res = { setHeader: (k: string, v: string) => (headers[k] = v), sendStatus: vi.fn() } as never;
    const next = vi.fn();

    corsMiddleware(req, res, next);
    expect(headers['Access-Control-Allow-Origin']).toBe('https://app.example.com');
    expect(headers['Access-Control-Allow-Origin']).not.toBe('*');
    expect(next).toHaveBeenCalled();
  });

  it('in production, an origin NOT on the allow-list receives no CORS headers', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, FULL_PRODUCTION_ENV);
    process.env.ALLOWED_ORIGINS = 'https://app.example.com';
    const { corsMiddleware } = await import('../../../core/security/cors.config');

    const headers: Record<string, string> = {};
    const req = { header: () => 'https://evil.example.com', method: 'GET' } as never;
    const res = { setHeader: (k: string, v: string) => (headers[k] = v), sendStatus: vi.fn() } as never;
    const next = vi.fn();

    corsMiddleware(req, res, next);
    expect(headers['Access-Control-Allow-Origin']).toBeUndefined();
  });
});
