import { describe, it, expect, vi } from 'vitest';
import { createShutdownHandler } from '../../../core/lifecycle/graceful-shutdown';

vi.mock('../../../core/logger/logger', () => ({
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
}));

describe('createShutdownHandler', () => {
  it('closes the HTTP server, runs cleanup, then exits 0 on success', async () => {
    const close = vi.fn((cb: (err?: Error) => void) => cb());
    const cleanup = vi.fn().mockResolvedValue(undefined);
    const exit = vi.fn();
    const shutdown = createShutdownHandler({ server: { close }, cleanup, timeoutMs: 5000, exit });

    await shutdown('SIGTERM');

    expect(close).toHaveBeenCalledTimes(1);
    expect(cleanup).toHaveBeenCalledTimes(1);
    expect(exit).toHaveBeenCalledWith(0);
  });

  it('waits for server.close() to finish (in-flight requests) before running cleanup', async () => {
    const order: string[] = [];
    const close = vi.fn((cb: (err?: Error) => void) => {
      order.push('server-closed');
      cb();
    });
    const cleanup = vi.fn().mockImplementation(async () => {
      order.push('cleanup-ran');
    });
    const exit = vi.fn();
    const shutdown = createShutdownHandler({ server: { close }, cleanup, timeoutMs: 5000, exit });

    await shutdown('SIGTERM');
    expect(order).toEqual(['server-closed', 'cleanup-ran']);
  });

  it('exits 1 (not 0) when cleanup itself fails, rather than reporting a false success', async () => {
    const close = vi.fn((cb: (err?: Error) => void) => cb());
    const cleanup = vi.fn().mockRejectedValue(new Error('pool.end() failed'));
    const exit = vi.fn();
    const shutdown = createShutdownHandler({ server: { close }, cleanup, timeoutMs: 5000, exit });

    await shutdown('SIGTERM');
    expect(exit).toHaveBeenCalledWith(1);
  });

  it('ignores a second shutdown call while one is already in progress', async () => {
    let resolveClose: (() => void) | undefined;
    const close = vi.fn((cb: (err?: Error) => void) => {
      resolveClose = () => cb();
    });
    const cleanup = vi.fn().mockResolvedValue(undefined);
    const exit = vi.fn();
    const shutdown = createShutdownHandler({ server: { close }, cleanup, timeoutMs: 5000, exit });

    const first = shutdown('SIGTERM');
    const second = shutdown('SIGINT'); // arrives while the first is still mid-flight

    resolveClose?.();
    await Promise.all([first, second]);

    expect(close).toHaveBeenCalledTimes(1); // the second call was a no-op
    expect(cleanup).toHaveBeenCalledTimes(1);
  });

  it('forces exit(1) if cleanup hangs past the timeout', async () => {
    vi.useFakeTimers();
    try {
      const close = vi.fn((cb: (err?: Error) => void) => cb());
      const cleanup = vi.fn(() => new Promise(() => undefined)); // never resolves
      const exit = vi.fn();
      const shutdown = createShutdownHandler({ server: { close }, cleanup, timeoutMs: 1000, exit });

      const shutdownPromise = shutdown('SIGTERM');
      await vi.advanceTimersByTimeAsync(1000);
      await Promise.race([shutdownPromise, Promise.resolve()]);

      expect(exit).toHaveBeenCalledWith(1);
    } finally {
      vi.useRealTimers();
    }
  });
});
