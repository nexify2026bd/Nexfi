import { describe, it, expect, beforeEach, vi } from 'vitest';

/**
 * Day 10/11 STEP 10 items 1 & 3: confirms authentication and RBAC dependencies are
 * actually resolved through the shared DI container (not constructed inline), and that
 * resolving them twice returns the SAME singleton instance (container contract).
 */
describe('authentication/RBAC DI resolution', () => {
  beforeEach(() => {
    vi.resetModules();
    process.env.NODE_ENV = 'test';
  });

  it('IAuthTokenService is registered on and resolvable from the shared container after importing the auth middleware', async () => {
    const { container } = await import('../../../core/di/container');
    await import('../../../core/auth/authenticate.middleware');
    const instance = container.resolve('IAuthTokenService');
    expect(instance).toBeDefined();
    expect(container.resolve('IAuthTokenService')).toBe(instance); // singleton
  });

  it('IPermissionService is registered on and resolvable from the shared container after importing the rbac middleware', async () => {
    const { container } = await import('../../../core/di/container');
    await import('../../../core/rbac/rbac.middleware');
    const instance = container.resolve('IPermissionService');
    expect(instance).toBeDefined();
    expect(container.resolve('IPermissionService')).toBe(instance); // singleton
  });
});
