import { describe, it, expect, beforeEach, vi } from 'vitest';

/** Day 10/11 STEP 10 item 11 / Day 13: missing production configuration is rejected. */
const VALID_JWT = {
  JWT_ACCESS_SECRET: 'access-secret-that-is-at-least-32-characters-long',
  JWT_REFRESH_SECRET: 'refresh-secret-that-is-at-least-32-characters-long',
};
const VALID_FIREBASE = {
  FIREBASE_PROJECT_ID: 'example-not-a-real-project',
  FIREBASE_CLIENT_EMAIL: 'example@example-not-a-real-project.iam.gserviceaccount.com',
  FIREBASE_PRIVATE_KEY: 'example-not-a-real-private-key',
};
const VALID_DB = {
  DATABASE_URL: 'postgres://example-not-a-real-credential/db',
  REDIS_URL: 'redis://example-not-a-real-credential:6379',
};

describe('env.schema — production fail-fast', () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
    process.env = { ...originalEnv };
  });

  it('throws at import time when NODE_ENV=production and DATABASE_URL/REDIS_URL/Firebase config are missing', async () => {
    process.env.NODE_ENV = 'production';
    delete process.env.DATABASE_URL;
    delete process.env.REDIS_URL;
    await expect(import('../../../core/config/env.schema')).rejects.toThrow(
      /missing required production environment variable/,
    );
  });

  it('imports successfully in production when all required variables (DB, Redis, JWT, Firebase) are set to strong values', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_JWT, VALID_FIREBASE);
    const mod = await import('../../../core/config/env.schema');
    expect(mod.env.DATABASE_URL).toBe(VALID_DB.DATABASE_URL);
  });

  it('throws in production when a JWT secret is too short (all other required vars present)', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_FIREBASE);
    process.env.JWT_ACCESS_SECRET = 'too-short';
    process.env.JWT_REFRESH_SECRET = VALID_JWT.JWT_REFRESH_SECRET;
    await expect(import('../../../core/config/env.schema')).rejects.toThrow(/too short/);
  });

  it('throws in production when a JWT secret matches a known placeholder value (blocklist, independent of length)', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_FIREBASE);
    // ≥32 chars, so this exercises the blocklist branch specifically, not the length branch
    process.env.JWT_ACCESS_SECRET = 'your-secret-key-here-change-this-in-production';
    process.env.JWT_REFRESH_SECRET = VALID_JWT.JWT_REFRESH_SECRET;
    await expect(import('../../../core/config/env.schema')).rejects.toThrow(/default\/example/);
  });

  it('throws in production when JWT_ACCESS_SECRET and JWT_REFRESH_SECRET are identical', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_FIREBASE);
    const sameSecret = 'this-secret-is-reused-for-both-access-and-refresh';
    process.env.JWT_ACCESS_SECRET = sameSecret;
    process.env.JWT_REFRESH_SECRET = sameSecret;
    await expect(import('../../../core/config/env.schema')).rejects.toThrow(/must be different values/);
  });

  it('throws in production when Firebase config is missing even though DB/JWT are fully valid', async () => {
    process.env.NODE_ENV = 'production';
    Object.assign(process.env, VALID_DB, VALID_JWT);
    delete process.env.FIREBASE_PROJECT_ID;
    delete process.env.FIREBASE_CLIENT_EMAIL;
    delete process.env.FIREBASE_PRIVATE_KEY;
    await expect(import('../../../core/config/env.schema')).rejects.toThrow(/FIREBASE_PROJECT_ID/);
  });

  it('does not throw in non-production even with DATABASE_URL/REDIS_URL/Firebase config missing (test/dev convenience)', async () => {
    process.env.NODE_ENV = 'test';
    delete process.env.DATABASE_URL;
    delete process.env.FIREBASE_PROJECT_ID;
    const mod = await import('../../../core/config/env.schema');
    expect(mod.env.DATABASE_URL).toBe('');
  });
});
