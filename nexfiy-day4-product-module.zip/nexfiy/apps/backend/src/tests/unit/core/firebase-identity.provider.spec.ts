import { describe, it, expect, beforeEach, vi } from 'vitest';

/**
 * Day 13 — FirebaseIdentityProvider's constructor guard is fully testable without
 * `firebase-admin` installed (the lazy require only happens inside
 * verifyIdentityToken() — see the class doc comment for why). Testing verifyIdentityToken
 * itself against a real Firebase project is out of scope here (no credentials, no
 * network) — that remains a disclosed, unverified gap, not something faked with a mock
 * Firebase SDK response.
 */
describe('FirebaseIdentityProvider', () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
    process.env = { ...originalEnv };
  });

  it('constructor throws when Firebase config is missing', async () => {
    delete process.env.FIREBASE_PROJECT_ID;
    delete process.env.FIREBASE_CLIENT_EMAIL;
    delete process.env.FIREBASE_PRIVATE_KEY;
    const { FirebaseIdentityProvider } = await import('../../../core/auth/firebase-identity.provider');
    expect(() => new FirebaseIdentityProvider()).toThrow(/FIREBASE_PROJECT_ID/);
  });

  it('constructor succeeds when all three Firebase config values are present', async () => {
    process.env.FIREBASE_PROJECT_ID = 'example-not-a-real-project';
    process.env.FIREBASE_CLIENT_EMAIL = 'example@example-not-a-real-project.iam.gserviceaccount.com';
    process.env.FIREBASE_PRIVATE_KEY = 'example-not-a-real-private-key';
    const { FirebaseIdentityProvider } = await import('../../../core/auth/firebase-identity.provider');
    expect(() => new FirebaseIdentityProvider()).not.toThrow();
  });
});
