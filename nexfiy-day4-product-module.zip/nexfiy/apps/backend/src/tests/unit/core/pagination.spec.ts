import { describe, it, expect } from 'vitest';
import { decodeCursor, encodeCursor } from '../../../core/http/pagination';
import { ValidationError } from '../../../core/errors/error-catalog';

/**
 * Day 9 audit regression test: decodeCursor previously threw a plain Error, which meant
 * a malformed `?cursor=` query param surfaced as an uncaught 500 through the global error
 * handler instead of a proper 422 ValidationError. Locks in the fix.
 */
describe('decodeCursor', () => {
  it('round-trips a value encoded by encodeCursor', () => {
    const original = { createdAt: '2026-01-01T00:00:00.000Z', id: '018f2c9e-1a2b-7c3d-8e4f-1234567890ab' };
    expect(decodeCursor(encodeCursor(original))).toEqual(original);
  });

  it('throws ValidationError (not a plain Error) for garbage input, so it maps to 422 not 500', () => {
    expect(() => decodeCursor('not-valid-base64!!!')).toThrow(ValidationError);
  });

  it('throws ValidationError for well-formed base64 that decodes to non-JSON', () => {
    const notJson = Buffer.from('this is not json').toString('base64url');
    expect(() => decodeCursor(notJson)).toThrow(ValidationError);
  });

  it('throws ValidationError for valid JSON missing the required cursor fields', () => {
    const incomplete = Buffer.from(JSON.stringify({ createdAt: '2026-01-01T00:00:00.000Z' })).toString('base64url');
    expect(() => decodeCursor(incomplete)).toThrow(ValidationError);
  });

  it('throws ValidationError for an empty string', () => {
    expect(() => decodeCursor('')).toThrow(ValidationError);
  });
});
