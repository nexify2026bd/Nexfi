import { describe, it, expect } from 'vitest';
import { pendingMigrations } from '../../../core/database/migration-runner';

describe('pendingMigrations', () => {
  it('returns all .sql files in lexical (numeric-prefix) order when none are applied', () => {
    const result = pendingMigrations(['0022_add_refresh_tokens.sql', '0021_add_event_outbox.sql'], new Set());
    expect(result).toEqual(['0021_add_event_outbox.sql', '0022_add_refresh_tokens.sql']);
  });

  it('excludes filenames already recorded as applied', () => {
    const result = pendingMigrations(
      ['0021_add_event_outbox.sql', '0022_add_refresh_tokens.sql'],
      new Set(['0021_add_event_outbox.sql']),
    );
    expect(result).toEqual(['0022_add_refresh_tokens.sql']);
  });

  it('returns an empty array when everything is already applied', () => {
    const result = pendingMigrations(
      ['0021_add_event_outbox.sql'],
      new Set(['0021_add_event_outbox.sql']),
    );
    expect(result).toEqual([]);
  });

  it('ignores non-.sql files in the migrations directory (e.g. a stray README)', () => {
    const result = pendingMigrations(['0021_add_event_outbox.sql', 'README.md', '.gitkeep'], new Set());
    expect(result).toEqual(['0021_add_event_outbox.sql']);
  });

  it('never re-orders based on input array order — always sorts, regardless of readdir order', () => {
    const result = pendingMigrations(
      ['0022_add_refresh_tokens.sql', '0021_add_event_outbox.sql', '0020_earlier.sql'],
      new Set(),
    );
    expect(result).toEqual(['0020_earlier.sql', '0021_add_event_outbox.sql', '0022_add_refresh_tokens.sql']);
  });
});
