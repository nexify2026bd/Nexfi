import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { IPermissionService } from '../../../core/rbac/permission.service.port';

vi.mock('../../../core/cache/redis-client', () => ({
  redisCacheClient: { get: vi.fn(), set: vi.fn(), del: vi.fn() },
}));
vi.mock('../../../core/logger/logger', () => ({
  logger: { warn: vi.fn(), info: vi.fn(), error: vi.fn() },
}));

describe('RedisCachedPermissionService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('cache hit: returns the cached value and never calls the wrapped source', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.get as ReturnType<typeof vi.fn>).mockResolvedValueOnce(JSON.stringify(['product.read']));
    const source: IPermissionService = { getPermissionsForUser: vi.fn() };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    const result = await service.getPermissionsForUser('user-1');
    expect(result).toEqual(['product.read']);
    expect(source.getPermissionsForUser).not.toHaveBeenCalled();
  });

  it('cache miss: queries the source, then populates the cache with a TTL', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.get as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    (redisCacheClient.set as ReturnType<typeof vi.fn>).mockResolvedValueOnce('OK');
    const source: IPermissionService = { getPermissionsForUser: vi.fn().mockResolvedValueOnce(['product.create']) };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    const result = await service.getPermissionsForUser('user-2');
    expect(result).toEqual(['product.create']);
    expect(source.getPermissionsForUser).toHaveBeenCalledWith('user-2');
    expect(redisCacheClient.set).toHaveBeenCalledWith(
      'permissions:user-2',
      JSON.stringify(['product.create']),
      'EX',
      600,
    );
  });

  it('Redis GET failure: falls back to the source (Postgres) directly, never grants access implicitly', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.get as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('ECONNREFUSED'));
    (redisCacheClient.set as ReturnType<typeof vi.fn>).mockResolvedValueOnce('OK');
    const source: IPermissionService = { getPermissionsForUser: vi.fn().mockResolvedValueOnce(['product.read']) };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    const result = await service.getPermissionsForUser('user-3');
    expect(result).toEqual(['product.read']); // real DB answer, not an empty/permissive fallback
    expect(source.getPermissionsForUser).toHaveBeenCalledWith('user-3');
  });

  it('Redis SET failure after a successful DB lookup: still returns the correct result to the caller', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.get as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    (redisCacheClient.set as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('ECONNREFUSED'));
    const source: IPermissionService = { getPermissionsForUser: vi.fn().mockResolvedValueOnce(['product.update']) };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    const result = await service.getPermissionsForUser('user-4');
    expect(result).toEqual(['product.update']); // the cache-write failure doesn't fail the request
  });

  it('invalidateUser() deletes the correct cache key', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.del as ReturnType<typeof vi.fn>).mockResolvedValueOnce(1);
    const source: IPermissionService = { getPermissionsForUser: vi.fn() };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    await service.invalidateUser('user-5');
    expect(redisCacheClient.del).toHaveBeenCalledWith('permissions:user-5');
  });

  it('never caches a failed database lookup as if it succeeded', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.get as ReturnType<typeof vi.fn>).mockResolvedValueOnce(null);
    const source: IPermissionService = {
      getPermissionsForUser: vi.fn().mockRejectedValueOnce(new Error('connection terminated unexpectedly')),
    };
    const { RedisCachedPermissionService } = await import('../../../core/rbac/redis-cached-permission.service');
    const service = new RedisCachedPermissionService(source);

    await expect(service.getPermissionsForUser('user-6')).rejects.toThrow(/connection terminated/);
    expect(redisCacheClient.set).not.toHaveBeenCalled();
  });
});
