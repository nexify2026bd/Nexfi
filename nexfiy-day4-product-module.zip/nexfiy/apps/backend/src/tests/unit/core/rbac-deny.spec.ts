import { describe, it, expect, beforeEach } from 'vitest';
import { requirePermission } from '../../../core/rbac/rbac.middleware';
import { container } from '../../../core/di/container';
import { ForbiddenError } from '../../../core/errors/error-catalog';
import type { IPermissionService } from '../../../core/rbac/permission.service.port';

/**
 * Day 10/11 STEP 10 item 6: "authenticated identity without permission is rejected."
 * StubPermissionService grants all five permissions to every user unconditionally, so
 * the deny branch can never be exercised end-to-end against the real registered stub —
 * that is itself a disclosed limitation of the stub (see StubPermissionService doc
 * comment), not something to fake around. This test instead verifies the
 * requirePermission MIDDLEWARE's deny logic directly, by substituting a differently-
 * configured IPermissionService binding — proving the enforcement logic itself is
 * correct and will work the moment a real, varying implementation is registered.
 */
describe('requirePermission — deny branch', () => {
  const testContainer = container as unknown as { registerSingleton: <T>(t: string, f: () => T) => void };

  beforeEach(() => {
    const limitedPermissions: IPermissionService = {
      getPermissionsForUser: async () => ['product.read'], // no product.create
    };
    testContainer.registerSingleton('IPermissionService', () => limitedPermissions);
  });

  it('rejects an authenticated identity that lacks the required permission', async () => {
    const middleware = requirePermission('product.create');
    const req = { identity: { userId: 'user-without-create', roles: ['customer'] } } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };
    await middleware(req, {} as never, next as never);
    expect(caught).toBeInstanceOf(ForbiddenError);
  });

  it('allows an authenticated identity that has the required permission', async () => {
    const middleware = requirePermission('product.read');
    const req = { identity: { userId: 'user-with-read', roles: ['customer'] } } as never;
    let nextCalled = false;
    const next = () => {
      nextCalled = true;
    };
    await middleware(req, {} as never, next as never);
    expect(nextCalled).toBe(true);
  });

  it('rejects when no identity is attached at all (authenticate middleware did not run)', async () => {
    const middleware = requirePermission('product.read');
    const req = {} as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };
    await middleware(req, {} as never, next as never);
    expect(caught).toBeInstanceOf(ForbiddenError);
  });

  it('ignores a client-supplied permissions list on the request body/headers — permissions only ever come from the resolved IPermissionService keyed on the verified identity', async () => {
    const middleware = requirePermission('product.archive'); // NOT in the limited-permissions mock from beforeEach
    const req = {
      identity: { userId: 'user-without-archive', roles: ['customer'] },
      body: { permissions: ['product.archive'] }, // attempted spoof
      headers: { 'x-permissions': 'product.archive' }, // attempted spoof
    } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };
    await middleware(req, {} as never, next as never);
    expect(caught).toBeInstanceOf(ForbiddenError); // spoofed body/header permissions are never consulted
  });

  it('fails closed (denies) rather than granting access when the permission service throws (e.g. a database error)', async () => {
    const failingPermissions: IPermissionService = {
      getPermissionsForUser: async () => {
        throw new Error('connection terminated unexpectedly'); // simulated DB error
      },
    };
    testContainer.registerSingleton('IPermissionService', () => failingPermissions);

    const middleware = requirePermission('product.read');
    const req = { identity: { userId: 'any-user', roles: ['customer'] } } as never;
    let caught: unknown;
    let nextCalledWithoutError = false;
    const next = (err?: unknown) => {
      if (err) caught = err;
      else nextCalledWithoutError = true;
    };
    await middleware(req, {} as never, next as never);
    expect(nextCalledWithoutError).toBe(false); // access was never granted
    expect(caught).toBeInstanceOf(Error); // the error propagates to the global handler instead
  });
});
