import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { httpLogger } from '../../../core/logger/http-logger.middleware';
import { logger } from '../../../core/logger/logger';

/** Day 10/11 STEP 10 item 10: sensitive authentication information is never logged. */
describe('httpLogger', () => {
  let infoSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    infoSpy = vi.spyOn(logger, 'info').mockImplementation(() => undefined);
  });

  afterEach(() => {
    infoSpy.mockRestore();
  });

  it('logs only safe fields (requestId, method, route, statusCode, durationMs) — never the Authorization header', () => {
    const listeners: Record<string, () => void> = {};
    const req = {
      method: 'POST',
      path: '/api/v1/products',
      route: { path: '/products' },
      header: (name: string) => (name.toLowerCase() === 'authorization' ? 'Bearer super-secret-token' : undefined),
    } as never;
    const res = {
      statusCode: 201,
      on: (event: string, cb: () => void) => {
        listeners[event] = cb;
      },
    } as never;
    const next = vi.fn();

    httpLogger(req, res, next);
    expect(next).toHaveBeenCalled();

    listeners.finish(); // simulate response completion
    expect(infoSpy).toHaveBeenCalledTimes(1);

    const [fields] = infoSpy.mock.calls[0] as [Record<string, unknown>, string];
    expect(fields).toHaveProperty('method', 'POST');
    expect(fields).toHaveProperty('statusCode', 201);
    expect(fields).toHaveProperty('requestId');
    expect(fields).toHaveProperty('durationMs');

    const serialized = JSON.stringify(fields);
    expect(serialized).not.toContain('super-secret-token');
    expect(serialized.toLowerCase()).not.toContain('authorization');
    expect(serialized.toLowerCase()).not.toContain('bearer');
  });
});
