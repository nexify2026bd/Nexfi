import { describe, it, expect, vi } from 'vitest';

/**
 * Day 13 — query-shape tests for the real refresh-token repository, mocking the pg pool
 * (no live database in this environment). Verifies parameterization and the actual
 * table/column names against the Day 2 identity.refresh_tokens schema.
 */
vi.mock('../../../core/database/pg-pool', () => ({
  writePool: { query: vi.fn() },
  readPool: { query: vi.fn() },
}));

describe('PostgresRefreshTokenRepository', () => {
  it('store() inserts into identity.refresh_tokens with parameterized values', async () => {
    const { writePool } = await import('../../../core/database/pg-pool');
    (writePool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresRefreshTokenRepository, hashRefreshToken } = await import(
      '../../../core/auth/postgres-refresh-token.repository'
    );
    const repo = new PostgresRefreshTokenRepository();
    const hash = hashRefreshToken('some-raw-refresh-token');
    const expiresAt = new Date('2026-09-01T00:00:00Z');

    await repo.store(hash, 'user-abc', expiresAt);

    expect(writePool.query).toHaveBeenCalledTimes(1);
    const [sql, params] = (writePool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('identity.refresh_tokens');
    expect(sql).not.toContain('some-raw-refresh-token'); // never the raw token, never interpolated
    expect(params).toEqual(['user-abc', hash, null, expiresAt]);
  });

  it('hashRefreshToken never returns the raw token itself', async () => {
    const { hashRefreshToken } = await import('../../../core/auth/postgres-refresh-token.repository');
    const raw = 'a-raw-refresh-token-value';
    const hashed = hashRefreshToken(raw);
    expect(hashed).not.toBe(raw);
    expect(hashed).toMatch(/^[a-f0-9]{64}$/); // sha256 hex digest shape
  });

  it('findByHash() queries by token_hash and returns null for an unknown hash', async () => {
    const { readPool } = await import('../../../core/database/pg-pool');
    (readPool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresRefreshTokenRepository } = await import('../../../core/auth/postgres-refresh-token.repository');
    const repo = new PostgresRefreshTokenRepository();

    const result = await repo.findByHash('nonexistent-hash');
    expect(result).toBeNull();
    const [sql, params] = (readPool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('token_hash = $1');
    expect(params).toEqual(['nonexistent-hash']);
  });

  it('revoke() sets revoked_at only for a non-revoked row matching the hash', async () => {
    const { writePool } = await import('../../../core/database/pg-pool');
    (writePool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresRefreshTokenRepository } = await import('../../../core/auth/postgres-refresh-token.repository');
    const repo = new PostgresRefreshTokenRepository();

    await repo.revoke('some-hash');
    const [sql, params] = (writePool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('revoked_at IS NULL');
    expect(sql).toContain('token_hash = $1');
    expect(params).toEqual(['some-hash']);
  });

  it('revokeAllForUser() sets revoked_at for every non-revoked row for that user', async () => {
    const { writePool } = await import('../../../core/database/pg-pool');
    (writePool.query as ReturnType<typeof vi.fn>).mockResolvedValueOnce({ rows: [] });
    const { PostgresRefreshTokenRepository } = await import('../../../core/auth/postgres-refresh-token.repository');
    const repo = new PostgresRefreshTokenRepository();

    await repo.revokeAllForUser('user-xyz');
    const [sql, params] = (writePool.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(sql).toContain('user_id = $1');
    expect(sql).toContain('revoked_at IS NULL');
    expect(params).toEqual(['user-xyz']);
  });
});
