import { describe, it, expect, vi } from 'vitest';
import { AuthController } from '../../../../modules/auth/presentation/auth.controller';
import { ValidationError } from '../../../../core/errors/error-catalog';
import type { VerifyIdentityUseCase } from '../../../../modules/auth/application/verify-identity.usecase';

describe('AuthController', () => {
  it('rejects a request body missing firebaseIdToken with a 422 validation error before reaching the use case', async () => {
    const execute = vi.fn();
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = { body: {} } as never;
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };

    await controller.verify(req, res, next as never);
    expect(caught).toBeInstanceOf(ValidationError);
    expect(execute).not.toHaveBeenCalled();
  });

  it('rejects extra/unexpected body fields (mass-assignment defense, .strict())', async () => {
    const execute = vi.fn();
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    // attempted userId/sellerId/roles injection alongside the real field
    const req = { body: { firebaseIdToken: 'tok', userId: 'attacker-controlled', roles: ['admin'] } } as never;
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };

    await controller.verify(req, res, next as never);
    expect(caught).toBeInstanceOf(ValidationError);
    expect(execute).not.toHaveBeenCalled();
  });

  it('on a valid body, calls the use case with only firebaseIdToken and returns its result', async () => {
    const execute = vi.fn().mockResolvedValue({
      accessToken: 'a',
      refreshToken: 'r',
      user: { id: 'user-1', email: null, phone: null },
    });
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = { body: { firebaseIdToken: 'valid-token' } } as never;
    const jsonSpy = vi.fn();
    const res = { status: vi.fn().mockReturnValue({ json: jsonSpy }) } as never;
    const next = vi.fn();

    await controller.verify(req, res, next as never);
    expect(execute).toHaveBeenCalledWith({ firebaseIdToken: 'valid-token' });
    expect(next).not.toHaveBeenCalled();
    expect(jsonSpy).toHaveBeenCalledWith(
      expect.objectContaining({ success: true, data: expect.objectContaining({ accessToken: 'a' }) }),
    );
  });

  it('uses the shared sendSuccess envelope (meta.requestId), not a hand-rolled response shape — regression test for a real inconsistency found and fixed during the API integration audit', async () => {
    const execute = vi.fn().mockResolvedValue({
      accessToken: 'a',
      refreshToken: 'r',
      user: { id: 'user-1', email: null, phone: null },
    });
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = { body: { firebaseIdToken: 'valid-token' } } as never;
    const jsonSpy = vi.fn();
    const res = { status: vi.fn().mockReturnValue({ json: jsonSpy }) } as never;

    await controller.verify(req, res, vi.fn() as never);

    const [body] = jsonSpy.mock.calls[0] as [{ meta: { requestId: string } }];
    expect(body.meta).toHaveProperty('requestId'); // previously hardcoded meta: {}, no requestId at all
  });

  it('accepts the optional fullName/email/phone provisioning fields and passes them through unchanged', async () => {
    const execute = vi.fn().mockResolvedValue({
      accessToken: 'a',
      refreshToken: 'r',
      user: { id: 'user-1', email: 'e@example.com', phone: '+15551234567' },
    });
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = {
      body: { firebaseIdToken: 'valid-token', fullName: 'Jane Example', email: 'e@example.com', phone: '+15551234567' },
    } as never;
    const jsonSpy = vi.fn();
    const res = { status: vi.fn().mockReturnValue({ json: jsonSpy }) } as never;
    const next = vi.fn();

    await controller.verify(req, res, next as never);
    expect(execute).toHaveBeenCalledWith({
      firebaseIdToken: 'valid-token',
      fullName: 'Jane Example',
      email: 'e@example.com',
      phone: '+15551234567',
    });
  });

  it('rejects an invalid email format in the optional provisioning fields', async () => {
    const execute = vi.fn();
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = { body: { firebaseIdToken: 'tok', email: 'not-an-email' } } as never;
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };

    await controller.verify(req, res, next as never);
    expect(caught).toBeInstanceOf(ValidationError);
    expect(execute).not.toHaveBeenCalled();
  });

  it('passes a use-case error to next() rather than throwing unhandled or leaking details in the response', async () => {
    const execute = vi.fn().mockRejectedValue(new Error('No account exists for this identity'));
    const controller = new AuthController({ execute } as unknown as VerifyIdentityUseCase);
    const req = { body: { firebaseIdToken: 'tok' } } as never;
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() } as never;
    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };

    await controller.verify(req, res, next as never);
    expect(caught).toBeInstanceOf(Error);
    expect((res as { json: ReturnType<typeof vi.fn> }).json).not.toHaveBeenCalled();
  });
});
