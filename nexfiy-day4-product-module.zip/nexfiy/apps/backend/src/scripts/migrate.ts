import { Client } from 'pg';
import { readdirSync, readFileSync } from 'fs';
import path from 'path';
import { env } from '../core/config/env.schema';
import { logger } from '../core/logger/logger';
import { pendingMigrations } from '../core/database/migration-runner';

/**
 * Day 17 — the actual migration runner. Previously absent entirely: migrations/*.sql
 * existed as files with nothing anywhere in the repository that executed them against a
 * real database (confirmed by inspection — no migration tool, no runner script, no
 * package.json script). Standard pattern: a schema_migrations tracking table, each
 * pending file run inside its own transaction (so a failure partway through one
 * migration doesn't leave it half-applied), recorded only after it commits successfully.
 *
 * Ordering logic (which files are pending, and in what order) is in
 * core/database/migration-runner.ts, unit-tested there without needing a live database.
 * This file is the thin, real-I/O wrapper — connecting to Postgres and actually running
 * SQL — which, like every other piece of real database code in this repository, has not
 * been executed against a live database in this sandbox (no network/DB access here).
 */
async function main(): Promise<void> {
  if (!env.DATABASE_URL) {
    logger.error({}, 'migrate.missing-database-url');
    process.exit(1);
  }

  const migrationsDir = path.resolve(__dirname, '../../migrations');
  const allFiles = readdirSync(migrationsDir);

  const client = new Client({ connectionString: env.DATABASE_URL });
  await client.connect();

  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS public.schema_migrations (
        filename    TEXT PRIMARY KEY,
        applied_at  TIMESTAMPTZ NOT NULL DEFAULT now()
      )
    `);

    const { rows } = await client.query<{ filename: string }>('SELECT filename FROM public.schema_migrations');
    const applied: Set<string> = new Set(rows.map((row) => row.filename));
    const pending = pendingMigrations(allFiles, applied);

    if (pending.length === 0) {
      logger.info({}, 'migrate.nothing-to-do');
      return;
    }

    for (const filename of pending) {
      const sql = readFileSync(path.join(migrationsDir, filename), 'utf8');
      logger.info({ filename }, 'migrate.applying');
      try {
        await client.query('BEGIN');
        await client.query(sql);
        await client.query('INSERT INTO public.schema_migrations (filename) VALUES ($1)', [filename]);
        await client.query('COMMIT');
        logger.info({ filename }, 'migrate.applied');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      }
    }

    logger.info({ count: pending.length }, 'migrate.complete');
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  logger.error({ err: err instanceof Error ? err.message : String(err) }, 'migrate.failed');
  process.exit(1);
});
