# NEXFIY — Backend

Multi-vendor marketplace backend. This repository currently contains the Product
module and the authentication/RBAC infrastructure it runs on (JWT sessions, Firebase
login, PostgreSQL-backed permissions, Redis permission cache) — see the architecture
documents for the full planned scope; other modules (Order, Payment, Cart, etc.) are
out of scope here by design.

Package manager: **npm** (not pnpm/yarn — every script below is an `npm` command).

## Local development

1. **Start PostgreSQL and Redis.** The included `docker-compose.yml` provides both for
   local dev only (not part of production deployment — a real deployment uses managed
   Postgres/Redis):
   ```
   docker compose up -d
   ```
2. **Configure environment.** Copy `.env.example` to `.env` and fill in real values.
   For local dev against the `docker-compose.yml` services, `DATABASE_URL` and
   `REDIS_URL` in `.env.example` already point at the right place. `JWT_ACCESS_SECRET`/
   `JWT_REFRESH_SECRET` need real random values even locally (see the generation
   command in `.env.example`) — `FIREBASE_*` need a real Firebase project's service
   account credentials; without them, Firebase-backed login won't work, but the rest of
   the API (Product routes) will, since non-production environments use the stub
   identity/permission services documented in `core/auth/` and `core/rbac/`.
3. **Install dependencies:**
   ```
   npm install
   ```
4. **Run database migrations** (after building, since the runner is compiled JS):
   ```
   npm run build
   npm run migrate
   ```
5. **Start the server:**
   ```
   npm start
   ```
   There is currently no separate hot-reload dev script — `npm run build && npm start`
   is the real local-dev loop. Re-run `build` after each change.

6. **Run tests / lint / type-check:**
   ```
   npm test
   npm run lint
   npx tsc -p tsconfig.json --noEmit
   ```

## Production deployment

1. Set real environment variables (see `.env.example` for the full list — every
   variable there is what `core/config/env.schema.ts` actually validates). Production
   fails fast at startup if `DATABASE_URL`, `REDIS_URL`, `JWT_ACCESS_SECRET`,
   `JWT_REFRESH_SECRET`, or the three `FIREBASE_*` variables are missing, and further
   validates the JWT secrets are at least 32 characters, not a known placeholder value,
   and that access/refresh secrets differ from each other.
2. Build: `npm run build`
3. Run migrations against the production database: `npm run migrate`
4. Start: `npm start` (runs `node dist/server.js`)

Health/readiness endpoints for a load balancer or orchestrator:
- `GET /healthz` — liveness only (process is up).
- `GET /readyz` — readiness: pings PostgreSQL and Redis for real, returns 503 if either
  is unreachable.

The server handles `SIGTERM`/`SIGINT` by stopping new connections, letting in-flight
requests finish, then closing the database pools and Redis connection before exiting
(see `core/lifecycle/graceful-shutdown.ts`).

## Docker

```
docker build -t nexfiy-backend .
docker run --env-file .env -p 3000:3000 nexfiy-backend
```

Multi-stage build (compile stage discarded from the final image), runs as a non-root
user, includes a container-level `HEALTHCHECK` against `/healthz`. **Not verified with
a real `docker build` run** — no Docker daemon or network access in the environment
this was written in. Reviewed carefully against standard practice, but genuinely
unverified; treat accordingly until you've run it yourself.

`docker-compose.yml` is for local development (Postgres + Redis) only, not for running
the application itself in production.

## Known limitations (see `.env.example` and the codebase comments for full detail)

- Firebase login (`POST /auth/verify`) requires a real Firebase project's service
  account credentials — not included, not fabricated.
- First-time user sign-in requires either Firebase-verified or client-supplied
  `fullName`/`email`/`phone` (see `modules/auth/application/verify-identity.usecase.ts`
  for exactly what's required and why placeholder values are never generated).
- Refresh-token revocation, RBAC permission lookups, and the Redis permission cache are
  real, tested code but have not been run against a live PostgreSQL/Redis instance from
  within the environment this was developed in.
