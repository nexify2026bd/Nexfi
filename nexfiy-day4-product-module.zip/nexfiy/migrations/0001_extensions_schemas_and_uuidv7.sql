-- Day 19 — CRITICAL FIX: no migration anywhere created the `audit` schema or defined
-- uuid_generate_v7(), yet 0021_add_event_outbox.sql (and every later migration/repository
-- query) assumes both exist. Against a genuinely fresh PostgreSQL database, `npm run
-- migrate` would fail on its first statement: "function uuid_generate_v7() does not
-- exist". Every prior migration review checked syntax/idempotency/parameterization, not
-- whether the dependency chain actually resolves from empty — this is that missing base.
--
-- uuid_generate_v7() is implemented here directly in PL/pgSQL rather than assumed to
-- come from a third-party extension (Day 2 §0 said "assumed available via pg_uuidv7
-- extension" — that extension is not part of standard PostgreSQL and isn't guaranteed to
-- exist on an arbitrary real deployment target). This implementation only needs the
-- built-in `pgcrypto` extension (for gen_random_bytes) and produces a spec-correct
-- UUIDv7: 48-bit millisecond Unix timestamp + version nibble 0111 + variant bits 10 +
-- 74 bits of randomness.
--
-- Only the schemas this repository's actual code uses are created here (identity,
-- catalog, audit) — not the full multi-domain marketplace schema (commerce, finance,
-- logistics, engagement, search) from the Day 2 architecture document, since no module
-- for any of those was ever built in this repository. Creating empty schema namespaces
-- for modules that don't exist would be unrequested scope expansion.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext; -- required for identity.users.email (case-insensitive), Day 2 §1

CREATE SCHEMA IF NOT EXISTS identity;
CREATE SCHEMA IF NOT EXISTS catalog;
CREATE SCHEMA IF NOT EXISTS audit;

CREATE OR REPLACE FUNCTION uuid_generate_v7()
RETURNS uuid
LANGUAGE plpgsql
VOLATILE
AS $$
DECLARE
  ts_ms    bigint := floor(extract(epoch FROM clock_timestamp()) * 1000)::bigint;
  ts_bytes bytea  := substring(int8send(ts_ms) FROM 3 FOR 6); -- lower 48 bits of the ms timestamp
  b        bytea;
BEGIN
  b := ts_bytes || gen_random_bytes(10); -- 16 bytes total: 6 timestamp + 10 random
  b := set_byte(b, 6, (get_byte(b, 6) & 15)  | 112); -- version nibble = 0111 (7)
  b := set_byte(b, 8, (get_byte(b, 8) & 63)  | 128); -- variant bits   = 10
  RETURN encode(b, 'hex')::uuid;
END;
$$;
