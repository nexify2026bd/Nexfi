-- Day 13: identity.refresh_tokens, per the Day 2 database architecture document (§1).
-- Documented there but never migrated until now — this repository previously had no
-- table for RealAuthTokenService.rotateRefreshToken/revokeRefreshToken to persist
-- against. IF NOT EXISTS throughout, matching the idempotent pattern established by
-- migrations/0021_add_event_outbox.sql.

CREATE TABLE IF NOT EXISTS identity.refresh_tokens (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    user_id        UUID NOT NULL REFERENCES identity.users(id) ON DELETE CASCADE,
    token_hash     TEXT NOT NULL,                 -- never store raw token (Day 2 §1 comment)
    device_info    TEXT,
    expires_at     TIMESTAMPTZ NOT NULL,
    revoked_at     TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user_id
    ON identity.refresh_tokens (user_id) WHERE revoked_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_refresh_tokens_hash
    ON identity.refresh_tokens (token_hash);
