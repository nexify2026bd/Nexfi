-- Day 19 — catalog.categories/brands/products, per the Day 2 database architecture
-- document §3. Column-for-column identical to PostgresProductRepository's SELECT_COLUMNS
-- list and INSERT statement (verified directly against that file, not just the design
-- doc, before writing this). Deliberately does NOT include catalog.product_images,
-- catalog.product_variants, or catalog.inventory — the Product module has never touched
-- sku/compare_at_price/currency/stock, by explicit design decision maintained since the
-- module was first built (see README's known-gap notes) — inventing those tables now
-- would be unrequested scope expansion, not a fix.

CREATE TABLE IF NOT EXISTS catalog.categories (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    parent_id    UUID REFERENCES catalog.categories(id) ON DELETE RESTRICT,
    name         TEXT NOT NULL,
    slug         TEXT NOT NULL,
    is_active    BOOLEAN NOT NULL DEFAULT true,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at   TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_categories_slug ON catalog.categories (slug);
CREATE INDEX IF NOT EXISTS idx_categories_parent_id ON catalog.categories (parent_id);

CREATE TABLE IF NOT EXISTS catalog.brands (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    name        TEXT NOT NULL,
    slug        TEXT NOT NULL,
    logo_url    TEXT,
    is_active   BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at  TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_brands_slug ON catalog.brands (slug);

CREATE TYPE catalog.product_status AS ENUM ('draft','pending_approval','approved','rejected','archived');

CREATE TABLE IF NOT EXISTS catalog.products (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    seller_id       UUID NOT NULL REFERENCES identity.sellers(id) ON DELETE RESTRICT,
    category_id     UUID NOT NULL REFERENCES catalog.categories(id) ON DELETE RESTRICT,
    brand_id        UUID REFERENCES catalog.brands(id) ON DELETE SET NULL,
    title           TEXT NOT NULL,
    slug            TEXT NOT NULL,
    description     TEXT,
    base_price      NUMERIC(14,2) NOT NULL CHECK (base_price >= 0),
    status          catalog.product_status NOT NULL DEFAULT 'draft',
    approved_by     UUID REFERENCES identity.users(id),
    approved_at     TIMESTAMPTZ,
    rating_avg      NUMERIC(3,2) NOT NULL DEFAULT 0.00,
    rating_count    INTEGER NOT NULL DEFAULT 0,
    version         INTEGER NOT NULL DEFAULT 1,
    created_by      UUID,
    updated_by      UUID,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_products_seller_slug ON catalog.products (seller_id, slug);
CREATE INDEX IF NOT EXISTS idx_products_seller_id ON catalog.products (seller_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_category_id ON catalog.products (category_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_products_status ON catalog.products (status) WHERE deleted_at IS NULL;
-- Composite index matching the exact keyset-pagination predicate in
-- PostgresProductRepository.findMany(): (created_at, id) > (cursor.createdAt, cursor.id).
CREATE INDEX IF NOT EXISTS idx_products_created_at_id ON catalog.products (created_at, id) WHERE deleted_at IS NULL;
