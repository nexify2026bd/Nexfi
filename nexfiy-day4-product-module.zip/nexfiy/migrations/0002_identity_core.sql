-- Day 19 — identity.users/roles/permissions/role_permissions/user_roles/sellers, per the
-- Day 2 database architecture document §1. Never previously migrated as real files (only
-- existed as the original markdown design) — see 0001's comment for why this was a real
-- gap. Column-for-column identical to what PostgresUserRepository and
-- PostgresPermissionService already query against; `identity.sellers` is included only
-- because catalog.products has a hard FK to it (no seller module/repository exists in
-- this codebase — the table exists purely to satisfy that foreign key, nothing more).

CREATE TYPE identity.user_status AS ENUM ('active','suspended','banned','pending_verification');

CREATE TABLE IF NOT EXISTS identity.users (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    full_name            TEXT NOT NULL,
    email                CITEXT NOT NULL,
    email_verified_at    TIMESTAMPTZ,
    phone                TEXT NOT NULL,
    phone_verified_at    TIMESTAMPTZ,
    firebase_uid         TEXT NOT NULL,
    password_hash        TEXT,
    status               identity.user_status NOT NULL DEFAULT 'pending_verification',
    default_address_id   UUID,
    device_fingerprint   TEXT,
    version              INTEGER NOT NULL DEFAULT 1,
    created_by           UUID,
    updated_by           UUID,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at           TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email ON identity.users (email) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_phone ON identity.users (phone) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_firebase_uid ON identity.users (firebase_uid) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_users_status ON identity.users (status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_users_created_at ON identity.users (created_at);

CREATE TABLE IF NOT EXISTS identity.roles (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    name          TEXT NOT NULL,
    description   TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_roles_name ON identity.roles (name);

CREATE TABLE IF NOT EXISTS identity.permissions (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    code          TEXT NOT NULL,
    description   TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_permissions_code ON identity.permissions (code);

CREATE TABLE IF NOT EXISTS identity.role_permissions (
    role_id        UUID NOT NULL REFERENCES identity.roles(id) ON DELETE CASCADE,
    permission_id  UUID NOT NULL REFERENCES identity.permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS identity.user_roles (
    user_id    UUID NOT NULL REFERENCES identity.users(id) ON DELETE CASCADE,
    role_id    UUID NOT NULL REFERENCES identity.roles(id) ON DELETE RESTRICT,
    granted_by UUID REFERENCES identity.users(id),
    granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, role_id)
);
CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON identity.user_roles (role_id);

-- Referenced by catalog.products.seller_id (0003) — no seller module exists in this
-- codebase; this table exists solely to satisfy that foreign key.
CREATE TABLE IF NOT EXISTS identity.sellers (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
    user_id             UUID NOT NULL REFERENCES identity.users(id) ON DELETE RESTRICT,
    business_name       TEXT NOT NULL,
    business_reg_no     TEXT,
    status              TEXT NOT NULL DEFAULT 'pending'
                           CHECK (status IN ('pending','approved','rejected','suspended')),
    approved_by         UUID REFERENCES identity.users(id),
    approved_at         TIMESTAMPTZ,
    commission_rate     NUMERIC(5,2) NOT NULL DEFAULT 10.00,
    pickup_address_id   UUID,
    version             INTEGER NOT NULL DEFAULT 1,
    created_by          UUID,
    updated_by          UUID,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sellers_user_id ON identity.sellers (user_id);
CREATE INDEX IF NOT EXISTS idx_sellers_status ON identity.sellers (status) WHERE deleted_at IS NULL;
