import { describe, it, expect, vi } from 'vitest';
import { PostgresProductRepository } from '../../../modules/product/infrastructure/repositories/postgres-product.repository';
import { Product } from '../../../modules/product/domain/entities/product.entity';
import { ProductId } from '../../../modules/product/domain/value-objects/product-id.vo';
import { Money } from '../../../modules/product/domain/value-objects/money.vo';
import { ConflictError } from '../../../core/errors/error-catalog';

const validId = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';

function makeUpdatedProduct() {
  // version 2 (touch() already applied once) simulates an update-path save, not a create.
  const p = Product.create({
    id: ProductId.from(validId),
    sellerId: 'seller-1',
    categoryId: 'cat-1',
    brandId: null,
    title: 'T',
    slug: 'slug',
    description: null,
    basePrice: Money.from(10),
  });
  p.updateDetails({ title: 'Updated title' }); // version -> 2
  return p;
}

/**
 * Audit fix regression test: `save()` previously ignored Postgres's silent zero-row
 * result when the `ON CONFLICT ... WHERE version = $18` predicate didn't match a
 * concurrently-modified row. This test locks in the fix — repository.save() must now
 * surface that as PRODUCT_VERSION_CONFLICT instead of returning successfully.
 */
describe('PostgresProductRepository — optimistic lock (audit regression test)', () => {
  it('throws PRODUCT_VERSION_CONFLICT when the update-path query affects zero rows', async () => {
    const repo = new PostgresProductRepository();
    const fakeTrx = { query: vi.fn().mockResolvedValue({ rowCount: 0, rows: [] }) } as never;

    const product = makeUpdatedProduct();
    await expect(repo.save(product, fakeTrx)).rejects.toMatchObject({ code: 'PRODUCT_VERSION_CONFLICT' });
  });

  it('succeeds silently when the update-path query affects exactly one row', async () => {
    const repo = new PostgresProductRepository();
    const fakeTrx = { query: vi.fn().mockResolvedValue({ rowCount: 1, rows: [{ id: validId }] }) } as never;

    const product = makeUpdatedProduct();
    await expect(repo.save(product, fakeTrx)).resolves.toBeUndefined();
  });

  it('does not treat a fresh create (version 1) zero-row edge case as a version conflict', async () => {
    const repo = new PostgresProductRepository();
    // A first-time INSERT always affects exactly one row in practice; this test documents
    // that the version-conflict check is gated on isUpdate (version > 1) so it can never
    // misfire against the create path.
    const fakeTrx = { query: vi.fn().mockResolvedValue({ rowCount: 1, rows: [{ id: validId }] }) } as never;
    const freshProduct = Product.create({
      id: ProductId.from(validId), sellerId: 's', categoryId: 'c', brandId: null,
      title: 'New', slug: 'new', description: null, basePrice: Money.from(1),
    });
    await expect(repo.save(freshProduct, fakeTrx)).resolves.toBeUndefined();
  });

  it('maps a Postgres unique_violation (23505) to PRODUCT_SLUG_ALREADY_EXISTS, never leaking the raw DB error', async () => {
    const repo = new PostgresProductRepository();
    const pgError = Object.assign(new Error('duplicate key value violates unique constraint'), { code: '23505' });
    const fakeTrx = { query: vi.fn().mockRejectedValue(pgError) } as never;

    const product = makeUpdatedProduct();
    await expect(repo.save(product, fakeTrx)).rejects.toMatchObject({ code: 'PRODUCT_SLUG_ALREADY_EXISTS' });
  });

  // Day 8 STEP 8 item 12 — "SQL-injection-shaped input safely rejected/handled": title/
  // description are never string-concatenated into SQL anywhere in this repository (every
  // query uses $1/$2/... placeholders) — a title containing SQL-injection-shaped content
  // must be passed through as inert parameter data, never influence the query structure.
  // This test locks in that guarantee by inspecting the actual parameter array `save()`
  // sends to `query()`, rather than asserting on behavior alone.
  it('passes a title containing SQL-injection-shaped content as inert parameter data, never concatenated into the query text', async () => {
    const repo = new PostgresProductRepository();
    const maliciousTitle = "Evil Product'; DROP TABLE catalog.products; --";
    const capturedCalls: unknown[][] = [];
    const fakeTrx = {
      query: vi.fn((...args: unknown[]) => {
        capturedCalls.push(args);
        return Promise.resolve({ rowCount: 1, rows: [] });
      }),
    } as never;

    const product = Product.create({
      id: ProductId.from(validId), sellerId: 's', categoryId: 'c', brandId: null,
      title: maliciousTitle, slug: 'evil-product', description: null, basePrice: Money.from(1),
    });
    await repo.save(product, fakeTrx);

    const [sqlText, params] = capturedCalls[0] as [string, unknown[]];
    // the query text itself must contain only placeholders, never the raw title
    expect(sqlText).not.toContain('DROP TABLE');
    expect(sqlText).toContain('$1');
    // the malicious string must appear ONLY as a parameter value, exactly as given
    expect(params).toContain(maliciousTitle);
  });
});
