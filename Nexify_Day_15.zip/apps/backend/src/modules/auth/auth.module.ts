import { Router } from 'express';
import { Container } from '../../core/di/container';
import { env } from '../../core/config/env.schema';
import { AuthController } from './presentation/auth.controller';
import { VerifyIdentityUseCase } from './application/verify-identity.usecase';
import { IIdentityProvider, IAuthTokenService } from '../../core/auth/auth.ports';
import { FirebaseIdentityProvider } from '../../core/auth/firebase-identity.provider';
import { StubIdentityProvider } from '../../core/auth/stub-identity-provider';
import { IUserRepository } from '../../core/auth/user.repository.port';
import { PostgresUserRepository } from '../../core/auth/postgres-user.repository';
import { rateLimit } from '../../core/security/rate-limiter';

/**
 * Day 13 — auth module registration, mirroring product.module.ts's pattern. Reuses the
 * IAuthTokenService binding already registered by authenticate.middleware.ts (module
 * import order in app.ts guarantees that binding exists by the time this resolves it) —
 * never constructs a second, inconsistent instance.
 *
 * IIdentityProvider follows the same production/non-production split as
 * IAuthTokenService and IPermissionService (FirebaseIdentityProvider vs
 * StubIdentityProvider) — an earlier draft of this file registered
 * FirebaseIdentityProvider unconditionally, which would have thrown immediately in any
 * environment without real Firebase config (including tests/local dev); caught and
 * fixed before this ever ran, via the same NODE_ENV branch already used elsewhere.
 *
 * Day 15: rate-limited (10 requests / 60s per IP) — the only unauthenticated,
 * write-capable route in this repository.
 */
export function registerAuthModule(container: Container): Router {
  container.registerSingleton<IIdentityProvider>('IIdentityProvider', () =>
    env.NODE_ENV === 'production' ? new FirebaseIdentityProvider() : new StubIdentityProvider(),
  );
  container.registerSingleton<IUserRepository>('IUserRepository', () => new PostgresUserRepository());

  const identityProvider = container.resolve<IIdentityProvider>('IIdentityProvider');
  const authTokens = container.resolve<IAuthTokenService>('IAuthTokenService');
  const userRepository = container.resolve<IUserRepository>('IUserRepository');
  const verifyIdentity = new VerifyIdentityUseCase(identityProvider, userRepository, authTokens);
  const controller = new AuthController(verifyIdentity);

  const router = Router();
  router.post(
    '/auth/verify',
    rateLimit({ keyPrefix: 'auth-verify', windowSeconds: 60, maxRequests: 10 }),
    controller.verify,
  );
  return router;
}
