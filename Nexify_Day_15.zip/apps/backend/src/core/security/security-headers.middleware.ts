import { NextFunction, Request, Response } from 'express';

/**
 * Day 15 — minimal, dependency-free security headers (previously absent entirely —
 * confirmed by inspection: no helmet, no manual header-setting anywhere in the repo).
 * Same "hand-roll rather than add an unverifiable package" reasoning as cors.config.ts —
 * this environment can't install/verify a new dependency, and the actual header set
 * needed here is small and stable enough not to need one.
 *
 * Deliberately does NOT set Strict-Transport-Security: HSTS is only safe to send over
 * an actual HTTPS connection (sending it over plain HTTP is a no-op at best and can
 * cause browser-side issues if a deployment is ever misconfigured to think it's HTTPS
 * when it isn't) — this app has no TLS-termination awareness of its own (that's normally
 * the reverse proxy/load balancer's job), so setting it here would be guessing.
 */
export function securityHeaders(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  next();
}
