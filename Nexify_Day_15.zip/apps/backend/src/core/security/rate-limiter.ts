import { Request, Response, NextFunction } from 'express';
import { redisCacheClient } from '../cache/redis-client';
import { logger } from '../logger/logger';
import { TooManyRequestsError } from '../errors/error-catalog';

/**
 * Day 15 — minimal fixed-window rate limiter, Redis-backed (INCR + EXPIRE on the first
 * hit in a window). Applied to POST /auth/verify — the ONE unauthenticated,
 * write-capable endpoint in this repository (every Product mutation route already
 * requires authentication + RBAC, which is a much stronger abuse barrier than rate
 * limiting alone; login/verification endpoints are the standard place this control
 * actually matters).
 *
 * Fails OPEN on a Redis error — unlike RBAC (where a failure must never grant
 * authorization), a rate limiter's job is abuse mitigation, not an access-control
 * decision: if Redis is down, temporarily allowing all traffic through is correct
 * behavior (Firebase token verification and RBAC/ownership checks downstream remain
 * the actual security boundary either way), not a security bypass. This mirrors the
 * SAME fail-open-to-real-source, never-fail-open-to-unrestricted-access reasoning
 * already used in RedisCachedPermissionService.
 */
export function rateLimit(options: { keyPrefix: string; windowSeconds: number; maxRequests: number }) {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    const identifier = req.ip ?? 'unknown';
    const key = `ratelimit:${options.keyPrefix}:${identifier}`;

    try {
      const count = await redisCacheClient.incr(key);
      if (count === 1) {
        await redisCacheClient.expire(key, options.windowSeconds);
      }
      if (count > options.maxRequests) {
        throw new TooManyRequestsError('Too many requests — please try again later');
      }
      next();
    } catch (err) {
      if (err instanceof TooManyRequestsError) {
        next(err);
        return;
      }
      logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'rate-limiter.failed-open');
      next(); // Redis unavailable — fail open, see doc comment above
    }
  };
}
