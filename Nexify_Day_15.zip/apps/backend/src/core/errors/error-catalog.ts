import { AppError } from './app-error.base';

export class ValidationError extends AppError {
  readonly code = 'VALIDATION_ERROR';
  readonly httpStatus = 422;
  constructor(message: string, details?: unknown[]) {
    super(message, details);
  }
}

export class TooManyRequestsError extends AppError {
  readonly code = 'TOO_MANY_REQUESTS';
  readonly httpStatus = 429;
  constructor(message: string) {
    super(message);
  }
}

export class AuthError extends AppError {
  readonly code = 'UNAUTHORIZED';
  readonly httpStatus = 401;
  constructor(message: string) {
    super(message);
  }
}

export class ForbiddenError extends AppError {
  readonly code = 'FORBIDDEN';
  readonly httpStatus = 403;
  constructor(message: string) {
    super(message);
  }
}

export class NotFoundError extends AppError {
  readonly code: string;
  readonly httpStatus = 404;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export class ConflictError extends AppError {
  readonly code: string;
  readonly httpStatus = 409;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export class InvalidStateTransitionError extends AppError {
  readonly code = 'PRODUCT_INVALID_STATUS_TRANSITION';
  readonly httpStatus = 409;
  constructor(message: string) {
    super(message);
  }
}

export class InternalError extends AppError {
  readonly code = 'INTERNAL_ERROR';
  readonly httpStatus = 500;
  constructor() {
    super('An unexpected error occurred.');
  }
}
