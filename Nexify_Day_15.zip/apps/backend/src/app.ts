import express, { Express } from 'express';
import { requestContext } from './core/logger/request-context';
import { httpLogger } from './core/logger/http-logger.middleware';
import { corsMiddleware } from './core/security/cors.config';
import { securityHeaders } from './core/security/security-headers.middleware';
import { globalErrorHandler } from './core/errors/global-error-handler';
import { registerProductModule } from './modules/product/product.module';
import { registerAuthModule } from './modules/auth/auth.module';
import { container } from './core/di/container';
import { readPool } from './core/database/pg-pool';
import { redisCacheClient } from './core/cache/redis-client';
import './core/auth/authenticate.middleware'; // side-effect import: registers IAuthTokenService
                                                // before registerAuthModule resolves it below

/**
 * Day 10/11 STEP 6 — the actual composition root. No file like this existed anywhere in
 * the repository before now; Day 3's design document described one (`bootstrap.ts`,
 * §1.2/§5.6) but it was never filed as real code, so "the complete flow" previously
 * existed only as separately-testable pieces (routes, middleware) with no single place
 * that assembled them in the documented order.
 *
 * Middleware order matches Day 3 §5.4 exactly: correlation-ID context first, then
 * request logging, then health/readiness endpoints (deliberately BEFORE security
 * headers/CORS/body-parsing — an orchestrator's liveness probe shouldn't depend on any
 * of that machinery, and shouldn't count against the auth module's rate limit or need a
 * CORS-allowed Origin), then security headers, then CORS, then bounded body parsing,
 * then routes (each module applies its own authenticate/requirePermission/validate
 * chain per Day 4 §11), then the global error handler last.
 *
 * Day 13: mounts the auth module's /auth/verify route alongside the product module.
 * Day 15: security-headers middleware + 1MB body-size limit (memory-exhaustion guard on
 * the one unauthenticated POST route) + Redis-backed rate limiting on /auth/verify.
 *
 * Day 16: adds /healthz (liveness — the process is up, nothing more) and /readyz
 * (readiness — can this instance actually serve traffic: real PostgreSQL and Redis
 * pings, not a hardcoded 200). Neither existed before; their absence would have been a
 * real problem for any orchestrator (k8s, ECS, a load balancer) deciding whether to
 * route traffic to or restart this instance.
 */
export function createApp(): Express {
  const app = express();

  app.use(requestContext);
  app.use(httpLogger);

  app.get('/healthz', (_req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  app.get('/readyz', async (_req, res) => {
    const checks: Record<string, 'ok' | 'error'> = {};

    try {
      await readPool.query('SELECT 1');
      checks.database = 'ok';
    } catch {
      checks.database = 'error'; // never leak the underlying error's details in the response
    }

    try {
      await redisCacheClient.ping();
      checks.redis = 'ok';
    } catch {
      checks.redis = 'error';
    }

    const ready = Object.values(checks).every((status) => status === 'ok');
    res.status(ready ? 200 : 503).json({ status: ready ? 'ok' : 'degraded', checks });
  });

  app.use(securityHeaders);
  app.use(corsMiddleware);
  app.use(express.json({ limit: '1mb' }));

  app.use('/api/v1', registerAuthModule(container));
  app.use('/api/v1', registerProductModule(container));

  app.use(globalErrorHandler);

  return app;
}
