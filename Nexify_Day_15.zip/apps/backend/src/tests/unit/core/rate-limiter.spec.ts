import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../../../core/cache/redis-client', () => ({
  redisCacheClient: { incr: vi.fn(), expire: vi.fn() },
}));
vi.mock('../../../core/logger/logger', () => ({
  logger: { warn: vi.fn(), info: vi.fn(), error: vi.fn() },
}));

describe('rateLimit', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('allows the request through and sets an expiry on the first hit in a window', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.incr as ReturnType<typeof vi.fn>).mockResolvedValueOnce(1);
    const { rateLimit } = await import('../../../core/security/rate-limiter');
    const middleware = rateLimit({ keyPrefix: 'test', windowSeconds: 60, maxRequests: 10 });

    const req = { ip: '1.2.3.4' } as never;
    const next = vi.fn();
    await middleware(req, {} as never, next);

    expect(redisCacheClient.expire).toHaveBeenCalledWith('ratelimit:test:1.2.3.4', 60);
    expect(next).toHaveBeenCalledWith(); // called with no error
  });

  it('does not re-set the expiry on subsequent hits within the same window', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.incr as ReturnType<typeof vi.fn>).mockResolvedValueOnce(5);
    const { rateLimit } = await import('../../../core/security/rate-limiter');
    const middleware = rateLimit({ keyPrefix: 'test', windowSeconds: 60, maxRequests: 10 });

    await middleware({ ip: '1.2.3.4' } as never, {} as never, vi.fn());
    expect(redisCacheClient.expire).not.toHaveBeenCalled();
  });

  it('rejects with TooManyRequestsError once the count exceeds maxRequests', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.incr as ReturnType<typeof vi.fn>).mockResolvedValueOnce(11);
    const { rateLimit } = await import('../../../core/security/rate-limiter');
    const { TooManyRequestsError } = await import('../../../core/errors/error-catalog');
    const middleware = rateLimit({ keyPrefix: 'test', windowSeconds: 60, maxRequests: 10 });

    let caught: unknown;
    const next = (err?: unknown) => {
      caught = err;
    };
    await middleware({ ip: '1.2.3.4' } as never, {} as never, next as never);
    expect(caught).toBeInstanceOf(TooManyRequestsError);
  });

  it('different IPs are tracked independently (separate keys)', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.incr as ReturnType<typeof vi.fn>).mockResolvedValueOnce(1);
    const { rateLimit } = await import('../../../core/security/rate-limiter');
    const middleware = rateLimit({ keyPrefix: 'test', windowSeconds: 60, maxRequests: 10 });

    await middleware({ ip: '5.6.7.8' } as never, {} as never, vi.fn());
    expect(redisCacheClient.incr).toHaveBeenCalledWith('ratelimit:test:5.6.7.8');
  });

  it('fails OPEN (allows the request) rather than blocking all traffic when Redis is unavailable', async () => {
    const { redisCacheClient } = await import('../../../core/cache/redis-client');
    (redisCacheClient.incr as ReturnType<typeof vi.fn>).mockRejectedValueOnce(new Error('ECONNREFUSED'));
    const { rateLimit } = await import('../../../core/security/rate-limiter');
    const middleware = rateLimit({ keyPrefix: 'test', windowSeconds: 60, maxRequests: 10 });

    let caught: unknown;
    let called = false;
    const next = (err?: unknown) => {
      called = true;
      caught = err;
    };
    await middleware({ ip: '1.2.3.4' } as never, {} as never, next as never);
    expect(called).toBe(true);
    expect(caught).toBeUndefined(); // no error passed — request proceeds
  });
});
