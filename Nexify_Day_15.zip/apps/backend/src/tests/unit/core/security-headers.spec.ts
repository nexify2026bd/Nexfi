import { describe, it, expect, vi } from 'vitest';
import { securityHeaders } from '../../../core/security/security-headers.middleware';

describe('securityHeaders', () => {
  it('sets the expected defensive headers and calls next()', () => {
    const headers: Record<string, string> = {};
    const req = {} as never;
    const res = { setHeader: (k: string, v: string) => (headers[k] = v) } as never;
    const next = vi.fn();

    securityHeaders(req, res, next);

    expect(headers['X-Content-Type-Options']).toBe('nosniff');
    expect(headers['X-Frame-Options']).toBe('DENY');
    expect(headers['Referrer-Policy']).toBe('no-referrer');
    expect(next).toHaveBeenCalledTimes(1);
  });

  it('does not set Strict-Transport-Security (this app has no TLS-termination awareness)', () => {
    const headers: Record<string, string> = {};
    const req = {} as never;
    const res = { setHeader: (k: string, v: string) => (headers[k] = v) } as never;
    securityHeaders(req, res, vi.fn());
    expect(headers['Strict-Transport-Security']).toBeUndefined();
  });
});
