import { describe, it, expect, vi } from 'vitest';

vi.mock('../../../core/logger/logger', () => ({
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
}));

describe('createStartupErrorHandler', () => {
  it('logs the error code/message/port and exits 1 on a startup failure (e.g. EADDRINUSE)', async () => {
    const { createStartupErrorHandler } = await import('../../../core/lifecycle/startup-error-handler');
    const { logger } = await import('../../../core/logger/logger');
    const exit = vi.fn();
    const handler = createStartupErrorHandler(3000, exit);

    const err = Object.assign(new Error('listen EADDRINUSE: address already in use :::3000'), {
      code: 'EADDRINUSE',
    });
    handler(err as never);

    expect(logger.error).toHaveBeenCalledWith(
      expect.objectContaining({ code: 'EADDRINUSE', port: 3000 }),
      'server.startup-failed',
    );
    expect(exit).toHaveBeenCalledWith(1);
  });
});
