import { logger } from '../logger/logger';

/**
 * Day 18 — extracted for the same reason as graceful-shutdown.ts: server.ts calls
 * `app.listen()` as a module-level side effect on import, so testing anything wired
 * into it directly would mean actually binding a real port. This handler covers a
 * startup failure (most commonly EADDRINUSE — the port already in use) that would
 * otherwise surface only as a generic, unhelpful message via the uncaughtException
 * handler (Node's HTTP server emits an 'error' event, which becomes an uncaught
 * exception if nothing listens for it).
 */
export function createStartupErrorHandler(
  port: number,
  exit: (code: number) => void,
): (err: NodeJS.ErrnoException) => void {
  return (err) => {
    logger.error({ err: err.message, code: err.code, port }, 'server.startup-failed');
    exit(1);
  };
}
