import { AppError } from '../../../../core/errors/app-error.base';

/**
 * Day 5 STEP 2 audit fix: the original Day 4 commands threw a bare
 * `new ForbiddenError('PRODUCT_PERMISSION_DENIED')` — but ForbiddenError's constructor
 * takes only a *message*, and its `code` is hardcoded to the generic 'FORBIDDEN' (Day 3
 * error-catalog). That meant the string 'PRODUCT_PERMISSION_DENIED' was silently being
 * used as the human-readable message, not the machine-readable code Day 4 §16 documented
 * ("PRODUCT_PERMISSION_DENIED" was listed as an expected *code*) — the actual JSON
 * response carried `code: "FORBIDDEN"`, not the specific code.
 *
 * This class fixes that AND gives ownership violations (checked via ProductOwnershipPolicy)
 * a distinct, more precise code than a generic RBAC-permission failure would — the two are
 * different failure modes: RBAC (`requirePermission`, Day 3 §3.4) already gates route access
 * before a command ever runs; a PolicyEngine rejection inside a command specifically means
 * "you have the general permission, but you don't own THIS resource."
 *
 * Extends AppError directly rather than the core catalog's ForbiddenError: ForbiddenError's
 * `code` field is a TypeScript literal-narrowed `'FORBIDDEN'` (no explicit `: string`
 * annotation), so a subclass cannot legally override it with a different literal value
 * (TS2416, caught during Day 5 STEP 12 compilation verification). Extending AppError's
 * `abstract readonly code: string` avoids that without touching the Day 3 core file —
 * this class still carries the same 403 semantics ForbiddenError would have.
 */
export class ProductOwnershipViolationError extends AppError {
  readonly code = 'PRODUCT_OWNERSHIP_VIOLATION';
  readonly httpStatus = 403;

  constructor(productId: string) {
    super(`You do not have permission to modify product '${productId}' — it belongs to a different seller`);
  }
}
