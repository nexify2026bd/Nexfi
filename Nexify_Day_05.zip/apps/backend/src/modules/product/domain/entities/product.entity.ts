import { ProductId } from '../value-objects/product-id.vo';
import { Money } from '../value-objects/money.vo';
import { ProductStatus, ProductStatusValue } from '../value-objects/product-status.vo';
import { InvalidProductStateTransitionError, InvalidProductDataError } from '../errors/product.errors';

const TITLE_MIN_LENGTH = 3;
const TITLE_MAX_LENGTH = 200;
const DESCRIPTION_MAX_LENGTH = 5000;

/**
 * Fields map 1:1 to catalog.products (Day 2 §3) — no invented columns.
 * NOTE: sku, compareAtPrice, currency, and stock quantity are deliberately ABSENT.
 * Per Day 2 §3, those live on catalog.product_variants (sku, price, compare_at_price)
 * and catalog.inventory (quantity_on_hand), not on catalog.products. Day 4 scope is the
 * Product module only (§22 "Do not implement" — no Variant/Inventory module) — see the
 * Day 4 final report for the explicit schema-dependency note this implies.
 */
export interface ProductProps {
  id: ProductId;
  sellerId: string;
  categoryId: string;
  brandId: string | null;
  title: string;
  slug: string;
  description: string | null;
  basePrice: Money;
  status: ProductStatus;
  approvedBy: string | null;
  approvedAt: Date | null;
  ratingAvg: number;
  ratingCount: number;
  version: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date | null;
}

export class Product {
  private constructor(private props: ProductProps) {}

  static create(input: {
    id: ProductId;
    sellerId: string;
    categoryId: string;
    brandId: string | null;
    title: string;
    slug: string;
    description: string | null;
    basePrice: Money;
  }): Product {
    Product.validateTitle(input.title);
    Product.validateDescription(input.description);
    if (!input.sellerId) throw new InvalidProductDataError('Product must have a sellerId');
    if (!input.categoryId) throw new InvalidProductDataError('Product must have a categoryId');

    const now = new Date();
    return new Product({
      id: input.id,
      sellerId: input.sellerId,
      categoryId: input.categoryId,
      brandId: input.brandId,
      title: input.title,
      slug: input.slug,
      description: input.description,
      basePrice: input.basePrice,
      status: ProductStatus.draft(),
      approvedBy: null,
      approvedAt: null,
      ratingAvg: 0,
      ratingCount: 0,
      version: 1,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    });
  }

  /** Rehydrates a Product from persisted row data (repository use only). */
  static rehydrate(props: ProductProps): Product {
    return new Product(props);
  }

  get id(): ProductId {
    return this.props.id;
  }
  get sellerId(): string {
    return this.props.sellerId;
  }
  get slug(): string {
    return this.props.slug;
  }
  get status(): ProductStatus {
    return this.props.status;
  }
  get version(): number {
    return this.props.version;
  }

  isOwnedBy(sellerId: string): boolean {
    return this.props.sellerId === sellerId;
  }

  updateDetails(input: {
    categoryId?: string;
    brandId?: string | null;
    title?: string;
    description?: string | null;
    basePrice?: Money;
  }): void {
    if (this.props.status.equals('archived')) {
      throw new InvalidProductStateTransitionError('Cannot update an archived product');
    }
    if (input.title !== undefined) Product.validateTitle(input.title);
    if (input.description !== undefined) Product.validateDescription(input.description);
    if (input.categoryId !== undefined) this.props.categoryId = input.categoryId;
    if (input.brandId !== undefined) this.props.brandId = input.brandId;
    if (input.title !== undefined) this.props.title = input.title;
    if (input.description !== undefined) this.props.description = input.description;
    if (input.basePrice !== undefined) this.props.basePrice = input.basePrice;
    this.touch();
  }

  /** Submits the product into the admin approval queue — see ProductStatus VO doc comment. */
  submitForApproval(): void {
    this.transitionTo('pending_approval');
  }

  archive(): void {
    this.transitionTo('archived');
  }

  private transitionTo(target: ProductStatusValue): void {
    if (!this.props.status.canTransitionTo(target)) {
      throw new InvalidProductStateTransitionError(
        `Cannot transition product from '${this.props.status.value}' to '${target}'`,
      );
    }
    this.props.status = ProductStatus.from(target);
    this.touch();
  }

  private touch(): void {
    this.props.updatedAt = new Date();
    this.props.version += 1;
  }

  /**
   * Day 5 STEP 3 hardening: title/description invariants now live on the entity itself,
   * not only in the Zod schema at the HTTP boundary (Day 4 presentation/validators). This
   * is standard DDD defense-in-depth — Product must be impossible to construct in an
   * invalid state regardless of caller (a future non-HTTP entry point, a test, an import
   * script), not only when reached through the API. Bounds intentionally mirror the
   * existing Zod schema (min 3 / max 200 / max 5000) — not a new business rule, just the
   * same rule enforced at both boundaries.
   */
  private static validateTitle(title: string): void {
    const trimmed = title?.trim() ?? '';
    if (trimmed.length < TITLE_MIN_LENGTH || trimmed.length > TITLE_MAX_LENGTH) {
      throw new InvalidProductDataError(
        `Product title must be between ${TITLE_MIN_LENGTH} and ${TITLE_MAX_LENGTH} characters`,
      );
    }
  }

  private static validateDescription(description: string | null): void {
    if (description !== null && description.length > DESCRIPTION_MAX_LENGTH) {
      throw new InvalidProductDataError(`Product description must not exceed ${DESCRIPTION_MAX_LENGTH} characters`);
    }
  }

  toProps(): Readonly<ProductProps> {
    return this.props;
  }
}
