import { describe, it, expect, vi, beforeEach } from 'vitest';
import { CreateProductCommand } from '../../../modules/product/application/commands/create-product.command';
import { ProductDomainService } from '../../../modules/product/domain/services/product-domain.service';
import { ConflictError, ValidationError } from '../../../core/errors/error-catalog';
import type { IProductRepository } from '../../../modules/product/application/ports/product.repository.port';
import type { IProductCache } from '../../../modules/product/application/ports/product-cache.port';
import type { ITransactionManager } from '../../../core/database/transaction-manager';
import type { IOutboxRepository } from '../../../core/events/outbox/transactional-outbox.repository';

function buildDeps() {
  const repository: IProductRepository = {
    findById: vi.fn(),
    findBySlug: vi.fn(),
    findMany: vi.fn(),
    existsBySlug: vi.fn().mockResolvedValue(false),
    save: vi.fn().mockResolvedValue(undefined),
  };
  const cache: IProductCache = {
    getById: vi.fn(),
    getBySlug: vi.fn(),
    setById: vi.fn(),
    setBySlug: vi.fn(),
    invalidate: vi.fn(),
    invalidateListCaches: vi.fn().mockResolvedValue(undefined),
  };
  const transactionManager: ITransactionManager = {
    runInTransaction: vi.fn(async (work) => work({} as never)),
  };
  const outbox: IOutboxRepository = { append: vi.fn().mockResolvedValue(undefined) };
  return { repository, cache, transactionManager, outbox };
}

describe('CreateProductCommand', () => {
  let deps: ReturnType<typeof buildDeps>;
  let command: CreateProductCommand;

  beforeEach(() => {
    deps = buildDeps();
    command = new CreateProductCommand(
      deps.repository,
      deps.cache,
      new ProductDomainService(),
      deps.transactionManager,
      deps.outbox,
    );
  });

  it('creates a product, writes inside a transaction with the outbox event, and invalidates list cache', async () => {
    const result = await command.execute({
      sellerId: 'seller-1',
      dto: { categoryId: 'cat-1', title: 'Nice Shoes', basePrice: 49.99 },
    });

    expect(result.sellerId).toBe('seller-1');
    expect(result.status).toBe('draft');
    expect(deps.transactionManager.runInTransaction).toHaveBeenCalledTimes(1);
    expect(deps.repository.save).toHaveBeenCalledTimes(1);
    expect(deps.outbox.append).toHaveBeenCalledTimes(1);
    expect(deps.cache.invalidateListCaches).toHaveBeenCalledWith('seller-1');
  });

  it('never trusts a client-supplied sellerId — only the authenticated actor sellerId is used', async () => {
    const result = await command.execute({
      sellerId: 'authenticated-seller',
      dto: { categoryId: 'cat-1', title: 'Item', basePrice: 10 } as never,
    });
    expect(result.sellerId).toBe('authenticated-seller');
  });

  it('throws ConflictError when the slug already exists for the seller', async () => {
    deps.repository.existsBySlug = vi.fn().mockResolvedValue(true);
    await expect(
      command.execute({ sellerId: 'seller-1', dto: { categoryId: 'cat-1', title: 'Dup', basePrice: 5 } }),
    ).rejects.toThrow(ConflictError);
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  // Day 5 STEP 8 — gap-fill: "create product invalid price"
  it('translates an invalid price (Money domain violation) into a ValidationError, not a 500', async () => {
    await expect(
      command.execute({
        sellerId: 'seller-1',
        dto: { categoryId: 'cat-1', title: 'Bad Price Item', basePrice: -10 },
      }),
    ).rejects.toThrow(ValidationError);
    // no partial write: a domain-validation failure must never reach the transaction
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('translates a price with more than 2 decimal places into a ValidationError', async () => {
    await expect(
      command.execute({
        sellerId: 'seller-1',
        dto: { categoryId: 'cat-1', title: 'Odd Cents Item', basePrice: 19.999 },
      }),
    ).rejects.toThrow(ValidationError);
  });

  // Day 5 STEP 8 — gap-fill: "create product invalid data"
  it('translates an invalid title (domain invariant, Day 5 hardening) into a ValidationError', async () => {
    await expect(
      command.execute({ sellerId: 'seller-1', dto: { categoryId: 'cat-1', title: 'ab', basePrice: 10 } }),
    ).rejects.toThrow(ValidationError);
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('rejects a title over 200 characters with a ValidationError', async () => {
    await expect(
      command.execute({ sellerId: 'seller-1', dto: { categoryId: 'cat-1', title: 'x'.repeat(201), basePrice: 10 } }),
    ).rejects.toThrow(ValidationError);
  });

  // Day 9 audit — real bug: a symbol-only title collapses to an empty auto-generated
  // slug, which previously reached the repository/DB unvalidated.
  it('rejects an all-symbol title that would generate an empty slug, with a ValidationError', async () => {
    await expect(
      command.execute({ sellerId: 'seller-1', dto: { categoryId: 'cat-1', title: '!!! ??? ###', basePrice: 10 } }),
    ).rejects.toThrow(ValidationError);
    expect(deps.repository.existsBySlug).not.toHaveBeenCalled(); // fails before ever hitting the repository
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('still succeeds for an all-symbol title when the client supplies an explicit slug', async () => {
    const result = await command.execute({
      sellerId: 'seller-1',
      dto: { categoryId: 'cat-1', title: '!!! ??? ###', basePrice: 10, slug: 'client-provided-slug' },
    });
    expect(result.slug).toBe('client-provided-slug');
  });
});
