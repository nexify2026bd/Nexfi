import { describe, it, expect, vi } from 'vitest';
import { UpdateProductCommand } from '../../../modules/product/application/commands/update-product.command';
import { Product } from '../../../modules/product/domain/entities/product.entity';
import { ProductId } from '../../../modules/product/domain/value-objects/product-id.vo';
import { Money } from '../../../modules/product/domain/value-objects/money.vo';
import { PolicyEngine } from '../../../core/rbac/policy.engine';
import { NotFoundError, ConflictError, ValidationError } from '../../../core/errors/error-catalog';
import { ProductOwnershipViolationError } from '../../../modules/product/application/errors/product-ownership-violation.error';
import type { IProductRepository } from '../../../modules/product/application/ports/product.repository.port';
import type { IProductCache } from '../../../modules/product/application/ports/product-cache.port';
import type { ITransactionManager } from '../../../core/database/transaction-manager';
import type { IOutboxRepository } from '../../../core/events/outbox/transactional-outbox.repository';

const validId = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';
const owner = { userId: 'seller-1', roles: ['seller'] };
const stranger = { userId: 'seller-2', roles: ['seller'] };

function makeProduct() {
  return Product.create({
    id: ProductId.from(validId),
    sellerId: 'seller-1',
    categoryId: 'cat-1',
    brandId: null,
    title: 'Original Title',
    slug: 'slug',
    description: null,
    basePrice: Money.from(10),
  });
}

function buildDeps(product: Product | null, saveImpl?: () => Promise<void>) {
  const repository: IProductRepository = {
    findById: vi.fn().mockResolvedValue(product),
    findBySlug: vi.fn(),
    findMany: vi.fn(),
    existsBySlug: vi.fn(),
    save: saveImpl ? vi.fn(saveImpl) : vi.fn().mockResolvedValue(undefined),
  };
  const cache: IProductCache = {
    getById: vi.fn(), getBySlug: vi.fn(), setById: vi.fn(), setBySlug: vi.fn(),
    invalidate: vi.fn(), invalidateListCaches: vi.fn(),
  };
  const transactionManager: ITransactionManager = { runInTransaction: vi.fn(async (w) => w({} as never)) };
  const outbox: IOutboxRepository = { append: vi.fn() };
  const policyEngine = new PolicyEngine();
  policyEngine.register('product', { can: (actor, _action, resource: Product) => resource.isOwnedBy(actor.userId) });
  return { repository, cache, transactionManager, outbox, policyEngine };
}

describe('UpdateProductCommand', () => {
  // Day 5 STEP 8 — gap-fill: "update product success"
  it('updates allowed fields, writes inside the outbox transaction, and invalidates the specific product cache', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);

    const result = await command.execute({
      productId: validId,
      actor: owner,
      dto: { title: 'Updated Title', basePrice: 25.5 },
    });

    expect(result.title).toBe('Updated Title');
    expect(result.basePrice).toBe(25.5);
    expect(deps.transactionManager.runInTransaction).toHaveBeenCalledTimes(1);
    expect(deps.outbox.append).toHaveBeenCalledTimes(1);
    expect(deps.cache.invalidate).toHaveBeenCalledWith(validId, 'seller-1', 'slug');
  });

  it('raises NotFoundError for a missing product', async () => {
    const deps = buildDeps(null);
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(
      command.execute({ productId: validId, actor: owner, dto: { title: 'X' } }),
    ).rejects.toThrow(NotFoundError);
  });

  // Day 5 STEP 8 — gap-fill: "update product ownership violation"
  it('rejects a non-owner with PRODUCT_OWNERSHIP_VIOLATION and never calls save()', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);

    let caught: unknown;
    try {
      await command.execute({ productId: validId, actor: stranger, dto: { title: 'Hijacked Title' } });
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(ProductOwnershipViolationError);
    expect(caught).toMatchObject({ code: 'PRODUCT_OWNERSHIP_VIOLATION' });
    expect(deps.repository.save).not.toHaveBeenCalled();
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('rejects updating an archived product with an InvalidStateTransition-mapped error', async () => {
    const product = makeProduct();
    product.archive();
    const deps = buildDeps(product);
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(
      command.execute({ productId: validId, actor: owner, dto: { title: 'Too Late' } }),
    ).rejects.toMatchObject({ code: 'PRODUCT_INVALID_STATUS_TRANSITION' });
  });

  it('rejects an invalid title update with a ValidationError (Day 5 domain hardening)', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(
      command.execute({ productId: validId, actor: owner, dto: { title: 'x' } }),
    ).rejects.toThrow(ValidationError);
  });

  // Day 5 STEP 8 — gap-fill: "update product version conflict"
  it('propagates PRODUCT_VERSION_CONFLICT from the repository without swallowing it (never silently overwrites)', async () => {
    const product = makeProduct();
    const deps = buildDeps(product, async () => {
      throw new ConflictError('PRODUCT_VERSION_CONFLICT', 'Product was modified concurrently; reload and retry');
    });
    const command = new UpdateProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);

    let caught: unknown;
    try {
      await command.execute({ productId: validId, actor: owner, dto: { title: 'Racing Update' } });
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(ConflictError);
    expect(caught).toMatchObject({ code: 'PRODUCT_VERSION_CONFLICT' });
    // the command must not report success or cache the stale write when the repository rejects
    expect(deps.cache.invalidate).not.toHaveBeenCalled();
  });
});
