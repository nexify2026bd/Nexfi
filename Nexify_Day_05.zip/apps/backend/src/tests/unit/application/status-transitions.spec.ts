import { describe, it, expect, vi } from 'vitest';
import { PublishProductCommand } from '../../../modules/product/application/commands/publish-product.command';
import { ArchiveProductCommand } from '../../../modules/product/application/commands/archive-product.command';
import { Product } from '../../../modules/product/domain/entities/product.entity';
import { ProductId } from '../../../modules/product/domain/value-objects/product-id.vo';
import { Money } from '../../../modules/product/domain/value-objects/money.vo';
import { PolicyEngine } from '../../../core/rbac/policy.engine';
import { NotFoundError, InvalidStateTransitionError } from '../../../core/errors/error-catalog';
import { ProductOwnershipViolationError } from '../../../modules/product/application/errors/product-ownership-violation.error';
import type { IProductRepository } from '../../../modules/product/application/ports/product.repository.port';
import type { IProductCache } from '../../../modules/product/application/ports/product-cache.port';
import type { ITransactionManager } from '../../../core/database/transaction-manager';
import type { IOutboxRepository } from '../../../core/events/outbox/transactional-outbox.repository';

const validId = '018f2c9e-1a2b-7c3d-8e4f-1234567890ab';
const owner = { userId: 'seller-1', roles: ['seller'] };
const stranger = { userId: 'seller-2', roles: ['seller'] };

function makeProduct() {
  return Product.create({
    id: ProductId.from(validId),
    sellerId: 'seller-1',
    categoryId: 'cat-1',
    brandId: null,
    title: 'T',
    slug: 'slug',
    description: null,
    basePrice: Money.from(10),
  });
}

function buildDeps(product: Product | null) {
  const repository: IProductRepository = {
    findById: vi.fn().mockResolvedValue(product),
    findBySlug: vi.fn(),
    findMany: vi.fn(),
    existsBySlug: vi.fn(),
    save: vi.fn().mockResolvedValue(undefined),
  };
  const cache: IProductCache = {
    getById: vi.fn(), getBySlug: vi.fn(), setById: vi.fn(), setBySlug: vi.fn(),
    invalidate: vi.fn(), invalidateListCaches: vi.fn(),
  };
  const transactionManager: ITransactionManager = { runInTransaction: vi.fn(async (w) => w({} as never)) };
  const outbox: IOutboxRepository = { append: vi.fn() };
  // Mirrors the real ProductOwnershipPolicy (application/policies/) — reused via
  // dependency injection through the PolicyEngine, not duplicated inline (Day 5 STEP 2).
  const policyEngine = new PolicyEngine();
  policyEngine.register('product', { can: (actor, _action, resource: Product) => resource.isOwnedBy(actor.userId) });
  return { repository, cache, transactionManager, outbox, policyEngine };
}

describe('PublishProductCommand', () => {
  it('rejects a non-owner with the specific PRODUCT_OWNERSHIP_VIOLATION error (Day 5 STEP 8: publish ownership violation)', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new PublishProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);

    let caught: unknown;
    try {
      await command.execute({ productId: validId, actor: stranger });
    } catch (err) {
      caught = err;
    }

    expect(caught).toBeInstanceOf(ProductOwnershipViolationError);
    expect(caught).toMatchObject({ code: 'PRODUCT_OWNERSHIP_VIOLATION' });
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('raises NotFoundError for a missing product', async () => {
    const deps = buildDeps(null);
    const command = new PublishProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: owner })).rejects.toThrow(NotFoundError);
  });

  it('succeeds for the owning seller and transitions draft → pending_approval (never a direct "published" state)', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new PublishProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    const result = await command.execute({ productId: validId, actor: owner });
    expect(result.status).toBe('pending_approval');
    expect(deps.outbox.append).toHaveBeenCalledTimes(1);
  });

  // Day 5 STEP 8 — gap-fill: "publish product invalid transition"
  it('rejects publishing a product that is already pending_approval (invalid transition)', async () => {
    const product = makeProduct();
    product.submitForApproval(); // now pending_approval
    const deps = buildDeps(product);
    const command = new PublishProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: owner })).rejects.toThrow(InvalidStateTransitionError);
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('rejects publishing an archived product (invalid transition)', async () => {
    const product = makeProduct();
    product.archive();
    const deps = buildDeps(product);
    const command = new PublishProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: owner })).rejects.toThrow(InvalidStateTransitionError);
  });
});

describe('ArchiveProductCommand', () => {
  // Day 5 STEP 8 — gap-fill: "archive product success"
  it('succeeds for the owning seller and transitions to archived', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new ArchiveProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    const result = await command.execute({ productId: validId, actor: owner });
    expect(result.status).toBe('archived');
    expect(deps.outbox.append).toHaveBeenCalledTimes(1);
    expect(deps.cache.invalidateListCaches).toHaveBeenCalledWith('seller-1');
  });

  it('rejects re-archiving an already-archived product (invalid transition)', async () => {
    const product = makeProduct();
    product.archive();
    const deps = buildDeps(product);
    const command = new ArchiveProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: owner })).rejects.toThrow(InvalidStateTransitionError);
  });

  // Day 5 STEP 8 — gap-fill: "archive product ownership violation"
  it('rejects a non-owner attempting to archive with PRODUCT_OWNERSHIP_VIOLATION', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    const command = new ArchiveProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: stranger })).rejects.toThrow(ProductOwnershipViolationError);
    expect(deps.transactionManager.runInTransaction).not.toHaveBeenCalled();
  });

  it('raises NotFoundError for a missing product', async () => {
    const deps = buildDeps(null);
    const command = new ArchiveProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);
    await expect(command.execute({ productId: validId, actor: owner })).rejects.toThrow(NotFoundError);
  });

  // Day 5 STEP 8 — gap-fill: "archive product version conflict"
  it('propagates PRODUCT_VERSION_CONFLICT from the repository without swallowing it', async () => {
    const product = makeProduct();
    const deps = buildDeps(product);
    deps.repository.save = vi.fn(async () => {
      throw Object.assign(new Error('version conflict'), { code: 'PRODUCT_VERSION_CONFLICT', httpStatus: 409 });
    });
    const command = new ArchiveProductCommand(deps.repository, deps.cache, deps.transactionManager, deps.outbox, deps.policyEngine);

    let caught: unknown;
    try {
      await command.execute({ productId: validId, actor: owner });
    } catch (err) {
      caught = err;
    }

    expect(caught).toMatchObject({ code: 'PRODUCT_VERSION_CONFLICT' });
    expect(deps.cache.invalidate).not.toHaveBeenCalled();
  });
});
